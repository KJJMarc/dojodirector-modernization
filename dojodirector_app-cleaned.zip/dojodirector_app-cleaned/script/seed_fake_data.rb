#!/usr/bin/env ruby

STDOUT.sync = true
STDERR.sync = true

require 'rubygems'
require 'bundler'
require './config/environment'
Bundler.setup(:default, :seed)
require 'timecop'
require 'ffaker'
require 'factory_girl_rails'

if Rails.env.production?
  raise "This code can't be run in production environment!"
end
`rake db:reset`

puts "Database cleared"

#minimal set
=begin
NO_OF_RECORDS = {
  :clubs => [1,1],
  :levels => [1,1],
  :badges => [1,1],
  :members => [1,10],
  :events => [1,1],
  :user_levels => [1,1],
  :user_badges => [1,1],
  :attendances => [1,1],
  :checkins => [1,1],
  :events_attended => [1,1]
}
=end

NO_OF_RECORDS = {
  :clubs => [2,2],
  :levels => [3,3],
  :badges => [3,3],
  :members => [100,100],
  :events => [3,10],
  :user_levels => [2,2],
  :user_badges => [3,4],
  :attendances => [3,5],
  :checkins => [5,5],
  :events_attended => [2,5]
}

seeder = Prowd::Seeder.new NO_OF_RECORDS

#make sure we don't send emails
ActionMailer::Base.delivery_method = :test

super_admins = %w{ steve@prowd.com ben@prowd.com joe@prowd.com krzysztof@prowd.com }
super_admins.each do |email|
  super_admin = User.create! :email => email, :password => 'password'
  super_admin.add_role :super_admin
end

puts "created super admins"

club_types = ["Football", "Cricket", "Squash", "Brazilian Ju Jitsu",
  "Children Sports Club", "Running Club", "Gym"]

club_types.each do |club_type_name|
  club_type = ClubType.create! :type_name => club_type_name,
    :available => true,
    :token_criteria => true
  
  seeder.add_levels_to_club_type club_type
  seeder.add_badges_to_club_type club_type
end
puts "Created club types"

ClubType.all.each do |club_type|
  seeder.create_clubs club_type
end

puts "Created clubs"

Club.approved.each do |club|
  seeder.add_users_to_club club
  seeder.add_events_to_club club
end

member_count = ClubUser.count

ClubUser.order("random()").first((member_count * 0.9).to_i).each do |club_user|
  seeder.add_member_data club_user
end

