#!/usr/bin/env ruby

STDOUT.sync = true
STDERR.sync = true

require 'rubygems'
require 'mysql2'
require 'bundler'
require './config/environment'
Bundler.setup

#make sure we don't send emails
ActionMailer::Base.delivery_method = :test

club_type = ClubType.new :type_name => "Brazilian Ju-Jitsu",
  :available => true,
  :token_criteria => true
club_type.save! :validate => false

club_type_id = club_type.id

config = {
  :host => ARGV[0],
  :username => ARGV[1],
  :password => ARGV[2],
  :database => ARGV[3]
}

client = Mysql2::Client.new(config)
level_mapping = {}

level_groups = client.query("SELECT * FROM badge_groups")
level_groups.each do |lg|
  level_group = club_type.level_groups.find_by_name lg["name"]
  level_group ||= LevelGroup.new :name => lg["name"]

  level_group.position = lg["ord"].to_i
  level_group.club_type = club_type
  level_group.save!

  levels = client.query("SELECT * FROM badge WHERE custom = 0 AND badge_group_id = #{lg["id"]}")
  levels.each do |lvl|
    level = level_group.levels.find_by_name lvl["name"]
    level ||= Level.new :level_group => level_group,
      :name => lvl["name"],
      :club_type => club_type,
      :code => lvl["name"].downcase.gsub(/\W+/,"_"),
      :position => lvl["ord"].to_i,
      :weeks_to_achieve => lvl["required_tokens"],
      :times_to_achieve => 2
    level.club_type = club_type
    level.save! :validate => false
    level_mapping[lvl["id"]] = level.id
  end
end

venues = client.query("SELECT * FROM venue")
venues.each do |venue|
  club = Club.find_by_name(venue["name"]) || Club.new(:name => venue["name"], 
    :address_attributes => {
      :line_1 => venue["address1"],
      :line_2 => venue["address2"]
    }
  )
  club.club_type_id = club_type_id
  club.save! :validate => false
  club.update_attribute :status, 'approved'

  users = client.query("SELECT * FROM user WHERE venue = #{venue["id"]}")
  users.each do |u|
    email = u["email"].blank? ? "missing+#{u["id"]}@prowd.com" : u["email"]

    user = User.new :email => email,
      :first_name => u["first_name"].blank? ? u["nickname"] : u["first_name"],
      :last_name => u["last_name"]
    user.save! :validate => false
    club.users << user
    user.add_role :member, club

    if u["suspended"] == 1
      user.suspend(club)
    end

    if u["admin"] == 3
      user.add_role :super_admin
    elsif u["admin"] == 2
      user.add_role :admin, club
    end

    user_levels = client.query("SELECT * FROM user_badge_lookup
                               WHERE user_id = #{u["id"]}")
    user_levels.each do |ul|
      if level_id = level_mapping[ul["badge_id"]]
        user.set_level_in_club Level.find(level_id), club, ul["created"]
      end
    end

    attendances = client.query("SELECT * FROM user_venue_attendance
                               WHERE user_id = #{u["id"]}")
    attendances.each do |a|
      user.attendances.at_club(club).toggle a["date"], true
    end
  end
end


 
