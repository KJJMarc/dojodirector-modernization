require 'spec_helper'

describe ClubProfilePresenter do
  let(:user)  { create(:user) }
  let(:club)  { create(:club) }

  before { club.users << user }
  subject { ClubProfilePresenter.new(club, user) }

  its(:role_in_club) { should == "None" }

  context "role_in_club" do
    describe "admin" do
      before do
        user.add_role :admin, club
      end

      its(:role_in_club) { should == "Admin" }
    end

    describe "suspended_member" do
      before do
        user.suspend(club)
      end
      it { should be_suspended }
    end
  end
end
