require 'spec_helper'

describe MessagePresenter do
  let(:alice)   { create(:user) }
  let(:bob)     { create(:user) }
  let(:message) { alice.send_message(bob, "Hi", "Bob") }

  subject { MessagePresenter.new(message).as_json }

  it "returns proper open attribute" do
    subject[:readed].should == message.opened
  end

  it "returns proper receiver id" do
    subject[:sender_id].should == message.from.id
  end
end