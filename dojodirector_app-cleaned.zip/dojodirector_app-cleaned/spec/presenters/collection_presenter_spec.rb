require 'spec_helper'

class MyArray < Array; end

describe CollectionPresenter do
  let(:root) { :root }
  let(:presenter) { MyArray }

  subject { CollectionPresenter.new([1], :root => root, :presenter => presenter).as_json }

  its(:keys) { should include(root) }

  it "returns presenter instance inside array" do
    subject[:root].first.should be_kind_of(presenter)
  end

  context "default root and presenter" do
    let(:root)      { nil }
    let(:presenter) { nil }

    its(:keys) { should include(:collection) }

    it "returns the same object without presenter" do
      subject[:collection].first.should_not be_kind_of(MyArray)
      subject[:collection].first.should_not be_kind_of(Array)
      subject[:collection].first.should be_kind_of(Fixnum)
    end
  end
end
