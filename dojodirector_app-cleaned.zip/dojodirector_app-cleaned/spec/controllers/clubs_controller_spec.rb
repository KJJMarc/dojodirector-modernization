require 'spec_helper'

describe ClubsController do
  let(:club)   { create(:club) }

  describe "show page" do
    it "should display club profile" do
      get :show, :id => club.id
      assigns(:club).should eq(club)
      response.should render_template("show")
    end
  end

end
