require 'spec_helper'

describe Users::CheckInsController do
  let(:user)              { create(:user) }
  let(:club)              { create(:club) }
  let(:club2)             { create(:club) }

  before do
    user.clubs << club
    user.add_role(:member, club)
    as_user(user)
  end

  describe "GET 'create'" do
    it "should create check-in" do
      user_check_ins = user.check_ins.count
      club_check_ins = club.check_ins.count

      post :create, :user_id => user.id,
                    :check_in => { :content => "Check in", :club_id => club.id }

      response.should redirect_to(user_profile_path(user))
      club.reload.check_ins.count.should eq(club_check_ins + 1)
      user.reload.check_ins.count.should eq(user_check_ins + 1)
    end

    it "should not create check-in by suspended member" do
      user.suspend(club)
      user_check_ins = user.check_ins.count
      club_check_ins = club.check_ins.count

      post :create, :user_id => user.id,
                    :check_in => { :content => "Check in", :club_id => club.id }

      club.reload.check_ins.count.should eq(club_check_ins)
      user.reload.check_ins.count.should eq(user_check_ins)
    end

    it "should not create check-in by non-member" do
      user_check_ins = user.check_ins.count
      club_check_ins = club2.check_ins.count

      post :create, :user_id => user.id,
                    :check_in => { :content => "Check in", :club_id => club2.id }

      club2.reload.check_ins.count.should eq(club_check_ins)
      user.reload.check_ins.count.should eq(user_check_ins)
    end

  end
end
