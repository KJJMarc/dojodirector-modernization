require 'spec_helper'

describe Users::BadgesController do
  let(:user)              { create(:user) }
  let(:club)              { create(:club) }
  let(:number_of_badges)  { 3 }
  let(:badge)             { user.badges.first }
  let(:last_badge)        { user.badges.last }

  before do
    user.clubs << club
    number_of_badges.times do
      badge = create(:badge, :club => club)
      user.user_badges.create(:badge => badge, :club => club)
    end

    as_user(user)
  end

  describe "show page" do
    it "should include club " do
      get :index, :user_id => user.id
      assigns(:badges).should include(club)
    end

    it "should include badges in proper order" do
      get :index, :user_id => user.id
      assigns(:badges)[club].should == user.user_badges.order("updated_at desc")
    end
  end
end
