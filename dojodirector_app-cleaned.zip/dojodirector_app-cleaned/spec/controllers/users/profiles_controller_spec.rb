require 'spec_helper'

describe Users::ProfilesController do
  let(:user)          { create(:user) }
  let(:club)          { create(:club) }
  let(:first_event)   { create(:event, :club => club) }
  let(:second_event)  { create(:event, :club => club) }
  let(:level)         { create(:level, :club_type => club.club_type) }

  before do
    user.clubs << club
    user.add_role(:member, club)
    user.events << first_event
    user.events << second_event
    user.set_level_in_club(level, club)

    as_user(user)
  end

  describe "show page" do
    it "should display user profile" do
      get :show, :user_id => user.id
      assigns(:user).should == user
      assigns(:club).should == user.clubs.first
      assigns(:clubs).should == user.clubs
    end
  end
end
