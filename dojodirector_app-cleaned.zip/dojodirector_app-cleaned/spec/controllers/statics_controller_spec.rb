require 'spec_helper'

describe StaticsController do

  describe "GET 'terms'" do
    it "should render terms of service page" do
      get :terms
      response.should render_template("terms")
    end
  end

  describe "GET 'faq'" do
    it "should render FAQ page" do
      get :faq
      response.should render_template("faq")
    end
  end

  describe "GET 'contact'" do
    it "should render contact page" do
      get :contact
      response.should render_template("contact")
    end
  end

end
