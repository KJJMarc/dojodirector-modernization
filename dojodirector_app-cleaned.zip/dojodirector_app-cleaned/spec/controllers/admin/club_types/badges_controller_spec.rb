require 'spec_helper'

describe Admin::ClubTypes::BadgesController do
  let(:super_admin) { create(:super_admin) }
  let(:club_type) { create(:club_type) }
  let(:badge) { create(:badge, :club_type => club_type) }

  def image_attachment
    test_image = "#{Rails.root}/spec/assets/attachments/image.gif"
    Rack::Test::UploadedFile.new(test_image, "image/gif")
  end

  before do
    as_user(super_admin)
  end

  describe "new badge page" do
    it "should display new badge form" do
      get :new, :club_type_id => club_type.id

      assigns(:club_type).should eq(club_type)
      assigns(:badge).club_type.should eq(club_type)
      response.should render_template("new")
    end
  end

  describe "create new badge" do
    context "with invalid data" do

      it "should be failed" do
        badges_count = Badge.count
        post :create, :badge => { :name => nil, :image => nil }, :club_type_id => club_type.id
        Badge.count.should eq(badges_count)
        response.should render_template("new")
      end
    end

    context "with valid data" do
      it "should be success" do
        badges_count = Badge.count
        post :create, :badge => { :name => "Badge name", :image => image_attachment }, :club_type_id => club_type.id

        club_type.badges.last.name.should eq("Badge name")
        Badge.count.should eq(badges_count + 1)
        response.should redirect_to(admin_club_type_path(club_type, :anchor => "badges"))
      end
    end
  end


  describe "edit badge page" do
    it "should display edit badge form" do
      get :edit, :club_type_id => club_type.id, :id => badge.id

      assigns(:badge).should eq(badge)
      response.should render_template("edit")
    end
  end

  describe "update badge page'" do
    it "should update badge" do
      put :update, :club_type_id => club_type.id, :id => badge.id, :badge => { :name => "Changed name" }

      badge.reload.name.should eq("Changed name")
      response.should redirect_to(admin_club_type_path(club_type, :anchor => "badges"))
    end
  end

  describe "destroy badge action" do
    it "should remove badge" do
      delete :destroy, :club_type_id => club_type.id, :id => badge.id

      Badge.find_by_id(badge.id).should be_nil
      response.should redirect_to(admin_club_type_path(club_type, :anchor => "badges"))
    end
  end

end
