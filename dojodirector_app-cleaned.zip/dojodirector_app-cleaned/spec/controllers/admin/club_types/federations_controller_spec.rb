require 'spec_helper'

describe Admin::ClubTypes::FederationsController do
  let(:super_admin) { create(:super_admin) }
  let(:club_type)   { create(:club_type) }
  let(:federation)  { create(:federation, :club_type => club_type) }

  before do
    as_user(super_admin)
  end

  describe "new federation page" do
    it "should display new federation form" do
      get :new, :club_type_id => club_type.id

      assigns(:club_type).should eq(club_type)
      assigns(:federation).club_type.should eq(club_type)
      response.should render_template("new")
    end
  end

  describe "create new federation" do
    context "with invalid data" do

      it "should be failed" do
        federations_count = Federation.count
        post :create, :federation => { :name => nil }, :club_type_id => club_type.id
        Federation.count.should eq(federations_count)
        response.should render_template("new")
      end
    end

    context "with valid data" do
      it "should be success" do
        federations_count = Federation.count
        post :create, :federation => { :name => "Federation name" },
                      :club_type_id => club_type.id

        club_type.federations.last.name.should eq("Federation name")
        Federation.count.should eq(federations_count + 1)
        response.should redirect_to(admin_club_type_path(club_type, :anchor => "federations"))
      end
    end
  end

  describe "edit federation page" do
    it "should display edit federation form" do
      get :edit, :club_type_id => club_type.id, :id => federation.id

      assigns(:federation).should eq(federation)
      response.should render_template("edit")
    end
  end

  describe "update federation page'" do
    it "should update federation" do
      put :update, :club_type_id => club_type.id, :id => federation.id,
                   :federation => { :name => "Changed name" }

      federation.reload.name.should eq("Changed name")
      response.should redirect_to(admin_club_type_path(club_type, :anchor => "federations"))
    end
  end

  describe "destroy federation action" do
    it "should remove federation" do
      delete :destroy, :club_type_id => club_type.id, :id => federation.id

      Federation.find_by_id(federation.id).should be_nil
      response.should redirect_to(admin_club_type_path(club_type, :anchor => "federations"))
    end
  end
end
