require 'spec_helper'

describe Admin::ClubTypes::Badges::UsersController do
  let(:super_admin) { create(:super_admin) }
  let(:club_type) { create(:club_type) }
  let(:badge) { create(:badge, :club_type => club_type) }

  before do
    as_user(super_admin)
  end

  describe "index page" do
    it "should display users list for specific badge" do
      get :index, :club_type_id => club_type.id, :badge_id => badge.id
      assigns(:badge).should eq(badge)
      response.should be_success
    end
  end

end
