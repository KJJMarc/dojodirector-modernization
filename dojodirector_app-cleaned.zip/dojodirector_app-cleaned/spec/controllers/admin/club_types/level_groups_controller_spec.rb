require 'spec_helper'

describe Admin::ClubTypes::LevelGroupsController do
  let(:super_admin) { create(:super_admin) }
  let(:club_type) { create(:club_type) }
  let(:level_group) { create(:level_group, :club_type => club_type) }

  before do
    as_user(super_admin)
  end

  describe "new group level page" do
    it "should display new group level form" do
      get :new, :club_type_id => club_type.id

      assigns(:club_type).should eq(club_type)
      assigns(:level_group).club_type.should eq(club_type)
      response.should render_template("new")
    end
  end

  describe "create new group level" do
    context "with invalid data" do
      it "should be failed" do
        groups_count = LevelGroup.count
        post :create, :level_group => { :name => nil }, :club_type_id => club_type.id
        LevelGroup.count.should eq(groups_count)
        response.should render_template("new")
      end
    end

    context "with valid data" do
      it "should be success" do
        groups_count = LevelGroup.count
        post :create, :level_group => { :name => "Group name" }, :club_type_id => club_type.id
        LevelGroup.count.should eq(groups_count + 1)
        response.should redirect_to(admin_club_type_path(club_type, :anchor => "levels"))
      end
    end
  end

  describe "edit group levels page" do
    it "should display edit group level form" do
      get :edit, :club_type_id => club_type.id, :id => level_group.id

      assigns(:level_group).should eq(level_group)
      response.should render_template("edit")
    end
  end

  describe "update group level page" do
    it "should update group level" do
      put :update, :club_type_id => club_type.id, :id => level_group.id, :level_group => { :name => "Changed name" }

      level_group.reload.name.should eq("Changed name")
      response.should redirect_to(admin_club_type_path(club_type, :anchor => "levels"))
    end
  end

end
