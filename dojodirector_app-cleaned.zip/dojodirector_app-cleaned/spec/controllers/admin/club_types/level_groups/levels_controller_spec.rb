require 'spec_helper'

describe Admin::ClubTypes::LevelGroups::LevelsController do
  let(:super_admin) { create(:super_admin) }
  let(:club_type)   { create(:club_type) }
  let(:level_group) { create(:level_group, :club_type => club_type) }
  let(:level)       { create(:level, :club_type => club_type, :level_group => level_group) }

  def image_attachment
    test_image = "#{Rails.root}/spec/assets/attachments/image.gif"
    Rack::Test::UploadedFile.new(test_image, "image/gif")
  end

  before do
    as_user(super_admin)
  end

  describe "new level page" do
    it "should display new level form" do
      get :new, :club_type_id => club_type.id, :level_group_id => level_group.id

      assigns(:club_type).should eq(club_type)
      assigns(:level_group).should eq(level_group)
      assigns(:level).club_type.should eq(club_type)
      assigns(:level).level_group.should eq(level_group)
      response.should render_template("new")
    end
  end

  describe "create new level" do
    context "with invalid data" do

      it "should be failed" do
        levels_count = Level.count
        post :create, :level => { :name => nil, :image => nil }, :club_type_id => club_type.id,
                      :level_group_id => level_group.id
        Badge.count.should eq(levels_count)
        response.should render_template("new")
      end
    end

    context "with valid data" do
      it "should be success" do
        levels_count = Level.count
        post :create, :level => { :name => "Level name", :image => image_attachment }, :club_type_id => club_type.id,
                      :level_group_id => level_group

        level_group.levels.last.name.should eq("Level name")
        Level.count.should eq(levels_count + 1)
        response.should redirect_to(admin_club_type_path(club_type, :anchor => "levels"))
      end
    end
  end


  describe "edit level page" do
    it "should display edit level form" do
      get :edit, :club_type_id => club_type.id, :level_group_id => level_group.id, :id => level.id

      assigns(:level).should eq(level)
      response.should render_template("edit")
    end
  end

  describe "update level page'" do
    it "should level badge" do
      put :update, :club_type_id => club_type.id, :level_group_id => level_group.id, :id => level.id,
                   :level => { :name => "Changed name" }

      level.reload.name.should eq("Changed name")
      response.should redirect_to(admin_club_type_path(club_type, :anchor => "levels"))
    end
  end
end
