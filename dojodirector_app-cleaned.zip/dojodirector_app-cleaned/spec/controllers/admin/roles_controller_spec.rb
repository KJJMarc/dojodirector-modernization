require 'spec_helper'

describe Admin::RolesController do
  let!(:super_admin)  { create(:super_admin) }
  let!(:club)         { create(:club) }
  let!(:user)         { create(:user) }
  let(:admin_role)    { user.roles.where(:name => "admin").first }

  before do
    request.env["HTTP_REFERER"] = "/"
    club.users << user
    user.add_role :admin, club
    admin_role
    as_user(user)
  end

  it "unadmin admin" do
    post :destroy, :club_id => club.id, :user_id => user.id, :id => admin_role.id
    response.code.should == "403"
  end

  it "superadmin unadmin admin" do
    as_user(super_admin)
    post :destroy, :club_id => club.id, :user_id => user.id, :id => admin_role.id
    response.should redirect_to(root_url)
  end
end
