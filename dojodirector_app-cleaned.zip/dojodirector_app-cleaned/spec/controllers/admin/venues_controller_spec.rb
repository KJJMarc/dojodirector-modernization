require 'spec_helper'

describe Admin::VenuesController do
  let(:user) { create(:user) }
  let(:club) { create(:club, :logo => nil) }

  def image_attachment
    test_image = "#{Rails.root}/spec/assets/attachments/image.gif"
    Rack::Test::UploadedFile.new(test_image, "image/gif")
  end

  before do
    club.users << user
    user.add_role :member, club
    user.add_role :admin, club
    as_user(user)
  end

  describe "show page" do
    it "should redirect to members" do
      get 'show', :id => club.id

      response.should redirect_to(admin_venue_members_path(club))
    end
  end

  describe "edit club details page" do
    it "should display edit form" do
      get 'edit', :id => club.id

      assigns(:club).should eq(club)
      response.should be_success
    end
  end

  describe "update club details page" do
    it "should update club details" do
      put 'update', :id => club.id, :club => { :name => "Changed name" }

      club.reload.name.should eq("Changed name")
      response.should redirect_to(admin_venue_members_path(club))
    end
  end

  describe "show club page" do
    it "should update club logo" do
      put 'update', :id => club.id, :club => { :logo => image_attachment }

      club.reload.logo.should_not be_nil
    end
  end
end
