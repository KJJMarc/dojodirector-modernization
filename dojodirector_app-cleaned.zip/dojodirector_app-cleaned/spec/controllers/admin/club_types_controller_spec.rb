require 'spec_helper'

describe Admin::ClubTypesController do
  let(:super_admin)       { create(:super_admin) }
  let(:club_type)         { ClubType.first }
  let(:club_types_count)  { 5 }

  before do
    club_types_count.times { |n| create(:club_type, :type_name => "club type #{n}")}
    as_user(super_admin)
  end

  describe "index page" do
    it "should display list of club types" do
      get 'index'

      assigns(:club_types).count.should eq(club_types_count)
      response.should be_success
    end
  end

  describe "show page" do
    it "should display club type information" do
      get 'show', :id => club_type.id

      assigns(:club_type).should eq(club_type)
      response.should be_success
    end
  end

  describe "new club type page" do
    it "should display new club type form" do
      get 'new'
      response.should be_success
    end
  end

  describe "create new club type" do
    context "with type name" do
      let(:type_name) { "Club type name" }

      it "should create new club type" do
        post 'create', :club_type => { :type_name => type_name }

        ClubType.last.type_name.should eq(type_name)
        response.should redirect_to(admin_club_type_path(ClubType.last))
      end
    end

    context "without type name" do
      let(:type_name) { nil }

      it "should not create new club type" do
        post 'create', :club_type => { :type_name => type_name }

        ClubType.count.should eq(club_types_count)
        response.should render_template("new")
      end
    end
  end

  describe "edit club type page" do
    it "should display edit form" do
      get 'edit', :id => club_type.id

      assigns(:club_type).should eq(club_type)
      response.should be_success
    end
  end

  describe "update club type page" do
    it "should update club type" do
      put 'update', :id => club_type.id, :club_type => { :type_name => "Changed name" }

      club_type.reload.type_name.should eq("Changed name")
      response.should redirect_to(admin_club_type_path(club_type))
    end
  end

end
