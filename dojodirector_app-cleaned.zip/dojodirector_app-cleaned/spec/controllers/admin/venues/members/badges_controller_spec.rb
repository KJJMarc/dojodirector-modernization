require 'spec_helper'

describe Admin::Venues::Members::BadgesController do
  let(:user)               { create(:user) }
  let(:member)             { create(:user) }
  let(:club)               { create(:club) }
  let(:badge)              { create(:badge, :club => club) }
  let(:user_badge)         { create(:user_badge, :badge => badge,
                                    :user => member, :club => club) }

  before do
    club.users << user
    club.users << member
    user.add_role :admin, club
    as_user(user)
  end

  describe "index page" do
    it "should display list of awarded bages" do
      get :index, :venue_id => club.id, :member_id => member.id
      assigns(:club).should eq(club)
      assigns(:member).should eq(member)
      response.should render_template("index")
    end
  end

  describe "award action" do
    it "should award badge to member" do
      second_badge = create(:badge, :club_type => club.club_type)
      expect {
        post :create, :venue_id => club.id, :member_id => member.id,
          :user_badge => {:badge_id => second_badge.id}
      }.to change{ member.badges.count }.by 1

      member.badges.should include(second_badge)
    end

    it "should redirect to member page and set a message if badge can't be created" do
      second_badge = create(:badge, :club_type => club.club_type)
      UserBadge.any_instance.stub(:valid?).and_return(false)

      expect {
        post :create, :venue_id => club.id, :member_id => member.id,
          :user_badge => {:badge_id => second_badge.id}
      }.to_not change{ member.badges.count }

      response.should redirect_to(admin_venue_member_path(club, member))
      flash[:alert].should =~ /Badge could not be awarded/
    end
  end

  describe "destroy action" do
    it "should remove badge from awarded badges list" do
      user_badge
      expect {
        delete :destroy, :venue_id => club.id, :member_id => member.id,
        :id => user_badge.id
      }.to change{ member.badges.count }.by -1

      member.badges.should_not include(badge)
    end
  end

end
