require 'spec_helper'

describe Admin::Venues::Members::LevelsController do
  let(:user)               { create(:user) }
  let(:member)             { create(:user) }
  let(:level)              { create(:level)}
  let(:other_level)        { create(:level)}
  let(:club)               { create(:club, :club_type => level.club_type) }

  before do
    club.users << user
    club.users << member
    user.add_role :admin, club
    as_user(user)
  end

  describe "index page" do
    it "should display user levels at venue" do
      get :index, :venue_id => club.id, :member_id => member.id
      assigns(:levels).should eq([])
      response.should render_template("index")

      put :update, :venue_id => club.id, :member_id => member.id, :id => level.id
      get :index, :venue_id => club.id, :member_id => member.id
      assigns(:levels).should eq([member.reload.user_levels.last])
    end
  end

  describe "update page" do
    it "should update member level" do
      put :update, :venue_id => club.id, :member_id => member.id, :id => level.id
      member.current_level_in(club).should eq(level)
    end

    it "should not update member level with invalid level" do
      expect do
        put :update, :venue_id => club.id, :member_id => member.id, :id => other_level.id
      end.to raise_error(ActiveRecord::RecordNotFound)
    end
  end

end
