require 'spec_helper'

describe Admin::Venues::ImportsController do
  let(:user)               { create(:user) }
  let(:club)               { create(:club) }

  def csv_attachment
    test_image = "#{Rails.root}/spec/assets/attachments/csv.csv"
    Rack::Test::UploadedFile.new(test_image, "text/csv")
  end

  before do
    club.users << user
    user.add_role :admin, club
    as_user(user)
  end

  describe "GET 'index'" do
    it "returns http success" do
      get 'index', :venue_id => club.id
      response.should be_success
    end
  end

  describe "POST 'create'" do
    it "renders new view when no csv given" do
      post 'create', :venue_id => club.id
      response.should render_template("new")
    end

    it "imports users" do
      expect {
        post 'create', :venue_id => club.id,
          :user_import => { :original_csv => csv_attachment }
      }.to change { UserImport.count }.by(1)

      response.should redirect_to(admin_venue_imports_path(club))
    end
  end
end
