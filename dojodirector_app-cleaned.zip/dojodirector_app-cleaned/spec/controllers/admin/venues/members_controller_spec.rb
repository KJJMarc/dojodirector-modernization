require 'spec_helper'

describe Admin::Venues::MembersController do
  let(:user)               { create(:user) }
  let(:member)             { create(:user) }
  let(:club)               { create(:club) }
  let(:email)              { "example@example.com" }
  let(:username)           { "user_example" }
  let(:first_name)         { "Invited" }
  let(:last_name)          { "Member" }
  let(:date_of_birth)      { Date.today }
  let(:gender)             { :male }
  let(:invitation_message) { "Custom message" }

  before do
    club.users << user
    club.users << member
    user.add_role :admin, club
    as_user(user)
  end

  describe "show member page" do
    it "should display member details" do
      get :show, :venue_id => club.id, :id => user.id
      assigns(:club).should eq(club)
      assigns(:member).should eq(user)
      response.should be_success
    end
  end

  describe "new member page" do
    it "should display new member form" do
      get :new, :venue_id => club.id
      assigns(:club).should eq(club)
      response.should be_success
    end
  end

  describe "create new member" do
    it "should invite new member" do
      expect {
        post :create, :venue_id => club.id, :user => {
          :first_name => first_name,
          :last_name => last_name,
          :email => email,
          :username => username,
          :invitation_message => invitation_message,
          :gender => gender,
          :date_of_birth => date_of_birth
        }
      }.to change{ club.users.count }.by 1

      assigns(:club).should eq(club)
      club.reload.users.last.full_name.should eq("#{first_name} #{last_name}")

      ActionMailer::Base.deliveries.last.body.should include(invitation_message)
      response.should redirect_to(new_admin_venue_member_path(club))
    end

    it "should fail with invalid data" do
     taken_username = user.username
     members_count = club.users.count

      post :create, :venue_id => club.id, :user => {
        :username => taken_username,
        :first_name => first_name,
        :last_name => last_name
      }

      assigns(:club).should eq(club)
      club.users.last.full_name.should_not eq("#{first_name} #{last_name}")
      club.users.count.should eq members_count
      response.should render_template("new")
    end
  end

  describe "edit member page" do
    it "should display edit member form" do
      get :edit, :venue_id => club.id, :id => member.id
      assigns(:club).should eq(club)
      assigns(:member).should eq(member)
      response.should be_success
    end
  end

  describe "update member" do
    it "should update member details" do
      put :update, :venue_id => club.id, :id => member.id, :user => {
        :first_name => "Changed name",
        :last_name => "Changed lastname"
      }
      assigns(:member).first_name.should eq("Changed name")
      assigns(:member).last_name.should eq("Changed lastname")
      response.should redirect_to(admin_venue_member_path(club, member.reload))
    end
  end

end
