require 'spec_helper'

describe Admin::Venues::EventsController do
  let(:user)   { create(:user) }
  let(:club)   { create(:club) }
  let(:event)  { create(:event, :club => club) }

  before do
    club.users << user
    user.add_role :admin, club
    as_user(user)
  end

  describe "show page" do
    it "should display event details" do
      get :show, :venue_id => club.id, :id => event.id

      assigns(:club).should eq(club)
      assigns(:event).should eq(event)
      response.should render_template("show")
    end
  end

  describe "new page" do
    it "should display new event form" do
      get :new, :venue_id => club.id

      assigns(:club).should eq(club)
      response.should render_template("new")
    end
  end

  describe "clone page" do
    it "should display clone event form" do
      get :clone, :venue_id => club.id, :id => event.id

      event = assigns(:event)

      assigns(:club).should eq(club)
      event.name.should eq(event.name)
      event.description.should eq(event.description)
      event.youtube_id.should eq(event.youtube_id)
      event.scheduled_at.should eq(event.scheduled_at)
      event.end_at.should eq(event.end_at)

      response.should render_template("clone")
    end
  end

  describe "create action" do
    let(:event_name)        { "Event name" }
    let(:event_description) { "Event desc" }
    let(:start_date)        { "10/10/2012" }
    let(:end_date)          { "20/10/2012" }
    let(:start_time)        { "20:00" }
    let(:end_time)          { "22:00" }
    let(:days)              { ["1", "5"] }

    it "should create single event" do
      event_params = { :name => event_name,
                       :description => event_description,
                       :start_date => start_date,
                       :start_time => start_time,
                       :end_time => end_time }
      post :create, :venue_id => club.id,
                    :event => event_params

      assigns(:club).should eq(club)

      d = Date.parse(start_date)
      t = Time.parse(start_time)
      scheduled_at = DateTime.new(d.year, d.month, d.day, t.hour, t.min, t.sec)

      club.events.last.name.should eq(event_name)
      club.events.last.description.should eq(event_description)
      club.events.last.scheduled_at.should eq(scheduled_at)
      response.should redirect_to(admin_venue_events_path(club))
    end
  end

  describe "edit page" do
    it "should display edit event form" do
      get :edit, :venue_id => club.id, :id => event

      assigns(:club).should eq(club)
      assigns(:event).should eq(event)
      response.should render_template("edit")
    end
  end

  describe "update action" do
    let(:event_name)        { "Changed name" }
    let(:event_description) { "Changed desc" }
    let(:start_date)        { "01/12/2013" }
    let(:start_time)        { "15:00" }
    let(:end_time)          { "20:00" }

    it "should update event" do
      event_params = { :name => event_name,
                       :description => event_description,
                       :start_date => start_date,
                       :start_time => start_time,
                       :end_time => end_time }
      put :update, :venue_id => club.id, :id => event.id, :event => event_params

      d = Date.parse(start_date)
      t = Time.parse(start_time)
      scheduled_at = DateTime.new(d.year, d.month, d.day, t.hour, t.min, t.sec)

      event.reload
      event.name.should eq(event_name)
      event.description.should eq(event_description)
      event.scheduled_at.should eq(scheduled_at)
      response.should redirect_to(admin_venue_event_path(club, event))
    end
  end
end
