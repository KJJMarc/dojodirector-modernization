require 'spec_helper'

describe Admin::Venues::EventsCollectionsController do
  let(:user)   { create(:user) }
  let(:club)   { create(:club) }
  let(:event)  { create(:event, :club => club) }

  before do
    club.users << user
    user.add_role :admin, club
    as_user(user)
  end
  
  describe "new page" do
    it "should display new event collection form" do
      get :new, :venue_id => club.id

      assigns(:club).should eq(club)
      response.should render_template("new")
    end
  end

  describe "create action" do
    let(:event_name)        { "Event name" }
    let(:event_description) { "Event desc" }
    let(:start_date)        { "10/10/2012" }
    let(:end_date)          { "20/10/2012" }
    let(:start_time)        { "20:00" }
    let(:end_time)          { "22:00" }
    let(:days)              { ["1", "5"] }
    
    it "should create series of events" do
      post :create, :venue_id => club.id,
        :event_collection => {
          :start_date => start_date,
          :end_date => end_date,
          :start_time => start_time,
          :end_time => end_time,
          :days => ["1", "5"],
          :name => event_name,
          :description => event_description
        }

      number_of_days = (Date.parse(start_date)..Date.parse(end_date)).select do |d|
        days.include?(d.wday.to_s)
      end

      assigns(:club).should eq(club)
      assigns(:event_collection).club.should eq(club)
      assigns(:event_collection).valid?
      EventCollection.last.events.length.should eq(number_of_days.size)
    end
  end
end
