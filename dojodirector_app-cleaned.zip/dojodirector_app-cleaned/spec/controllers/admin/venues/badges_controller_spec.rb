require 'spec_helper'

describe Admin::Venues::BadgesController do
  let(:user)        { create(:user) }
  let(:admin)       { create(:user) }
  let(:club)        { create(:club) }
  let(:club_type)   { club.club_type }
  let(:badge)       { create(:badge, :club => club, :club_type => nil) }

  def image_attachment
    test_image = "#{Rails.root}/spec/assets/attachments/image.gif"
    Rack::Test::UploadedFile.new(test_image, "image/gif")
  end

  before do
    user.add_role :super_admin
    as_user(user)
  end

  describe "new badge page" do
    it "should display new badge form" do
      get :new, :venue_id => club.id

      assigns(:club).should eq(club)
      assigns(:badge).club.should eq(club)
      response.should render_template("new")
    end
  end

  describe "create new badge" do
    context "with invalid data" do

      it "should be failed" do
        badges_count = Badge.count
        post :create, :badge => { :name => nil, :image => nil }, :venue_id => club.id
        Badge.count.should eq(badges_count)
        response.should render_template("new")
      end
    end

    context "with valid data" do
      it "should be success" do
        badges_count = Badge.count
        post :create, :badge => { :name => "Badge name", :image => image_attachment }, :venue_id => club.id

        club.badges.last.name.should eq("Badge name")
        Badge.count.should eq(badges_count + 1)
        response.should redirect_to(admin_venue_badges_path(club))
      end
    end
  end

  describe "edit badge page" do
    it "should display edit badge form" do
      get :edit, :venue_id => club.id, :id => badge.id

      assigns(:badge).should eq(badge)
      response.should render_template("edit")
    end
  end

  describe "update badge page" do
    it "should update badge" do
      put :update, :venue_id => club.id, :id => badge.id, :badge => { :name => "Changed name" }

      badge.reload.name.should eq("Changed name")
      response.should redirect_to(admin_venue_badges_path(club))
    end
  end

  describe "destroy badge action" do
    it "should remove badge" do
      delete :destroy, :venue_id => club.id, :id => badge.id

      Badge.find_by_id(badge.id).should be_nil
      response.should redirect_to(admin_venue_badges_path(club))
    end
  end

  describe "multi-award action" do
    let(:badge)         { badge = create(:badge, :club_type => club.club_type) }
    let(:member)        { club.users.first }
    let(:event)         { create(:event, :club => club) }
    let(:level)         { create(:level, :level_group => level_group, :club_type => club_type) }
    let(:level_group)   { create(:level_group, :club_type => club_type) }

    it "should award badge for all members of event via multi-award action" do
      expect {
        post :award, :venue_id => club.id, :badge_id => badge.id, :for => 'all_members'
      }.to change{ member.badges.count }.by 1

      member.badges.should include(badge)
    end

    it "should award badge for all event attendees of event via multi-award action" do
      event.attendees << member
      member.event_attendees.map(&:confirm)

      expect {
        post :award, :venue_id => club.id, :badge_id => badge.id, :for => 'all_from_event', :event => event.id
      }.to change{ member.badges.count }.by 1

      member.badges.should include(badge)
    end

    it "should award badge for all users with selected level via multi-award action" do
      UserLevel.create(:user => member, :level => level, :club => club)

      expect {
        post :award, :venue_id => club.id, :badge_id => badge.id, :for => 'all_from_group', :level => level.id
      }.to change{ member.badges.count }.by 1

      member.badges.should include(badge)
    end

    it "should not award badge as non-super-admin" do
      user.remove_role :super_admin

      expect {
        post :award, :venue_id => club.id, :badge_id => badge.id, :for => 'all_from_group', :level => level.id
      }.to_not change{ member.badges.count }.by 1
    end
  end

  context "admin" do
    let(:admin) { create(:user) }

    before do
      admin.add_role :admin, club
      as_user(admin)
    end

    it "does not able to create badge" do
      lambda {
        post :create, :badge => { :name => "Badge name", :image => image_attachment }, :venue_id => club.id
      }.should_not change(Badge, :count).by(1)
    end

    it "is able to see new action" do
      get :new, :venue_id => club.id
      response.should render_template("new")
    end
  end
end
