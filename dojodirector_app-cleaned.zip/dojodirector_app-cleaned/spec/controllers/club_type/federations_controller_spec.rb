require 'spec_helper'

describe ClubType::FederationsController do

  let(:federation)  { create(:federation) }
  let(:club_type)   { federation.club_type }
  let(:federations)  { club_type.federations }

  describe "GET 'index'" do
    it "returns http success" do
      get 'index', :club_type_id => club_type.id, :format => :json
      response.should be_success
    end

    it "returns array of associated federation for club type" do
      get 'index', :club_type_id => club_type.id, :format => :json
      response.body.should == federations.to_json
    end
  end
end
