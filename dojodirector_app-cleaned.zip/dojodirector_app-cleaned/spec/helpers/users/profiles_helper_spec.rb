require 'spec_helper'
require 'ostruct'

describe Users::ProfilesHelper do
  let(:user_without_clubs)  { stub(:clubs => []) }
  let(:user_with_clubs)     { stub(:clubs => [Club.new]) }
  let(:user_with_roles) do
    stub(:roles_for => [
      OpenStruct.new(:name => "first_role"),
      OpenStruct.new(:name => "last_role")
    ])
  end
  let(:user_with_level) { stub(:current_level_in => OpenStruct.new(:name => "Level")) }
  let(:user_without_level) { stub(:current_level_in => nil) }


  it "returns without clubs string in case of no associated clubs" do
    club_description(user_without_clubs).should == t(:without_club)
  end

  it "returns with clubs string in case of associated clubs" do
    club_description(user_with_clubs).should == t(:with_club)
  end
end
