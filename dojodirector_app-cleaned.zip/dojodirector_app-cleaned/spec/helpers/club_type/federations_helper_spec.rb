require 'spec_helper'

describe ClubType::FederationsHelper do
end
