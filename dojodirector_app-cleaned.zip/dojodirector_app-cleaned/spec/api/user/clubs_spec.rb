require "spec_helper"

describe "GET /users/1/clubs", :type => :request do
  let(:user) {
    user = create(:user, :clubs => [club])
    user.add_role :member, club
    user
  }
  let(:admin) {
    user = create(:user, :clubs => [club])
    user.add_role :admin, club
    user
  }
  let(:user_2)          { create(:user) }
  let(:club)            { create(:club, :phone_number => "123456789",
                                 :emergency_phone_number => "911") }
  let(:token)           { user.authentication_token }
  let(:default_params)  { {:auth_token => token, :format => :json} }

  before(:all) do
    user
    user_2
    admin
  end

  context "admin" do
    it "returns 200 code" do
      get "/users/#{user.id}/clubs", {:auth_token => admin.authentication_token, :format => :json}
      response.code.should == "200"
    end
  end

  context "user from other club" do
    it "returns 403 code" do
      get "/users/#{user.id}/clubs", {:auth_token => user_2.authentication_token, :format => :json}
      response.code.should == "403"
    end
  end

  context "user (owner)" do
    before { get "/users/#{user.id}/clubs", default_params }

    it "returns 200 code" do
      response.code.should == "200"
    end

    it_behaves_like "clubs in API" do
      let(:parsed_club) { parsed_body[:clubs].first }
    end
  end
end
