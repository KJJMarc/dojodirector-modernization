require 'spec_helper'

describe "GET /users/1/messages", :type => :request do
  let(:alice)           { create(:user) }
  let(:bob)             { create(:user) }
  let(:token)           { bob.authentication_token }
  let(:message)         { alice.send_message(bob, "Hi", "Bob") }
  let(:default_params)  { {:auth_token => token, :format => :json} }
  let(:parsed_message)  { parsed_body[:messages].first }

  before(:all) { message }
  before { get "/users/#{bob.id}/messages", default_params }

  it "returns id of message" do
    parsed_message[:id].should == message.id
  end

  it "returns topic of message" do
    parsed_message[:topic].should == message.topic
  end

  it "return body of message" do
    parsed_message[:body].should == message.body
  end

  it "returns state of message" do
    parsed_message[:readed].should == message.open?
  end

  it "returns sender of message" do
    parsed_message[:sender_id].should == message.from.id
  end
end