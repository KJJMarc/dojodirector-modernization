require 'spec_helper'

describe "GET /users/1/events", :type => :request do
  let(:user)            { create(:user) }
  let(:token)           { user.authentication_token }
  let(:club_type)       { create(:club_type) }
  let(:club)            { create(:club, :club_type => club_type) }
  let(:badge)           { create(:badge, :club_type => club_type) }
  let(:default_params)  { {:auth_token => token, :format => :json} }
  let!(:user_badge)     {UserBadge.create(:user => user, :club => club, :badge => badge)}

  before { get "/users/#{user.id}/badges", default_params }

  it "returns array of events" do
    parsed_body[:badges].should be_kind_of(Array)
  end

  context "badge" do
    it_behaves_like "user badges in API" do
      let(:parsed_badge)    { parsed_body[:badges].first }
      let(:badge_to_check)  { badge }
      let(:user_badge_to_check)  { user_badge }
    end
  end

end
