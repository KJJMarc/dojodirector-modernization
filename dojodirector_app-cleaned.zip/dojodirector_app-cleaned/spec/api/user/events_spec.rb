require 'spec_helper'

describe "events in API", :type => :request do
  let(:user)            { create(:user) }
  let(:token)           { user.authentication_token }
  let(:club)            { create(:club) }
  let(:date)            { Date.today }
  let(:start_time)      { Time.now.strftime("%H:%M") }
  let(:event)           { create(:event, :start_date => date.to_s, :start_time => start_time) }
  let(:default_params)  { {:auth_token => token, :format => :json} }

  before(:all) do
    user.events << event
    user.event_attendees.map(&:confirm)
    club.users << user
  end

  describe "GET /users/1/events" do
    before { get "/users/#{user.id}/events", default_params }

    it "returns array of events" do
      parsed_body[:events].should be_kind_of(Array)
    end

    context "event" do
      it_behaves_like "event in API" do
        let(:event_to_check) { event }
        let(:parsed_event) { parsed_body[:events].first }
      end
    end
  end
end

