require 'spec_helper'

describe "GET /events/1/attendees", :type => :request do
  let(:user)            { create(:user) }
  let(:token)           { user.authentication_token }
  let(:club)            { create(:club) }
  let(:date)            { Date.today }
  let(:start_time)      { Time.now.strftime("%H:%M") }
  let(:event)           { create(:event, :start_date => date.to_s, :start_time => start_time) }
  let(:event_2)         { create(:event, :start_date => date.to_s, :start_time => start_time) }
  let(:default_params)  { {:auth_token => token, :format => :json} }

  before(:all) do
    user.events << event
    club.users << user
  end

  before { get "/events/#{event.id}/attendees", default_params }

  it "returns array of attendees" do
    parsed_body[:attendees].should be_kind_of(Array)
  end

  it "user should not able to see event attendees" do
    get "/events/#{event_2.id}/attendees", default_params
    response.code.should_not be_equal(200)
  end

  context "event attendee" do
    it_behaves_like "users in API" do
      let(:parsed_user) { parsed_body[:attendees].first }
    end
  end
end
