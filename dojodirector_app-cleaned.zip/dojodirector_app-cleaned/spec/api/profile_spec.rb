require "spec_helper"

describe "login with token", :type => :request do
  let(:user) {
    user =  create(:user, :clubs => [club])
    user.add_role :member, club
    user
  }
  let(:club)            { create(:club) }
  let(:level)           { create(:level) }
  let(:badge)           { create(:badge, :description => "description", :club_id => club) }
  let(:badge_2)         { create(:badge, :description => "another description", :club_id => club) }
  let(:token)           { user.authentication_token }
  let(:default_params)  { { :auth_token => token, :format => :json } }
  let!(:user_level)      { UserLevel.create(:user => user, :club => club, :level => level) }
  let!(:user_badge)      { UserBadge.create(:user => user, :club => club, :badge => badge) }
  let!(:user_badge_2)    { UserBadge.create(:user => user, :club => club, :badge => badge_2) }

  describe "GET /profile" do

    before do
      get "/profile", default_params
    end

    it "returns code 200" do
      response.status.should == 200
    end

    it_behaves_like "member in API" do
      let(:parsed_member) { parsed_body }
    end

    it "returns array of clubs" do
      parsed_body[:clubs].should be_kind_of(Array)
    end

    describe "club profile" do
      let(:parsed_club) { parsed_body[:clubs].first }

      it "returns id of club" do
        parsed_club[:id].should == club.id
      end

      it "returns name of club" do
        parsed_club[:name].should == club.name
      end

      it "returns no of attendances at club" do
        parsed_club[:attendance_count].should == user.attendances_in(club)
      end

      it "returns no of checkins at club" do
        parsed_club[:check_ins_count].should == user.check_ins_in(club)
      end

      it "returns logo url" do
        parsed_club[:logo_url].should == "#{request.protocol}#{request.host_with_port}#{club.logo.url(:medium)}"
      end

      it "returns no role in club" do
        parsed_club[:role_in_club].should == "None"
      end

      describe "level in club" do
        it_behaves_like "level in API" do
          let(:level_to_check)  { level }
          let(:parsed_level)    { parsed_club[:level] }
        end
      end

      describe "featured badges" do
        it_behaves_like "user badges in API" do
          let(:parsed_badge) {parsed_body[:badges].find{|b| b[:id] == badge.id}}
          let(:user_badge_to_check)  { user_badge }
          let(:badge_to_check)  { badge }
        end

        it "returns all user badges" do
          parsed_body[:badges].map { |badge| badge[:id] }.
            should == user.user_badges.map{ |us| us.badge }.map(&:id)
        end
      end
    end
  end
end
