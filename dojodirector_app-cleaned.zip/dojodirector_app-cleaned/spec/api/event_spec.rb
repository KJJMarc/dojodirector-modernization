require 'spec_helper'

describe "events", :type => :request do
  let(:user)            { create(:user) }
  let(:token)           { user.authentication_token }
  let(:date)            { Date.current }
  let(:start_time)      { Time.now.strftime("%H:%M") }
  let(:event)           { create(:event, :start_date => date.to_s, :start_time => start_time) }
  let(:default_params)  { {:auth_token => token, :format => :json} }

  before(:all) do
    event
    user.add_role :super_admin
  end

  describe "GET /events/1" do
    before { get "/events/#{event.id}", default_params }

    it_behaves_like "event in API" do
      let(:event_to_check)  { event.reload }
      let(:parsed_event)    { parsed_body }
    end
  end

  describe "POST /events/1/attendees" do
    before { post "/events/#{event.id}/attendees", default_params.merge('users_ids[]' => user.id) }

    it "returns array of users" do
      parsed_body[:attendees].should be_kind_of(Array)
    end

    it "should add event attendee do event" do
      event.event_attendees.map(&:user).should include(user)
    end

    it_behaves_like "users in API" do
      let(:parsed_user) { parsed_body[:attendees].first }
    end
  end

  describe "PUT /events/1" do
    let(:name) { "updated_name" }

    context "proper attributes" do
      before { put "/events/#{event.id}", default_params.merge('event[name]' => name) }

      it "updated event" do
        event.reload.name.should == name
      end
    end

    context "invalid attributes" do
      before { put "/events/#{event.id}", default_params.merge('event[name]' => '') }

      it "should returns errors" do
        parsed_body.should include(:errors)
      end
    end
  end
end

