require "spec_helper"

describe "login with token", :type => :request do
  let(:password)  { "12345a" }
  let(:user)      { create(:user, :password => password,
                                  :password_confirmation => password) }
  let(:token)     { user.authentication_token }

  it "POST /login without token" do
    post "/login", :auth_token => "", :format => "json"
    response.status.should == 401
  end

  it "POST /login with invalid token" do
    post "/login", :auth_token => "", :format => "json"
    response.status.should == 401
  end

  it "POST /login with valid token" do
    post "/login", :auth_token => user.authentication_token, :format => "json"
    response.status.should == 201
  end

  it "POST /login with invalid password" do
    post "login", :'user[username]' => user.username, :'user[password]' => "invalid", :format => "json"
    response.status.should == 401
  end

  it "POST /login with invalid login" do
    post "login", :'user[username]' => 'invalid', :'user[password]' => password, :format => "json"
    response.status.should == 401
  end

  it "POST /login with login and password" do
    post "login", :'user[username]' => user.username, :'user[password]' => password, :format => "json"
    response.status.should == 201
  end

  it "POST /login with email and password" do
    post "login", :'user[email]' => user.username, :'user[password]' => password, :format => "json"
    response.status.should == 201
  end


  it "POST /login should return proper authentication_token" do
    post "login", :'user[username]' => user.username, :'user[password]' => password, :format => "json"
    JSON.parse(response.body)["authentication_token"].should == user.authentication_token
  end
end
