require "spec_helper"

describe "checkins", :type => :request do
  let(:user)            { create(:user, :clubs => [club]) }
  let(:club)            { create(:club) }
  let(:club_2)          { create(:club) }
  let(:token)           { user.authentication_token }
  let(:default_params)  { {:auth_token => token, :format => :json} }
  let(:check_in)        { create(:check_in, :user => user, :club => club) }
  let(:check_in_2)      { create(:check_in, :user => user, :club => club_2) }

  before(:all) do
    user.add_role :member, club
    check_in
    check_in_2
  end

  context "POST /clubs/1/checkins valid" do
    context "response" do
      before do
        post "/clubs/#{club.id}/checkins", default_params.merge('check_in[content]' => "My check in")
      end

      it "returns proper HTTP code" do
        response.code.should == "201"
      end

      it_behaves_like "check_in in API" do
        let(:check_in_to_check) { CheckIn.last }
        let(:parsed_check_in) { parsed_body }
      end
    end

    it "should create checkin" do
      lambda do
        post "/clubs/#{club.id}/checkins", default_params.merge('check_in[content]' => "My check in")
      end.should change(CheckIn, :count).by(1)
    end
  end

  context "POST /clubs/1/checkins invalid" do
    before do
      post "/clubs/#{club.id}/checkins", default_params
    end

    it "returns new checkin in club" do
      response.code.should == "422"
    end

    it "should not create checkin" do
      lambda do
        post "/clubs/#{club.id}/checkins", default_params
      end.should_not change(CheckIn, :count).by(1)
    end
  end

  context "GET /clubs/1/checkins" do
    before { get "/clubs/#{club.id}/checkins", default_params }

    it "returns 200 code" do
      response.code.should == "200"
    end

    it "returns club checkins" do
      parsed_body[:check_ins].map { |ch| ch[:id] }.tap do |check_ins_ids|
        check_ins_ids.should include(check_in.id)
        check_ins_ids.should_not include(check_in_2.id)
      end
    end

    it_behaves_like "check_in in API" do
      let(:check_in_to_check) { check_in }
      let(:parsed_check_in) { parsed_body[:check_ins].first }
    end
  end
end
