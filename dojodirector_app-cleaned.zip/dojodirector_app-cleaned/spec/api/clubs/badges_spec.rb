require 'spec_helper'

describe "GET /clubs/1/badges", :type => :request do
  let(:user)            { create(:user) }
  let(:token)           { user.authentication_token }
  let(:club_type)       { create(:club_type) }
  let(:club)            { create(:club, :club_type => club_type) }
  let(:badge)           { create(:badge, :club_type => club_type) }
  let(:badge_2)         { create(:badge, :club_type => club_type) }
  let(:default_params)  { {:auth_token => token, :format => :json} }

  before(:all) do
    UserBadge.create(:user => user, :club => club, :badge => badge)
  end

  before { get "/clubs/#{club.id}/badges", default_params }

  it "returns array of events" do
    parsed_body[:badges].should be_kind_of(Array)
  end

  it "returns only badges that belongs to club" do
    parsed_body[:badges].map { |b| b[:id] }.tap do |badges_ids|
      badges_ids.should include(badge.id)
      badges_ids.should_not include(badge_2.id)
    end
  end

  context "badge" do
    it_behaves_like "badges in API" do
      let(:parsed_badge)    { parsed_body[:badges].first }
      let(:badge_to_check)  { badge }

      it "user badge should return title" do
        parsed_badge[:title].should == user.user_badges.last.title
      end
    end
  end
end