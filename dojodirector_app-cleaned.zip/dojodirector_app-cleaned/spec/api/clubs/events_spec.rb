require 'spec_helper'

describe "club events in API", :type => :request do
  let(:user)              { create(:user, :clubs => [club]) }
  let(:token)             { user.authentication_token }
  let(:club)              { create(:club) }
  let(:date)              { Date.current }
  let(:start_time)        { Time.zone.now + 5.minutes }
  let(:start_time_future) { (Time.zone.now + 2.hours).strftime("%H:%M") }
  let(:start_time_past)   { (Time.zone.now - 2.hours).strftime("%H:%M") }
  let(:event)             { create(:event, :start_date => date.to_s, :start_time => start_time, :club => club) }
  let(:event_past)        { create(:event, :start_date => date.to_s, :start_time => start_time_past, :club => club) }
  let(:event_2)           { create(:event, :start_date => date.to_s, :start_time => start_time_future) }
  let(:default_params)    { {:auth_token => token, :format => :json} }

  before(:all) do
    user.add_role :admin, club
    event
    event_2
    event_past
  end

  context "GET /clubs/1/events" do
    before { get "/clubs/#{club.id}/events", default_params }

    it "returns array of events" do
      parsed_body[:events].should be_kind_of(Array)
    end

    it "returns only events from club" do
      parsed_body[:events].map { |e| e[:id] }.tap do |events_ids|
        events_ids.should include(event.id)
        events_ids.should_not include(event_2.id)
      end
    end

    it_behaves_like "event in API" do
      let(:event_to_check) { event }
      let(:parsed_event) { parsed_body[:events].first }
    end
  end

  context "GET /clubs/1/events/upcoming" do
    before { get "/clubs/#{club.id}/events/upcoming", default_params }

    it "returns array of events" do
      parsed_body[:events].should be_kind_of(Array)
    end

    it "returns only events from club" do
      parsed_body[:events].map { |e| e[:id] }.tap do |events_ids|
        events_ids.should include(event.id)
        events_ids.should_not include(event_past.id)
        events_ids.should_not include(event_2.id)
      end
    end

    it_behaves_like "event in API" do
      let(:event_to_check) { event }
      let(:parsed_event) { parsed_body[:events].first }
    end
  end

  context "GET /clubs/1/events/past" do
    before { get "/clubs/#{club.id}/events/past", default_params }

    it "returns array of events" do
      parsed_body[:events].should be_kind_of(Array)
    end

    it "returns only events from club" do
      parsed_body[:events].map { |e| e[:id] }.tap do |events_ids|
        events_ids.should include(event_past.id)
        events_ids.should_not include(event.id)
        events_ids.should_not include(event_2.id)
      end
    end

    it_behaves_like "event in API" do
      let(:event_to_check) { event_past }
      let(:parsed_event) { parsed_body[:events].detect { |e| e[:id] == event_past.id } }
    end
  end

  context "PUT /clubs/1/events/cancel" do
    let(:event_to_cancel) { create(:event, :start_date => date.to_s, :start_time => start_time_future, :club => club) }

    before(:all) { event_to_cancel }
    before { put "/clubs/#{club.id}/events/#{event_to_cancel.id}/cancel", default_params }

    it "returns proper HTTP code" do
      response.code.should == "204"
    end

    it "should cancel event" do
      event_to_cancel.reload.status.should == "canceled"
    end
  end

  context "POST /clubs/1/events" do
    let(:name) { "name" }
    let(:description) { "description" }
    let(:youtube_id) { "http://youtube.com/video?1313131" }
    let(:start_date) { Date.current }
    let(:start_time) { Time.now }
    let(:end_time) { Time.now + 2.hours }
    let(:event_params) do
      {
        :name         => name,
        :description  => description,
        :youtube_id   => youtube_id,
        :start_date   => start_date,
        :start_time   => start_time,
        :end_time     => end_time
      }
    end

    context "invalid params" do
      before do
        post "/clubs/#{club.id}/events",
             default_params.merge(:event => event_params.except(:start_date))
      end

      it "should return errors" do
        parsed_body[:errors].should_not be_blank
      end
    end

    context "valid params" do
      before { post "/clubs/#{club.id}/events", default_params.merge(:event => event_params) }

      it "returns proper HTTP code" do
        response.code.should == "201"
      end

      it "should create proper event" do
        current_event = club.events.find(parsed_body[:id])

        current_event.name.should == name
        current_event.description.should == description
        current_event.youtube_id.should == youtube_id
        current_event.start_date.should == start_date
        current_event.start_time.should == start_time.strftime("%H:%M")
        current_event.end_time.should == end_time.strftime("%H:%M")
      end

      it_behaves_like "event in API" do
        let(:event_to_check)  { club.events.find(parsed_body[:id]) }
        let(:parsed_event)    { parsed_body }
      end
    end
  end
end

