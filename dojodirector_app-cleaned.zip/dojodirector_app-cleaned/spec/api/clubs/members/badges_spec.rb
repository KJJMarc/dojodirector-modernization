require 'spec_helper'

describe "badges", :type => :request do
  let(:user)            { create(:user, :clubs => [club]) }
  let(:member)          { create(:user, :clubs => [club]) }
  let(:token)           { user.authentication_token }
  let(:club_type)       { create(:club_type) }
  let(:club)            { create(:club, :club_type => club_type) }
  let(:badge)           { create(:badge, :club_type => club_type) }
  let(:badge_2)         { create(:badge, :club_type => club_type) }
  let(:default_params)  { {:auth_token => token, :format => :json} }

  context "GET /clubs/1/members/1/badges" do
    let!(:user_badge) { UserBadge.create(:user => user, :club => club, :badge => badge) }

    before { get "/clubs/#{club.id}/members/#{user.id}/badges", default_params }

    it "returns array of events" do
      parsed_body[:badges].should be_kind_of(Array)
    end

    it "returns user badges" do
      parsed_body[:badges].map { |b| b[:id] }.tap do |badges_ids|
        badges_ids.should include(badge.id)
        badges_ids.should_not include(badge_2.id)
      end
    end

    it_behaves_like "user badges in API" do
      let(:parsed_badge)    { parsed_body[:badges].first }
      let(:badge_to_check)  { badge }
      let(:user_badge_to_check)  { user_badge }
    end
  end

  context "POST /clubs/1/members/1/badges" do
    let(:title)         { "title" }
    let(:badge_params)  { { :badge_id => badge.id, :title => title } }

    before do
      user.add_role :admin, club
      post "/clubs/#{club.id}/members/#{member.id}/badges", default_params.merge(badge_params)
    end

    it "returns proper HTTP code" do
      response.code.should == "201"
    end

    it "user should get badge" do
      member.badges.should include(badge)
    end

    it_behaves_like "user badges in API" do
      let(:parsed_badge)    { parsed_body }
      let(:badge_to_check)  { badge }
      let(:user_badge_to_check)  { badge.user_badges.last }
    end
  end
end
