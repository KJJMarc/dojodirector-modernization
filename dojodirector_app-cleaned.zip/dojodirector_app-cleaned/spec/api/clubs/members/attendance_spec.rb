require 'spec_helper'

describe "attendance", :type => :request do
  let(:token)           { admin.authentication_token }
  let(:super_admin)     { create(:super_admin) }
  let(:club)            { create(:club) }
  let(:member)          { create(:user, :clubs => [club]) }
  let(:date)            { Date.today.to_s }

  context "admin adds attendance" do
    let(:admin) { super_admin }

    before { post "/clubs/#{club.id}/members/#{member.id}/attendances",
      :auth_token => token, :format => :json,
      :attendance => { :date => date, :attended => true } }

    it "should create attendance" do
      member.attendances.at_club(club).first.should_not be_nil
    end
  end

  context "admin removes attendance" do
    let(:admin) { super_admin }

    before do
      @old_attendance = Attendance.create!(:user => member,
                                      :club => club,
                                      :date => date.to_date)
      member.attendances.at_club(club).first.should_not be_nil

      post "/clubs/#{club.id}/members/#{member.id}/attendances",
      :auth_token => token, :format => :json,
      :attendance => { :date => date, :attended => false }
    end

    it "should create attendance" do
      member.attendances.at_club(club).first.should be_nil
    end
  end


 
end
