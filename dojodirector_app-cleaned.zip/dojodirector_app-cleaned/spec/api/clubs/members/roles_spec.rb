require 'spec_helper'

describe "roles", :type => :request do
  let(:super_admin)     { create(:super_admin) }
  let(:normal_user)     { create(:user) }
  let(:member)          { create(:user, :clubs => [club]) }
  let(:token)           { admin.authentication_token }
  let(:club)            { create(:club) }
  let(:default_params)  { {:auth_token => token, :format => :json} }

  context "normal user try to add role to member" do
    let(:admin) { normal_user }

    before { post "/clubs/#{club.id}/members/#{member.id}/roles", default_params.merge('role[name]' => 'admin') }

    it "returns proper HTTP code" do
      response.code.should == "403"
    end

    it "member should not get admin role" do
      member.reload.has_role?(:admin, club).should be_false
    end
  end

  context "member of club try to add role to member" do
    let(:admin) { member }

    before { post "/clubs/#{club.id}/members/#{member.id}/roles", default_params.merge('role[name]' => 'admin') }

    it "returns proper HTTP code" do
      response.code.should == "403"
    end

    it "member should not get admin role" do
      member.reload.has_role?(:admin, club).should be_false
    end
  end

  context "admin of club should able to add role" do
    let(:admin) { create(:user) }

    before do
      admin.add_role :admin, club
      post "/clubs/#{club.id}/members/#{member.id}/roles", default_params.merge('role[name]' => 'admin')
    end

    it "returns proper HTTP code" do
      response.code.should == "201"
    end

    it "member should get admin role" do
      member.reload.has_role?(:admin, club).should be_true
    end

    it_behaves_like "role in API" do
      let(:role_to_check) { Role.find_by_name("admin") }
      let(:parsed_role)   { parsed_body }
    end
  end

  context "super-admin should able to add role" do
    let(:admin) { super_admin }

    before { post "/clubs/#{club.id}/members/#{member.id}/roles", default_params.merge('role[name]' => 'admin') }

    it "returns proper HTTP code" do
      response.code.should == "201"
    end

    it "member should get admin role" do
      member.reload.has_role?(:admin, club).should be_true
    end

    it_behaves_like "role in API" do
      let(:role_to_check) { Role.find_by_name("admin") }
      let(:parsed_role)   { parsed_body }
    end
  end
end