require 'spec_helper'

describe "level", :type => :request do
  let(:super_admin)     { create(:super_admin) }
  let(:normal_user)     { create(:user) }
  let(:member)          { create(:user, :clubs => [club]) }
  let(:token)           { admin.authentication_token }
  let(:default_params)  { {:auth_token => token, :format => :json} }
  let(:club)            { create(:club, :club_type => club_type) }
  let(:club_type)       { create(:club_type) }
  let(:level_group)     { create(:level_group, :club_type => club_type) }
  let(:level)           { create(:level, :level_group => level_group, :club_type => club_type) }

  context "normal user try to add level to member" do
    let(:admin) { normal_user }

    before { post "/clubs/#{club.id}/members/#{member.id}/levels", default_params.merge('level_id' => level.id) }

    it "returns proper HTTP code" do
      response.code.should == "403"
    end

    it "does not create level" do
      member.current_level_in(club).should_not == level
    end
  end

  context "member of club try to add level to member" do
    let(:admin) { member }

    before { post "/clubs/#{club.id}/members/#{member.id}/levels", default_params.merge('level_id' => level.id) }

    it "returns proper HTTP code" do
      response.code.should == "403"
    end

    it "does not create level" do
      member.current_level_in(club).should_not == level
    end
  end

  context "admin of club should able to add level" do
    let(:admin) { create(:user) }

    before do
      admin.add_role :admin, club
      post "/clubs/#{club.id}/members/#{member.id}/levels", default_params.merge('level_id' => level.id)
    end

    it "should create level" do
      response.code.should == "201"
    end

    it "does not create level" do
      member.current_level_in(club).should == level
    end

    it_behaves_like "level in API" do
      let(:level_to_check) { level }
      let(:parsed_level)   { parsed_body }
    end
  end

  context "super-admin should able to add level" do
    let(:admin) { super_admin }

    before { post "/clubs/#{club.id}/members/#{member.id}/levels", default_params.merge('level_id' => level.id) }

    it "should create level" do
      response.code.should == "201"
    end

    it "does not create level" do
      member.current_level_in(club).should == level
    end

    it_behaves_like "level in API" do
      let(:level_to_check) { level }
      let(:parsed_level)   { parsed_body }
    end
  end
end