require 'spec_helper'

describe "club members", :type => :request do
  let(:user)            { club.users.first }
  let(:user_2)          { create(:user) }
  let(:token)           { user.authentication_token }
  let(:club)            { create(:club) }
  let(:default_params)  { {:auth_token => token, :format => :json} }
  let(:user_level)      { UserLevel.create(:user => user, :club => club, :level => level) }
  let(:level)           { create(:level) }

  before(:all) do
    user
    user_level
    user.add_role :member, club
  end

  context "GET /clubs/1/members/search" do
    let(:search_params) { default_params.merge(:query => user.email) }

    before { get "/clubs/#{club.id}/members/search", default_params }

    it "returns array of members" do
      parsed_body[:members].should be_kind_of(Array)
    end

    it "returns members matched to query" do
      parsed_body[:members].map { |m| m[:id] }.tap do |members_ids|
        members_ids.should include(user.id)
        members_ids.should_not include(user_2.id)
      end
    end

    describe "member" do
      it_behaves_like "users in API" do
        let(:parsed_user) { parsed_body[:members].first }
      end
    end
  end

  context "GET /clubs/1/members" do
    before { get "/clubs/#{club.id}/members", default_params }

    it "returns array of members" do
      parsed_body[:members].should be_kind_of(Array)
    end

    it "returns members of club" do
      parsed_body[:members].map { |m| m[:id] }.should =~ club.users.map(&:id)
    end

    describe "member" do
      it_behaves_like "users in API" do
        let(:parsed_user) { parsed_body[:members].first }
      end
    end
  end

end