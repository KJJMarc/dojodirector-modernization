require 'spec_helper'

describe "GET /clubs/1", :type => :request do
  let(:club)            { create(:filled_club) }
  let(:club_type)       { club.club_type }
  let(:user)            { create(:user) }
  let(:token)           { user.authentication_token }
  let(:default_params)  { {:auth_token => token, :format => :json} }

  before { get "/clubs/#{club.id}", default_params }

  it_behaves_like "clubs in API" do
    let(:parsed_club) { parsed_body }
  end

  it_behaves_like "clubs type in API" do
    let(:club_type_to_check)  { club_type }
    let(:parsed_club_type)    { parsed_body[:club_type] }
  end
end
