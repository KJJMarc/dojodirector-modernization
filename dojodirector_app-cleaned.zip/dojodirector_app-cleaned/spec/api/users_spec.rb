require "spec_helper"

describe "GET /users/1", :type => :request do
  let(:user) {
    user = create(:user, :clubs => [club])
    user.add_role :member, club
    user
  }
  let(:admin) {
    user = create(:user, :clubs => [club])
    user.add_role :admin, club
    user
  }
  let(:user_2)          { create(:user) }
  let(:club)            { create(:club) }
  let(:token)           { user.authentication_token }
  let(:default_params)  { {:auth_token => token, :format => :json} }

  before(:all) do
    user
    user_2
    admin
  end

  context "admin" do
    it "returns 200 code" do
      get "/users/#{user.id}", {:auth_token => admin.authentication_token, :format => :json}
      response.code.should == "200"
    end
  end

  context "user from other club" do
    it "returns 403 code" do
      get "/users/#{user.id}", {:auth_token => user_2.authentication_token, :format => :json}
      response.code.should == "403"
    end
  end

  context "user (owner)" do
    before { get "/users/#{user.id}", default_params }

    it "returns 200 code" do
      response.code.should == "200"
    end

    it_behaves_like "users in API" do
      let(:parsed_user) { parsed_body }
    end
  end
end
