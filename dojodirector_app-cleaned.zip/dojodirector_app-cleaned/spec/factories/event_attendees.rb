FactoryGirl.define do
  factory :event_attendee do
    event
    user
  end
end
