# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :level_group do
    sequence(:name) {|n| "Level Group name #{n}" }
    sequence(:position) {|n| n }
    club_type
  end
end
