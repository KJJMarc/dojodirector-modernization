# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  sequence :type_name do |n|
    "club_type_#{n}"
  end

  factory :club_type do
    type_name
    header_image { File.new(Rails.root.join('spec', 'assets', 'attachments', 'image.gif')) }
    token_criteria true
  end
end
