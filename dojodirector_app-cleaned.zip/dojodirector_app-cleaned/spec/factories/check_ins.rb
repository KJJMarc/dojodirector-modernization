# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :check_in do
    content "Check-in comment"
    user
    club
  end
end
