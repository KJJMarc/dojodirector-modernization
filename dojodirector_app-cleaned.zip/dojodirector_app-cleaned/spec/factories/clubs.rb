# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :club do
    name
    address
    status "approved"
    statement { Faker::Lorem.sentence }
    club_type
    logo { File.new(Rails.root.join('spec', 'assets', 'attachments', 'image.gif')) }

    after(:create) do |club|
      club.users << FactoryGirl.create(:user)
      club.users.first.add_role :admin, club
    end
  end

  factory :filled_club, :parent => :club do
    twitter_url             "http://twitter.com/prowd"
    facebook_url            "http://facebook.com/prowd_fanpage"
    website_url             "http://prowd.com/"
    phone_number            "123456789"
    emergency_phone_number  "911"
  end
end
