# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  sequence :email do |n|
    "email#{n}@prowd.com"
  end

  sequence :username do |n|
    "user#{n}-prowd"
  end

  factory :user do
    first_name { Faker::Name.first_name }
    last_name { Faker::Name.last_name }
    email
    username
    password "password"
    date_of_birth { ((rand(20) + 8).years + rand(356).days).ago }
    gender :male
    statement Faker::Lorem.sentence
  end

  factory :super_admin, :parent => :user do |user|
    after(:create) { |u| u.add_role(:super_admin) }
  end

  factory :admin, :parent => :user do |user|
    after(:create) { |u| u.add_role(:admin, FactoryGirl.create(:club)) }
  end
end
