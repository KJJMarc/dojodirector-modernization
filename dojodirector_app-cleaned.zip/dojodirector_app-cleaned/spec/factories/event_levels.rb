FactoryGirl.define do
  factory :event_level do
    event
    level
  end
end
