FactoryGirl.define do
  factory :attendance do
    club
    user
    date { 1.day.ago }
  end
end
