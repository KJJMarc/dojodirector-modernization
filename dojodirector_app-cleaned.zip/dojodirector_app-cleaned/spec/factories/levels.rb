# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :level do
    sequence(:name) {|n| "Level name #{n}" }
    sequence(:position) {|n| n }
    image { File.new(Rails.root.join('spec', 'assets', 'attachments', 'image.gif')) }
    club_type
    level_group
    weeks_to_achieve { 1 }
    times_to_achieve { 1 }
  end
end
