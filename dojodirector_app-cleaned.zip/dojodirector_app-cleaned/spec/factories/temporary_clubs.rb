FactoryGirl.define do
  factory :temporary_club do
    name  "TemporaryClub"
    email "club@club.com"
  end
end
