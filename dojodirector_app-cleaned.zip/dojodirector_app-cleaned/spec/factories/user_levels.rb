FactoryGirl.define do
  factory :user_level do
    level
    club
    user
  end
end
