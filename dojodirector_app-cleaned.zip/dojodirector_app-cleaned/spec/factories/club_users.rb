# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :club_user do
  end
end
