# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :group_badge do
  end
end
