# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :address do
    line_1 { Faker::AddressUK.street_address }
    postcode 'EC1R 1UP'
    city { Faker::AddressUK.city }
  end
end
