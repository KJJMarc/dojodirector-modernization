# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :event_collection do
    sequence(:name) {|n| "Collection event name #{n}" }
    description "description"
    youtube_id "AAoXKLSOXmE"

    start_date Date.tomorrow.strftime("%d/%m/%Y")
    end_date (Date.tomorrow + 1.week).strftime("%d/%m/%Y")
    days %w{0}
    start_time "20:00"
    end_time "22:00"
    club
  end
end
