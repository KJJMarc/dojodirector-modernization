# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :user_badge do
    user
    badge
    club
  end
end
