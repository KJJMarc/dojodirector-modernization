# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :event do
    sequence(:name) {|n| "Event name #{n}" }
    description "Event description"
    youtube_id "AAoXKLSOXmE"
    start_date Date.tomorrow.strftime("%d/%m/%Y")
    start_time "20:00"
    end_time "22:00"
    club
    sequence(:scheduled_at) {|n| Time.now + n.days }
    status "active"
  end
end
