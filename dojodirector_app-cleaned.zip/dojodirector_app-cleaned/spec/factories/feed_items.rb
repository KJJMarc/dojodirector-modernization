# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :feed_item do
    user
    club
    subject { create(:event) }
    action "event_create"
  end
end
