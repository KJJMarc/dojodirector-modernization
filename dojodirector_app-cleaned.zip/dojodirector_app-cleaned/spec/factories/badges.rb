# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :badge do
    sequence(:name) {|n| "Badge name #{n}" }
    description "Badge description"
    title_available true
    image { File.new(Rails.root.join('spec', 'assets', 'attachments', 'image.gif')) }
    club_type
  end
end
