FactoryGirl.define do
  sequence :name do |n|
    "Federation_#{n}"
  end

  factory :federation do
    name
    club_type
  end
end
