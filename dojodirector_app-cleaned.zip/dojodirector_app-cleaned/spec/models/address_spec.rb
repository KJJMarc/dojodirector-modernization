require 'spec_helper'

describe Address do
  let(:line_1) { "Address Line 1" }
  let(:line_2) { "Address Line 2" }
  let(:postcode) { "EC1R 0JH" }
  let(:city) { "London" }

  subject(:address) do
    Address.new :line_1 => line_1, 
                :line_2 => line_2, 
                :postcode => postcode, 
                :city => city
  end

  it { should be_valid }
  
  context "with blank first line" do
    let(:line_1) { '' }
    it { should_not be_valid }
  end

  context "with blank second line" do
    let(:line_2) { '' }
    it { should be_valid }
  end

  context "without a postcode" do
    let(:postcode) { '' }
    it { should be_valid }
  end

  context "with invalid postcode" do
    let(:postcode) { 'H0H 0HO' }
    it { should be_valid }
  end

  context "with valid postcodes" do
    ['M1 1AA','B33 8TH', 'CR2 6XH', 'DN55 1PT', 'W1A 1HQ', 'EC1A 1BB'].each do |p_code|
      let(:postcode) { p_code }
      it { should be_valid }
    end
  end

  context "without a city" do
    let(:city) { '' }
    it { should be_valid }
  end
end
