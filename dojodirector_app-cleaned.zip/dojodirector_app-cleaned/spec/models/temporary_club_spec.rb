require 'spec_helper'

describe TemporaryClub do
  let(:name)                { "club" }
  let(:email)               { "club@club.com" }
  let(:user)                { create(:user) }
  let(:super_admin_count)   { 2 }

  subject do
    TemporaryClub.new(
      :name   => name,
      :email  => email,
      :user   => user
    )
  end

  before do
    ActionMailer::Base.deliveries.clear
    super_admin_count.times { create(:super_admin) }
  end

  it { should be_valid }

  context "without name" do
    let(:name) { nil }

    it { should_not be_valid }
  end

  context "without email" do
    let(:email) { nil }

    it { should_not be_valid }
  end

  it "sends email to super-admins after create" do
    subject.should_receive(:notify_super_admins)
    subject.save
  end

  it "sends proper number of emails to all super-admins after create" do
    subject.save
    ActionMailer::Base.deliveries.size.should == super_admin_count
  end

  it "sends email with proper body to all super-admins after create" do
    subject.save
    ActionMailer::Base.deliveries.first.body.
      should == "Temporary #{name} created club with email #{email}"
  end
end
