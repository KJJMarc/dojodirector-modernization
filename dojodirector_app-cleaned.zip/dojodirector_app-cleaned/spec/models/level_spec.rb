require 'spec_helper'

describe Level do
  let(:name) { nil }
  let(:club_type) { create(:club_type) }
  let(:image) { nil }
  let(:position) { nil }
  let(:level_group) { club_type.level_groups.build() }
  let(:weeks_to_achieve) { 1 }
  let(:times_to_achieve) { 1 }

  subject(:level) {
    club_type.levels.build(:name => name, :position => position, :image => image,
                           :level_group => level_group, :weeks_to_achieve => weeks_to_achieve,
                           :times_to_achieve => times_to_achieve)
  }

  context "without name" do
    it { should_not be_valid }
  end

  context "with name and club type but without image" do
    let(:name) { "level name" }
    it { should_not be_valid }
  end

  context "with invalid position" do
    let(:name)  { "club_name" }
    let(:image) { File.new(Rails.root.join('spec', 'assets', 'attachments', 'image.gif')) }
    let(:level_group) { create(:level_group, :club_type => club_type) }
    let(:position) { 1 }

    it "should not be valid" do
      create(:level, :position => 1, :level_group => level_group)
      level.should_not be_valid
    end
  end

  context "with valid data" do
    let(:name)  { "club_name" }
    let(:image) { File.new(Rails.root.join('spec', 'assets', 'attachments', 'image.gif')) }
    let(:level_group) { create(:level_group, :club_type => club_type) }
    let(:position) { 1 }

    it { should be_valid }

    context "number of times to achieve next level should valid" do
      let(:weeks_to_achieve) { 5 }
      it { should be_valid }
    end

    context "number of times to achieve next level should be integer" do
      let(:weeks_to_achieve) { 1.1 }
      it { should_not be_valid }
    end

    context "number of times to achieve next level should be > 0" do
      let(:weeks_to_achieve) { 0 }
      it { should_not be_valid }
    end
  end
end
