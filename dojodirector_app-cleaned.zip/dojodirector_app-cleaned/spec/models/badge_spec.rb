require 'spec_helper'

describe Badge do
  let(:name) { nil }
  let(:club_type) { create(:club_type) }
  let(:image) { nil }
  let(:description) { nil }

  subject(:badge) { club_type.badges.build(:name => name, :description => description, :image => image) }

  context "without name" do
    it { should_not be_valid }
  end

  context "with name and club type but without image" do
    let(:name) { "badge name" }
    it { should_not be_valid }
  end

  context "with name and club type and image" do
    let(:name)  { "club_name" }
    let(:image) { File.new(Rails.root.join('spec', 'assets', 'attachments', 'image.gif')) }

    it { should be_valid }
  end
end
