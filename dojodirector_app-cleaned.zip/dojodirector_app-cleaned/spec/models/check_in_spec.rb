require 'spec_helper'

describe CheckIn do
  let(:content) { nil }
  let(:user)    { nil }
  let(:club)    { nil }

  subject(:check_in) { build(:check_in, :content => content, :user => user, :club => club) }

  context "without any data" do
    it { should_not be_valid }
  end

  context "without club" do
    let(:content) { "Check in" }
    let(:user)    { create(:user) }
    it { should_not be_valid }
  end

  context "without user" do
    let(:content) { "Check in" }
    let(:club)    { create(:club) }
    it { should_not be_valid }
  end

  context "without content" do
    let(:club)    { create(:club) }
    let(:user)    { create(:user) }
    it { should_not be_valid }
  end

  context "with all data" do
    let(:club)    { create(:club) }
    let(:user)    { create(:user) }
    let(:content) { "Check in" }

    it { should be_valid }
  end

  it_behaves_like "feed item subject" do
    let(:feed_item_subject) { create(:check_in) }
  end
end
