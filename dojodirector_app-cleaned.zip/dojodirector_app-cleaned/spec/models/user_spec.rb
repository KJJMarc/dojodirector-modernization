require 'spec_helper'

describe User do
  let(:email)         { "example@example.com" }
  let(:password)      { "password" }
  let(:club)          { create(:club) }
  let(:username)      { "example1" }
  let(:first_name)    { "James" }
  let(:last_name)     { "Bond" }
  let(:date_of_birth) { Date.today }
  let(:gender)        { :male }
  let(:address)       { build(:address) }

  subject do
    User.create(
      :username              => username,
      :email                 => email,
      :password              => password,
      :password_confirmation => password,
      :first_name            => first_name,
      :last_name             => last_name,
      :date_of_birth         => date_of_birth,
      :gender                => gender,
      :address               => address
    )
  end

  it { should be_valid }

  it "has unique username" do
    taken = build(:user, :username => username)

    subject.should be_valid
    taken.should_not be_valid
    taken.errors.has_key?(:username)
  end

  it 'allows duplicate email' do
    taken = build(:user, :email => email)

    subject.should be_valid
    taken.should be_valid
  end

  it 'saves username with case sensitivity' do
    subject.username ='JamesBond'
    subject.save

    subject.reload.username.should eq 'JamesBond'
  end

  it 'should be case-insensitive on username uniqueness' do
    u = build(:user, :username => subject.username.upcase)

    u.should_not be_valid
    u.should have(1).errors_on(:username)
  end

  it "knows if it's active at club" do
    subject.active_at?(club).should be_false
    subject.clubs << club
    subject.active_at?(club).should be_true
  end

  it "knows if it's supsended at club" do
    subject.clubs << club
    subject.suspend(club)
    subject.active_at?(club).should be_false

    subject.unsuspend(club)
    subject.active_at?(club).should be_true
  end

  describe "address" do
    it "should be the same as address owner" do
      subject.address.owner.should == subject
    end

    it "should destroy address when it's destroyed" do
      address = subject.address
      subject.destroy

      Address.find_by_id(address).should be_nil
    end

    context "without a postcode" do
      let(:address) { build(:address, :postcode => nil) }
      it { should be_valid }
    end
  end

  context "gender" do
    let(:gender) { nil }

    it { should be_valid }

    describe "wrong gender" do
      let(:gender) { :wrong }

      it "should set gender as nil" do
        subject.gender.should be_nil
      end
    end

    describe "good gender" do
      let(:gender) { :female }

      it { should be_valid }
    end
  end

  context "date_of_birth" do
    let(:date_of_birth) { nil }

    it { should be_valid }
  end

  context "check level in club" do
    before do
      @member1 = create(:user)
      @member2 = create(:user)
      @club = create(:club)
      @level = create(:level, :club_type => club.club_type)
      @club.users << @member1
      @club.users << @member2
    end

    it "should return valid level" do
      @member1.current_level_in(@club).should be_nil
      @member2.current_level_in(@club).should be_nil

      @member1.set_level_in_club(@level, @club)

      @member1.current_level_in(@club).should eq(@level)
      @member2.current_level_in(@club).should be_nil
    end
  end

  describe "events" do
    let(:event) { create(:event) }
    let(:user)  { create(:user) }

    subject { user }

    before { user.events << event }

    context "non-approved attendance" do
      its(:events) { should_not be_blank }
      its("events.confirmed") { should be_blank }
    end

    context "approved attendance" do
      before { user.event_attendees.map(&:confirm) }

      its(:events) { should_not be_blank }
      its("events.confirmed") { should include(event) }
    end

    context "approved in last month" do
      let(:event) { create(:event, :scheduled_at => Date.today.months_ago(1)) }

      before { user.event_attendees.map(&:confirm) }

      its(:events) { should include(event) }
      its("events.confirmed") { should include(event) }
    end
  end

  context "roles" do
    let(:club)  { create(:club) }
    let(:user) { create(:user) }
    let(:admin) { create(:admin) }
    let(:super_admin) { create(:super_admin) }
    let(:new_member) do
      user = create(:user)
      club.users << user
      user
    end
    let(:suspended_member) do
      user = create(:user)
      club.users << user
      user.suspend(club)
      user
    end

    it "user should have unknown role" do
      user.role.should == "None"
      new_member.role.should == "None"
      suspended_member.role.should == "None"
    end

    it "admin should have admin role" do
      admin.role.should == "Admin"
    end

    it "super-admin should have super-admin role" do
      super_admin.role.should == "Super admin"
    end
  end

  context "admin role" do
    let(:user)    { create(:user) }
    let(:club)    { create(:club) }
    let(:club_2)  { create(:club) }

    it "member and admin" do
      user.add_role :admin, club

      user.roles.map(&:name).sort.should == ["admin"]
    end

    it "admin => super_admin" do
      user.add_role :admin, club
      user.add_role :super_admin

      user.roles.map(&:name).sort.should == ["admin","super_admin"]
    end

    it "two admins" do
      user.add_role :admin, club
      user.add_role :admin, club_2

      user.roles.map(&:name).should == (["admin"] * 2)
    end

    it "super_admin" do
      user.add_role :admin, club
      user.add_role :admin, club_2
      user.add_role :super_admin

      user.roles.map(&:name).should == (["admin"]*2) + ["super_admin"]
    end

    it "super_admin => admin" do
      user.add_role :super_admin
      user.add_role :admin, club

      user.roles.map(&:name).sort.should == ["admin", "super_admin"]
    end

    it "super_admin => admin => admin" do
      user.add_role :super_admin
      user.add_role :admin, club
      user.add_role :admin, club_2

      user.roles.map(&:name).sort.should == ((["admin"] * 2) + ["super_admin"])
    end
  end
end
