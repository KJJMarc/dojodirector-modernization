require 'spec_helper'

describe Attendance do
  let(:user) { create(:user) }
  let(:club) { create(:club) }
  let(:attendance) { create(:attendance, :user => user, :club => club) }

  before do
    attendance
  end

  describe "toggling" do
    it "removes existing attendance if we want to remove and it exists" do
      expect {
        user.attendances.at_club(club).toggle(attendance.date, false)
      }.to change { user.attendances.count }.by(-1)
    end

    it "does nothing if we want to create attendance when it exists" do
      expect {
        user.attendances.at_club(club).toggle(attendance.date, true)
      }.to_not change { user.attendances.count }
    end

    it "does nothing if we want to remove attendance when it doesn't exists" do
      date = attendance.date + 1.day
      expect {
        user.attendances.at_club(club).toggle(date, false)
      }.to_not change { user.attendances.count }
    end

    it "creates attendances when it doesn't exist" do
      date = attendance.date + 1.day
      expect {
        user.attendances.at_club(club).toggle(date, true)
      }.to change { user.attendances.count }.by(1)
    end
  end
end
