require 'spec_helper'

describe Message do
  let(:user) { create(:user) }

  it "user can't send message to himself" do
    message = user.send_message(user, "topic", "body")
    message.should_not be_valid
  end
end
