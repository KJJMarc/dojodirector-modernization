require 'spec_helper'

describe ClubType do
  let(:type) { nil }

  subject { ClubType.new(:type_name => type) }

  it { should_not be_valid }

  context "with type" do
    let(:type) { "Type" }

    it { should be_valid }
  end
end
