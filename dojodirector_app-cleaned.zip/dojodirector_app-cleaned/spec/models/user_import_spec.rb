require 'spec_helper'

describe UserImport do
  describe "preparing attributes from csv row" do
    let(:row) { {"gender" => true} }
    subject { UserImport.new.send(:prepare_attributes_from_csv_row, row) }

    it "returns proper gender" do
      should include("gender" => true)
    end

    describe "regular attribute" do
      let(:row) { { "first_name" => true } }

      it "return proper regular attribute" do
        should include("first_name" => true)
      end
    end

    describe "address attribute" do
      let(:row) { { "address_line_1" => "Some address" } }
      it "includes user address attributes" do
        should include(:address_attributes)
      end
    end

    describe "optional fields" do
      let(:row) { { "another_field" => true } }

      it "return optional fields as hash" do
        should include(:extra_information => {"another_field" => true})
      end
    end
  end

  describe "fixing file encoding" do
    let(:contents) {  File.read(Rails.root.join('spec', 'assets', 'attachments', 'broken_encoding_csv.csv')) }

    it "should allow CSV to open the file" do

      expect { CSV.parse(contents) }.to raise_error(ArgumentError)

      fixed_contents = UserImport.fix_encoding contents
      # will not rais exception
      CSV.parse(fixed_contents)
    end
  end
end
