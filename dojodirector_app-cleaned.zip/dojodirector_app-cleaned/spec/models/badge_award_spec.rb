require 'spec_helper'

shared_examples "multi user badge" do
  it "creates new badge for user" do
    expect {
      BadgeAward.new(club, badge, params).award!
    }.to change { UserBadge.count }.by(1)
  end

  context "badge award" do
    before { BadgeAward.new(club, badge, params).award! }

    it "new user_badge is associated to badge" do
      user.reload.badges.last.should == badge
    end

    it "does not create feed item for user" do
      FeedItem.where(:user_id => user, :subject_id => UserBadge.last).count.should be_equal(0)
    end

    it "should create global feed item" do
      group_badge = GroupBadge.find_by_badge_id(badge)
      group_badge.feed_items.count.should be_equal(1)
    end

    it "should have custom message" do
      user.reload.user_badges.last.title.should == message
    end

    it "should mark proper notify option" do
      user.reload.user_badges.last.notify.should == notify
    end
  end
end

describe BadgeAward do
  before { ActiveRecord::Observer.enable_observers }
  after  { ActiveRecord::Observer.disable_observers }

  let(:club)          { create(:club, :club_type => club_type) }
  let(:club_type)     { create(:club_type) }
  let(:user)          { club.users.first }
  let(:badge)         { create(:badge) }
  let(:message)       { nil }
  let(:notify)        { false }

  context "level" do
    let!(:level)        { create(:level, :level_group => level_group, :club_type => club_type) }
    let!(:level_group)  { create(:level_group, :club_type => club_type) }
    let!(:user_level)   { UserLevel.create(:user => user, :level => level, :club => club) }
    let(:params)        { { :for => 'all_from_group', :level => level.id } }

    it_behaves_like "multi user badge"

    context "when there is a user with same level in another club" do
      let!(:another_club) { create(:club, :club_type => club_type) }
      let!(:another_user)          { another_club.users.first }
      let!(:another_user_level)   { UserLevel.create(:user => another_user, :level => level, :club => another_club) }

      it "does not create badge for user from another club" do
        expect {
          BadgeAward.new(club, badge, params).award!
        }.to_not change { another_user.badges.count }
      end
    end

    context "when same level awarded more than once" do
      let!(:user_level_2)   { UserLevel.create(:user => user,
                                               :level => level,
                                               :club => club,
                                               :awarded_at => 1.week.ago) }

      it "creates exactly one badge for user" do
        expect {
          BadgeAward.new(club, badge, params).award!
        }.to change { UserBadge.count }.by(1)
      end
    end
  end

  context "event" do
    let(:event)   { create(:event, :club => club) }
    let(:params)  { { :for => 'all_from_event', :event => event.id } }

    before do
      event.attendees << user
      user.event_attendees.map(&:confirm)
    end

    it_behaves_like "multi user badge"
  end

  context "club" do
    let(:message) { "Message" }
    let(:params) { { :for => 'all_members', :message => message } }
    before { user.add_role :member, club }

    it_behaves_like "multi user badge"
  end

  context "message" do
    let(:message) { "Message" }
    let(:params) { { :for => 'all_members', :message => message } }

    it_behaves_like "multi user badge"
  end

  context "notify" do
    let(:notify) { true }
    let(:params) { { :for => 'all_members', :notify => notify } }

    it_behaves_like "multi user badge"

    it "notify users about new badge" do
      User::Notifier.should_receive(:new_badge).at_least(1).and_return(stub(:deliver => nil))
      BadgeAward.new(club, badge, params).award!
    end

    context "notify off" do
      let(:notify) { false }

      it "should not notify users about new badge" do
        User::Notifier.should_not_receive(:new_badge)
        BadgeAward.new(club, badge, params).award!
      end
    end
  end
end
