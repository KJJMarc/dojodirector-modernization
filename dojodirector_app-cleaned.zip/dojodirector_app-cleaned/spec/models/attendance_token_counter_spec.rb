require 'spec_helper'

describe AttendanceTokenCounter do
  let(:club) { create(:club) }
  let(:user) { create(:user) }

  def token_counter
    AttendanceTokenCounter.new(user, club)
  end

  context "without any attendances nor levels" do
    it "returns false when asked about new level" do
      token_counter.should_not be_new_level
    end

    it "is not enabled" do
      token_counter.should_not be_enabled
    end
  end

  context "without current but with next level being set up" do
    let(:level_group) { create(:level_group, :club_type => club.club_type) }
    let(:level) { create(:level, :club_type => club.club_type,
                     :level_group => level_group,
                     :times_to_achieve => 1,
                     :weeks_to_achieve => 1)
    }

    before do
      level
    end

    it "is enabled" do
      token_counter.should be_enabled
    end

    it "returns false when asked about new level" do
      token_counter.should_not be_new_level
    end

    context "with an attendance in club" do
      before do
        create(:attendance, :user => user, :club => club)
      end

      it "is enabled" do
        token_counter.should be_enabled
      end

      it "returns true when asked about new level" do
        token_counter.should be_new_level
      end
    end

    context "with event attended in club" do
      before do
        event = create(:event, :club => club)
        att = create(:event_attendee, :user => user, :event => event)
        att.confirm
      end

      it "returns true when asked about new level" do
        token_counter.should be_new_level
      end
    end

    context "with existing level awarded 2 weeks ago" do
      before do
        create(:user_level, :user => user, :club => club, :level => level,
               :awarded_at => 2.weeks.ago)
      end

      it "is not enabled because there is no next level set up" do
        token_counter.should_not be_enabled
      end

      context "with next level with higher requirements set up" do
        let(:next_level) { create(:level, :level_group => level_group,
                 :club_type => club.club_type,
                 :weeks_to_achieve => 2,
                 :times_to_achieve => 2)
        }

        before do
          next_level
        end

        it "is enabled" do
          token_counter.should be_enabled
        end

        it "does not indicate new level" do
          token_counter.should_not be_new_level
        end

        it "has number of tokens equal to 0" do
          token_counter.tokens.should == 0
        end

        context "with event attended in club" do
          before do
            event = create(:event, :club => club, :start_date => 13.days.ago.to_date)
            att = create(:event_attendee, :user => user, :event => event)
            att.confirm
          end

          it "returns false when asked about new level" do
            token_counter.should_not be_new_level
          end

          it "has number of tokens equal to 0" do
            token_counter.tokens.should == 0
          end

          context "with one more attendance in first of these two weeks" do
            before do
              create(:attendance, :user => user, :club => club, :date => 13.days.ago.to_date)
            end
            
            it "returns false when asked about new level" do
              token_counter.should_not be_new_level
            end

            it "has number of tokens equal to 1" do
              token_counter.tokens.should == 1
            end

            context "and one more event and attendance in the following week" do
              before do
                event = create(:event, :club => club, :start_date => 1.day.ago.to_date)
                att = create(:event_attendee, :user => user, :event => event)
                att.confirm

                create(:attendance, :user => user, :club => club, :date => 1.day.ago.to_date)
              end

              it "has number of tokens equal to 2" do
                token_counter.tokens.should == 2
              end

              it "returns true when asked about new level" do
                token_counter.should be_new_level
              end

              context "when new level is awarded" do
                before do
                  create(:level, :level_group => level_group,
                         :club_type => club.club_type,
                         :weeks_to_achieve => 2,
                         :times_to_achieve => 2, :name => "YEt another level")

                  create(:user_level, :user => user, :club => club, 
                         :level => next_level,
                         :awarded_at => Time.now)

                end

                it "has number of tokens equal to 0" do
                  token_counter.tokens.should == 0
                end

                it "returns false when asked about new level" do
                  token_counter.should_not be_new_level
                end
              end
            end
          end
        end
      end
    end
  end
end
