require 'spec_helper'

describe FeedItem do
  it "is not valid without club" do
    item = build(:feed_item, :club => nil)
    item.should_not be_valid
  end

  it "is not valid without subject" do
    item = build(:feed_item, :subject => nil)
    item.should_not be_valid
  end

  it "is not valid with invalid action" do
    item = build(:feed_item, :action => "crazy_thing_happenned")
    item.should_not be_valid
  end
end
