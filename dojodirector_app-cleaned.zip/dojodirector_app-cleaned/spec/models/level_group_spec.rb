require 'spec_helper'

describe LevelGroup do
  let(:name) { nil }
  let(:club_type) { create(:club_type) }
  let(:position) { nil }

  subject(:level_group) { club_type.level_groups.build(:name => name, :position => position) }

  context "without name" do
    it { should_not be_valid }
  end

  context "with valid data" do
    let(:name) { "group level name" }
    let(:position) { 1 }

    it { should be_valid }
  end

  context "with invalid position" do
    let(:name)  { "club_name" }
    let(:position) { 1 }

    it "should not be valid" do
      create(:level_group, :position => 1)
      should_not be_valid
    end
  end

  context "sort group levels with specific order" do
    before do
      @level_group1 = create(:level_group, :position => 1)
      @level_group2 = create(:level_group, :position => 2)
      @level_group3 = create(:level_group, :position => 3)
    end

    it "should be ok with array of ids" do
      LevelGroup.update_positions!(
        [@level_group3.id , @level_group1.id, @level_group2.id]
      )

      @level_group3.reload.position.should eq(1)
      @level_group2.reload.position.should eq(3)
      @level_group1.reload.position.should eq(2)
    end

    it "should not change position of groups with empty array" do
      LevelGroup.update_positions!([])

      @level_group3.reload.position.should eq(3)
      @level_group2.reload.position.should eq(2)
      @level_group1.reload.position.should eq(1)
    end
  end

  context "sort levels within group" do
    before do
      @level1 = create(:level, :position => 1, :club_type => club_type,
                                   :level_group => level_group)
      @level2 = create(:level, :position => 2, :club_type => club_type,
                                   :level_group => level_group)
      @level3 = create(:level, :position => 3, :club_type => club_type,
                                   :level_group => level_group)
    end

    it "should be ok with array of ids" do
      level_group.update_levels_positions!([@level3.id, @level1.id, @level2.id])

      @level3.reload.position.should eq(1)
      @level2.reload.position.should eq(3)
      @level1.reload.position.should eq(2)
    end

    it "should not change position of groups with empty array" do
      level_group.update_levels_positions!([])

      @level3.reload.position.should eq(3)
      @level2.reload.position.should eq(2)
      @level1.reload.position.should eq(1)
    end
  end
end
