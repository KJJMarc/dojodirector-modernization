require 'spec_helper'

describe UserBadge do
  let(:user)  { create(:user) }
  let(:badge) { create(:badge) }
  let(:club)  { create(:club) }

  before do
    ActionMailer::Base.deliveries.clear
    UserBadge.create(:badge => badge, :user => user, :club => club)
  end

  it "send email after create user badge" do
    ActionMailer::Base.deliveries.should_not be_empty
  end

  it "should include club name" do
    ActionMailer::Base.deliveries.first.body.should include(club.name)
  end

  it "should include profile url with badge id" do
    ActionMailer::Base.deliveries.first.body.should include(Rails.application.routes.url_helpers.user_profile_path(user, :badge_id => badge.id))
  end

  it_behaves_like "feed item subject" do
    let(:feed_item_subject) { create(:user_badge) }
  end
end
