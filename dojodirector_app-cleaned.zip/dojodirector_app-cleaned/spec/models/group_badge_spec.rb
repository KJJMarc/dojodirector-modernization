require 'spec_helper'

describe GroupBadge do
  it { should validate_presence_of(:subject) }
  it { should validate_presence_of(:badge) }
end
