require 'spec_helper'

describe ClubProfile do
  let(:club) { create(:club, :address => nil) }  
  let(:club_profile) { ClubProfile.new(club) }

  it "is not complete for blank club" do
    club_profile.should_not be_complete
    club_profile.should be_incomplete
    club_profile.show_reminder?.should == true
  end

  it "does not show reminder if it was dismissed recently" do
    club.completeness_reminder_dismissed_at = 2.minutes.ago
    club_profile.show_reminder?.should be_false

    club.completeness_reminder_dismissed_at = (1.hour + 1.minute).ago
    club_profile.show_reminder?.should be_true
  end

  it "knows it's missing fields" do
    club_profile.missing_fields.should =~ 
      ["Address", "Telephone","Twitter","Facebook"]
  end

  context "with some fields added" do
    it "should not include these fields as incomplete" do
      club.phone_number = "0123282832"
      club_profile.should_not be_complete
      club_profile.missing_fields.should_not =~ 
        ["Telephone"]
    end
  end

  context "with all required fields added" do
    it "should be complete" do
      club.phone_number = "0123282832"
      club.twitter_url = "twitter"
      club.facebook_url = "facebook"
      club.address = build(:address)

      club_profile.should be_complete
      club_profile.missing_fields.should == []
    end
  end
end
