require 'spec_helper'

describe EventAttendee do
  let(:club)            { create(:club, :club_type => club_type) }
  let(:club_type)       { create(:club_type, :token_criteria => true) }
  let(:event)           { create(:event, :club => club) }
  let(:event_2)         { create(:event, :club => club) }
  let(:user)            { create(:user) }
  let(:event_attendee)  { create(:event_attendee, :event => event) }
  let(:level)           { create(:level, :club_type => club.club_type, :level_group => level_group) }
  let(:level_group)     { create(:level_group, :club_type => club.club_type) }

  before { level }

  subject { event_attendee }

  it { should be_valid }

  describe "confirmed" do
    its(:confirmed) { should be_false }

    context "confirmed" do
      before { subject.confirm }

      its(:confirmed) { should be_true }
    end
  end

  describe "uniqueness" do
    let(:event_attendee) { create(:event_attendee, :user => user, :event => event) }
    let(:event_attendee_duplicate) { event_attendee.dup }

    it "does not allow to create user attended two times to the same event" do
      event_attendee_duplicate.should_not be_valid
    end
  end
end
