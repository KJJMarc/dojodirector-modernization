require 'spec_helper'

describe FeedObserver do
  it "creates feed item when observed item is created" do
    ActiveRecord::Observer.with_observers(:feed_observer) do
      expect {
        create(:user_level)
      }.to change{ FeedItem.count }.by(1)
      
      FeedItem.last.subject.should == UserLevel.last
    end
  end
end
