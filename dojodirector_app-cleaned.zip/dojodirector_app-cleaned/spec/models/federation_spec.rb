require 'spec_helper'

describe Federation do
  let(:name)      { "federation" }
  let(:club_type) { create(:club_type) }

  subject { Federation.new(:name => name, :club_type => club_type) }

  it { should be_valid }

  context "without name" do
    let(:name) { nil }

    it { should_not be_valid }
  end

  context "without club type" do
    let(:club_type) { nil }

    it { should_not be_valid }
  end

  context "invalid club_type" do
    let(:club_type) { ClubType.new }

    it { should_not be_valid }
  end

end
