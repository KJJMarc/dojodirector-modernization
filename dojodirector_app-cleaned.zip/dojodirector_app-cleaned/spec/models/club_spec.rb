require 'spec_helper'

describe Club do
  let(:name) { "club_name" }
  let(:club_type) { build(:club_type) }
  let(:twitter_url) { "https://twitter.com/prowd" }
  let(:statement) { "statement for the club" }

  subject(:club) do
    Club.new(
      :name         => name,
      :club_type    => club_type,
      :twitter_url  => twitter_url,
      :statement    => statement
    )
  end

  it { should be_valid }

  context "without name" do
    let(:name) { nil }
    it { should_not be_valid }
  end

  context "with invalid club type" do
    let(:club_type) { ClubType.new }
    it { should_not be_valid }
  end

  context "with statement too long" do
    let(:statement) { "a word" * 20 }
    it { should_not be_valid }
  end

  context "without club type" do
    let(:club_type) { nil }
    it { should_not be_valid }
  end

  context "with invalid twitter url" do
    let(:twitter_url) { "htt_p://invalid" }
    it { should_not be_valid }
  end

  context "with blank twitter url" do
    let(:twitter_url) { nil }
    it { should be_valid }
  end

  context "club next level" do
    let(:user)          { create(:user) }
    let(:club)          { create(:club) }
    let(:club_type)     { club.club_type }
    let(:level_group_1) { create(:level_group, :position => 1, :club_type => club_type) }
    let(:level_group_2) { create(:level_group, :position => 2, :club_type => club_type) }
    let(:first_level)   { level_group_1.levels.first }
    let(:sec_level)     { level_group_1.levels.last }
    let(:third_level)   { level_group_2.levels.first }
    let(:fourth_level)  { level_group_2.levels.last }

    before do
      club.users << user
      user.add_role :member, club

      2.times do |n|
        create(:level, :level_group => level_group_1, :position => n)
        create(:level, :level_group => level_group_2, :position => n)
      end
    end

    it "club should return first level" do
      club.next_level.should == first_level
    end

    it "club should return sec level" do
      club.next_level(first_level).should == sec_level
    end

    it "club should return level from next level group" do
      club.next_level(sec_level).should == third_level
    end

    it "club should return last level" do
      club.next_level(third_level).should == fourth_level
    end

    it "clubs should once again return last level" do
      club.next_level(fourth_level).should_not == fourth_level
    end
  end

  context "uniqueness of users in club" do
    let(:user) { create(:user) }
    let(:club) { create(:club) }

    it "one user in club" do
      lambda {
        club.users << user
      }.should_not raise_error(ActiveRecord::RecordInvalid)
    end

    it "the same user in club" do
      lambda {
        2.times { club.users << user }
      }.should raise_error(ActiveRecord::RecordInvalid)
    end
  end

  describe "most popular badges" do
    let(:popular_badge) { create(:badge, :club_type => club.club_type) }
    let(:popular_custom_badge) { create(:badge, :club => club) }

    before do
      3.times do
        create(:user_badge, :badge => popular_badge, :club => club)
      end

      2.times do
        create(:user_badge, :badge => popular_custom_badge, :club => club)
      end

      #unpopular badge
      create(:badge, :club => club)
    end

    it "returns badges that were awarded most often" do
      two_most_popular = club.most_popular_badges(2)
      two_most_popular.should == [popular_badge, popular_custom_badge]
      two_most_popular.first.award_count.to_i.should == 3
    end
  end
end
