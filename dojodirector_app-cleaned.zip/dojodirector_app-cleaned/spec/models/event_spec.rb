require 'spec_helper'

describe Event do
  let(:name)         { "Event name" }
  let(:event_type)   { "single" }
  let(:club)         { create(:club) }
  let(:description)  { "Description" }
  let(:youtube_id)   { "YXX3lztmPFo" }
  let(:start_date)   { Date.current.strftime("%d/%m/%Y") }
  let(:start_time)   { Time.now.strftime("%H:%M") }
  let(:end_time)   { (Time.now + 2.hours).strftime("%H:%M") }
  let(:scheduled_at) { Time.now }

  subject(:event) { build(:event, :name => name, :description => description,
                          :club => club, :youtube_id => youtube_id,
                          :start_date => start_date, :start_time => start_time,
                          :end_time => end_time, :scheduled_at => scheduled_at) }

  context "without name" do
    let(:name) { nil }
    it { should_not be_valid }
  end

  context "without club" do
    let(:club) { nil }
    it { should_not be_valid }
  end

  context "without youtube_id" do
    let(:youtube_id) { nil }
    it { should be_valid }
  end

  context "with invalid youtube_id" do
    let(:youtube_id) { "wrong id" }
    it { should_not be_valid }
  end

  context "without description" do
    let(:description) { nil }
    it { should be_valid }
  end

  context "without start_date and without scheduled_at" do
    let(:start_date) { nil }
    let(:scheduled_at) { nil }
    it { should_not be_valid }
  end

  context "without start_time and without scheduled_at" do
    let(:start_time) { nil }
    let(:scheduled_at) { nil }
    it { should_not be_valid }
  end

  context "without end_at and without end_time" do
    let(:end_at) { nil }
    let(:end_time) { nil }
    it { should_not be_valid }
  end

  context "period_events" do
    let(:current_time)      { Time.now }
    let(:first_event_time)  { current_time + 10.days }
    let(:sec_event_time)    { current_time + 20.days }
    let(:start_time)        { Time.now.strftime("%H:%M") }

    before do
      @first_event  = create(:event, :start_date => first_event_time.to_s,
                             :start_time => start_time)
      @sec_event    = create(:event, :start_date => sec_event_time.to_s,
                             :start_time => start_time)
    end

    it "does not find any events" do
      events = Event.period_events(current_time, first_event_time - 1.days)
      events.should be_blank
    end

    it "finds only first event" do
      events = Event.period_events(first_event_time - 5.days, first_event_time + 5.days)
      events.should     include(@first_event)
      events.should_not include(@sec_event)
    end

    it "finds only sec event" do
      events = Event.period_events(first_event_time + 1.days, sec_event_time + 5.days)
      events.should     include(@sec_event)
      events.should_not include(@first_event)
    end

    it "finds all events" do
      events = Event.period_events(first_event_time - 5.days, sec_event_time + 5.days)
      events.should include(@first_event, @sec_event)
    end
  end

  context "monthly_events" do
    let(:previous_month)      { Time.now.beginning_of_month - 1.days }
    let(:next_month)          { Time.now.end_of_month + 1.days }
    let(:middle_of_the_month) { Time.now.beginning_of_month + 10.days }
    let(:start_time)          { Time.now.strftime("%H:%M") }

    before do
      @event_in_this_month = create(:event, :start_date => middle_of_the_month.to_s,
                                    :start_time => start_time)
      @event_in_next_month = create(:event, :start_date => next_month.to_s,
                                    :start_time => start_time)
    end

    it "does not find any event in previous month" do
      events = Event.monthly_events(previous_month)
      events.should be_blank
    end

    it "finds event in this month" do
      events = Event.monthly_events(middle_of_the_month)
      events.should     include(@event_in_this_month)
      events.should_not include(@event_in_next_month)
    end

    it "finds event in next month" do
      events = Event.monthly_events(next_month)
      events.should     include(@event_in_next_month)
      events.should_not include(@event_in_this_month)
    end
  end

  context "daily_events" do
    let(:event_day)         { Date.current }
    let(:day_after_event)   { Date.tomorrow }
    let(:event_time)        { (Time.now).strftime("%H:%M") }

    before do
      @today_event = create(:event, :start_date => event_day.to_s,
                                    :start_time => event_time)
    end

    it "does not find events" do
      events = Event.daily_events(Date.tomorrow)
      events.should be_blank
    end

    it "finds event" do
      events = Event.daily_events(Date.current)
      events.should include(@today_event)
    end
  end

  context "attend" do
    let(:event) { create(:event) }
    let(:user)  { create(:user) }

    it "does not include user on attendees list" do
      event.attendees.should_not include(user)
    end

    it "adds user to event attendants" do
      event.attend(user)
      event.attendees.should include(user)
    end

    it "removes user from event attendants" do
      event.attend(user)
      event.unattend(user)
      event.attendees.should_not include(user)
    end

    it "returns true if user attend to event" do
      event.attend(user)
      event.attending?(user).should be_true
    end

    it "returns false if user does not attend to event" do
      event.attending?(user).should be_false
    end
  end
end
