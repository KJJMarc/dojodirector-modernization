require 'spec_helper'

describe Announcement do
  let(:title) { "title" }
  let(:body) { "body" }
  subject { Announcement.new(:body => body, :title => title) }

  it { should be_valid }

  context "without body" do
    let(:body) { nil }

    it { should_not be_valid }
  end

  context "without title" do
    let(:title) { nil }

    it { should_not be_valid }
  end

end
