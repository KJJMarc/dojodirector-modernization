require 'spec_helper'

describe UserLevel do
  let(:level) { create(:level) }
  let(:user)  { create(:user) }
  let(:club)  { create(:club) }

  before do
    ActionMailer::Base.deliveries.clear
    UserLevel.create(:level => level, :user => user, :club => club)
  end

  it "send email after create" do
    ActionMailer::Base.deliveries.should_not be_empty
  end

  it "should include level name" do
    ActionMailer::Base.deliveries.first.body.should include(level.name)
  end

  it "should include club name" do
    ActionMailer::Base.deliveries.first.body.should include(club.name)
  end

  it "should include profile url" do
    ActionMailer::Base.deliveries.first.body.should
      include(Rails.application.routes.url_helpers.user_profile_path(user))
  end

  it_behaves_like "feed item subject" do
    let(:feed_item_subject) { create(:user_level) }
  end
end
