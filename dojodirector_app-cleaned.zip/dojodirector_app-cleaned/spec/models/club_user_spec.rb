require 'spec_helper'

describe ClubUser do
  let(:user) { nil }
  let(:club) { nil }

  subject { ClubUser.new(:user => user, :club => club) }

  it { should_not be_valid }

  context "with user" do
    let(:user) { create(:user) }

    it { should_not be_valid }
  end

  context "with club" do
    let(:club) { create(:club) }

    it { should_not be_valid }
  end

  context "with user and club" do
    let(:user) { create(:user) }
    let(:club) { create(:club) }

    it { should be_valid }
  end
end
