require 'acceptance/acceptance_helper'

feature 'Admin event level feature' do
  let(:club_type)     { create(:club_type) }
  let(:club)          { create(:club, :club_type => club_type) }
  let(:user)          { create(:user) }
  let!(:user_level)   { UserLevel.create(:user => user, :level => level, :club => club) }
  let!(:level_group)  { create(:level_group, :club_type => club_type) }
  let!(:level)        { create(:level, :level_group => level_group, :club_type => club_type) }

  background do
    as_user(user)
    club.users << user
    user.add_role(:member, club)
    user.add_role(:admin, club)
    UserLevel.create(:user => user, :level => level, :club => club)
    visit admin_venue_events_path(club)
  end

  scenario 'admin should see levels on event create' do
    click_link "Add event"
    page.should have_content(level.name)
  end

  scenario 'admin should able to select level', :js => true do
    click_link "Add event"
    within('#content') {click_link "Change"}
    page.should have_content "Select members (0 selected)".upcase
    check level.name
    page.should have_content "Select members (1 selected)".upcase
  end

  context "create event collection", :js => true do
    background do
      click_link "Add event"
      click_link "Recurring event"
      check level.name
      fill_in "Name", :with => "Single Event"
      fill_in "Description", :with => "Single event description"
      fill_in "Start date", :with => Date.today.strftime("%d/%m/%Y")
      fill_in "End date", :with => (Date.today + 10.days).strftime("%d/%m/%Y")
      select "12:00", :from => "Start time"
      select "14:00", :from => "End time"
      check "Monday"
      check "Friday"

      click_button "Create"
    end

    scenario 'admin should create event collection with levels' do
      page.should have_content "Event collection was successfully created.".upcase
      EventCollection.last.events.last.levels.should include(level)
    end
  end

  context "create event", :js => true do
    background do
      click_link "Add event"
      check level.name

      fill_in "Name", :with => "Single Event"
      fill_in "Description", :with => "Single event description"
      fill_in "Start date", :with => Date.today.strftime("%d/%m/%Y")
      select "12:00", :from => "Start time"
      select "14:00", :from => "End time"

      click_button "Create"
    end

    scenario 'admin create event with level' do
      page.should have_content "Event was successfully created.".upcase
      Event.last.levels.should include(level)
    end

    scenario 'admin should see event levels', :js => true do
      within("#calendar") do
        click_calendar_day(Date.today.strftime("%e").strip)
      end
      find(".calendarEvent").click

      page.should have_content("#{level.name}")
    end

    scenario 'clone event', :js => true do
      within("#calendar") do
        click_calendar_day(Date.today.strftime("%e").strip)
      end
      find(".calendarEvent").click

      page.should have_content("#{level.name}")
      click_link "Clone"
      lambda {
        click_button "Create"
        page.should have_content "Event was successfully created".upcase
      }.should change(Event, :count).by(1)
    end

    scenario 'event levels should be visible on event page' do
      page.should have_content "Event was successfully created.".upcase
      visit club_event_path(club.id, Event.last.id)
      page.should have_content("#{level.name}")
    end

    scenario 'admin should see checked levels in update page' do
      within("#calendar") do
        click_calendar_day(Date.today.strftime("%e").strip)
      end
      find(".calendarEvent").click
      within('.action') do
        click_link "Edit"
      end

      within('#content') {click_link 'Change'}
      find("#level_id_#{level.id}").should be_checked
      page.should have_content "Select members (1 selected)".upcase
    end

    scenario 'admin should see checked group checkbox', :js => true do
      within("#calendar") do
        click_calendar_day(Date.today.strftime("%e").strip)
      end
      find(".calendarEvent").click
      within('.action') do
        click_link "Edit"
      end

      find("#level_id_#{level.id}").should be_checked
      find("#level_group_#{level_group.id}").should be_checked
    end
  end
end
