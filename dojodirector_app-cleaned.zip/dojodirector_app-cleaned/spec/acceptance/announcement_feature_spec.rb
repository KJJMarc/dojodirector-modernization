require 'acceptance/acceptance_helper'

feature 'Announcement feature' do
  let(:admin)         { create(:user) }
  let(:club)          { create(:club) }
  let(:announcement)  { create(:announcement, :club => club) }
  let(:title)         { "Please read this" }
  let(:body)          { "Very important announcement" }
  let(:another_body)  { "Other body" }

  background do
    announcement
    club.users << admin
    admin.add_role :admin, club
    as_user(admin)
    visit admin_venue_announcements_path(club)
  end

  scenario 'admin of club should able to create new announcement' do
    page.click_link "Create announcement"
    fill_in "Title", :with => title
    fill_in "Content", :with => body
    click_button "Create"
    page.should have_content(body)
  end

  scenario 'admin should able to edit announcement' do
    page.should have_content(announcement.body)
    click_link announcement.title

    within('.action') do
      click_link "Edit"
    end

    fill_in "Title", :with => "anything else"
    fill_in "Content", :with => another_body
    click_button "Update"
    announcement.reload.title.should == "anything else"
    page.should have_content(another_body)
  end

  scenario 'admin should able to destroy announcement' do
    page.should have_content(announcement.body)
    within("table#announcement") do
      click_link announcement.title
    end
    click_link "Destroy"
    page.should_not have_content(announcement.body)
  end

  scenario 'announcement should be visible on club page' do
    visit club_path(club)
    page.should have_content("Recent announcements")
    page.should have_content(announcement.title)
  end
end
