require 'acceptance/acceptance_helper'

feature 'Group message' do
  let(:club)        { create(:club, :club_type => club_type) }
  let(:eve)         { create(:user, :email => email) }
  let(:user)        { create(:user) }
  let(:suspended)   { create(:user) }
  let(:club_type)   { create(:club_type) }
  let(:level)       { create(:level, :club_type => club_type, :level_group => level_group) }
  let(:level_2)     { create(:level, :club_type => club_type, :level_group => level_group) }
  let(:level_group) { create(:level_group, :club_type => club_type) }
  let(:email)       { "eve@example.com" }
  let(:topic)       { "Topic" }
  let(:body)        { "Body" }

  background do
    club.users << [user, eve, suspended]
    user.add_role :admin, club
    suspended.add_role :suspended_member, club

    UserLevel.create(:user => eve, :club => club, :level => level)
    UserLevel.create(:user => suspended, :club => club, :level => level_2)
    level_2
    as_user(user)
  end

  scenario 'admin should see level group and level', :js => true do
    visit new_admin_venue_message_path(club)
    within('#content') {click_link 'Change'}
    page.should have_content level_group.name.upcase
    page.should have_content level.name.upcase
    page.should have_content level_2.name.upcase
  end

  context "checkbox filter" do
    background do
      visit new_admin_venue_message_path(club)
      within('#content') {click_link 'Change'}
    end

    scenario 'admin should see 0 selected users before checked checkbox' do
      page.should have_content("0 selected")
    end

    scenario 'admin should see 1 selected after check proper level', :js => true do
      page.find(:xpath, "//label[@for='level_id_#{level.id}']").click
      page.should have_content "1 selected".upcase
    end

    scenario 'admin should see 0 selected after check wrong level', :js => true do
      page.find(:xpath, "//label[@for='level_id_#{level_2.id}']").click
      page.should have_content "0 selected".upcase
    end

    scenario 'admin check level group and all level in group should be selected', :js => true do
      page.find(:xpath, "//label[@for='level_group_#{level_group.id}']").click
      find("#level_id_#{level.id}").should be_checked
      find("#level_id_#{level_2.id}").should be_checked
    end

    scenario "admin check suspended checkbox", :js => true do
      page.find(:xpath, "//label[@for='level_id_#{level_2.id}']").click
      page.find(:xpath, "//label[@for='include_suspended']").click
      page.should have_content "1 selected".upcase
    end
  end

  context "send message" do
    background do
      visit new_admin_venue_message_path(club)
      within('#content') {click_link 'Change'}
    end

    scenario 'admin send invalid message', :js => true do
      page.find(:xpath, "//label[@for='level_id_#{level.id}']").click

      fill_in "group_message_topic", :with => topic
      click_link "send_group_message"

      page.should have_xpath("//input[@id = 'level_id_#{level.id}' and @checked]")
      page.should have_selector(".field_with_errors")
    end

    scenario 'admin see members', :js => true do
      page.find(:xpath, "//label[@for='level_id_#{level.id}']").click
      page.should have_content "1 selected".upcase
      page.find(:xpath, "//label[@for='level_id_#{level_2.id}']").click
      page.should have_content "1 selected".upcase
      page.find(:xpath, "//label[@for='include_suspended']").click
      page.should have_content "2 selected".upcase
    end

    scenario 'admin send message', :js => true do
      page.find(:xpath, "//label[@for='level_id_#{level.id}']").click
      page.find(:xpath, "//label[@for='level_id_#{level_2.id}']").click
      page.find(:xpath, "//label[@for='include_suspended']").click

      fill_in "group_message_topic", :with => topic
      fill_in "group_message_body", :with => body

      click_link "send_group_message"

      page.should have_content "Group message was successfully created.".upcase

      as_user(eve) do
        visit user_messages_path(eve)
        page.should have_content(topic)
        page.should have_content(user.full_name)
        click_link topic
        page.should have_content(body)
      end
    end
  end
end
