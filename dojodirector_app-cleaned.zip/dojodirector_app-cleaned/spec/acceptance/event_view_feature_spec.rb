require 'acceptance/acceptance_helper'

feature 'Event view' do
  let(:club)          { create(:club) }
  let(:another_user)  { create(:user) }
  let(:user)          { create(:user, :first_name => "User") }
  let(:email)         { "eve@example.com" }
  let(:topic)         { "Topic" }
  let(:body)          { "Body" }
  let!(:event)        { create(:event, :club => club, :start_date => 1.day.from_now.to_s) }

  background do
    user.add_role :admin, club
    club.users << user
    event.attendees << another_user
    as_user(user)
    visit club_event_path(club, event)
  end

  scenario 'user should see information about event' do
    page.should have_content(event.name)
    page.should have_content(event.description)
    page.should have_content(event.scheduled_at.to_s(:short))
  end

  scenario 'user should see list of attendees' do
    page.should have_content(another_user.full_name)
    within(".event_attendees") do
      page.should have_link(nil, :href => user_profile_path(another_user))
    end
  end

  context "as user" do
    before { as_user(user) }

    scenario "user can attend to event" do
      click_link("Attend")
      within(".event_attendees") do
        page.should have_link(nil, :href => user_profile_path(user))
      end
    end

    scenario "user can unattend" do
      click_link("Attend")

      within(".event_attendees") do
        page.should have_link(nil, :href => user_profile_path(user))
      end

      click_link("Unattend")

      within(".event_attendees") do
        page.should have_no_content(user.full_name)
      end
    end
  end

  context "as not-invited-user" do
    before do
      as_user(create(:user))
      visit club_event_path(club, event)
    end

    scenario 'should not see attend button' do
      page.should have_content("You are not invited to this event")
    end
  end
end
