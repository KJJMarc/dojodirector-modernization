require 'acceptance/acceptance_helper'

feature 'Club members management feature' do
  let(:admin)                 { create(:user) }
  let(:club)                  { create(:club, :club_type => club_type) }
  let(:club_type)             { create(:club_type) }
  let(:user)                  { create(:user) }

  let(:start_time)            { (Time.now.utc - 1.hour).strftime("%H:%M") }
  let(:end_time)              { (Time.now.utc + 1.hour).strftime("%H:%M") }
  let(:last_month)            { Date.today.months_ago(1) }
  let(:event_in_last_month)   { create(:event, :start_date => last_month.to_s, 
                                       :start_time => start_time,
                                       :end_time => end_time,
                                       :club => club) }
  
  background do
    as_user(admin)
    admin.add_role(:admin, club)

    club.users << user
    club.events << event_in_last_month
    user.add_role :member, club
    user.remove_role :pending_member, club
  end

  context 'member attendees' do
    let(:level_group)           { create(:level_group, :club_type => club_type) }
    let(:level)                 { create(:level, :level_group => level_group, :club_type => club_type) }

    before do
      level
      user.events << event_in_last_month
      user.event_attendees.map(&:confirm)

      visit admin_venue_member_path(club, user)
    end

    scenario 'admin can confirm unassinged level', :js => true do
      pending do
        within(".unconfirmed-levels") do
          click_link "Change"
          page.should have_no_content(level.name)
        end
      end
    end

    scenario 'admin see member attendees details title' do
      page.should have_content "Attendances 1"
      page.should have_content "Last attendance on #{event_in_last_month.scheduled_at.to_date}"
    end
  end

  context "calendar", :js => true, :driver => :selenium do
    let(:event) { create(:event, :start_date => Date.today.to_s,
                         :start_time => start_time, :club => club) }

    before do
      club.events << event

      user.events << event_in_last_month
      user.events << event

      visit admin_venue_member_path(club, user)
    end

    scenario 'admin see member events calendar' do
      click_link "Calendar"
      page.should have_content event.name
    end

    scenario 'day calendar should change after click on day' do
      click_link "Calendar"
      page.find("#calendar .fc-today").click

      within("#day_calendar") do
        page.should have_content(event.name) 
      end
    end

    scenario 'day calendar should change after click on event' do
      click_link "Calendar"

      within("#calendar") do
        click_calendar_day(event.scheduled_at.day)
      end

      within("#day_calendar") do
        page.should have_content(event.name)
      end
    end

    scenario 'redirects user after click on event' do
      click_link "Calendar"

      within("#calendar") do
        click_calendar_day(event.scheduled_at.day)
      end

      within("#day_calendar") do
        page.find(:xpath, "//span[text()='#{event.name}']").click
      end

      page.should have_no_selector("#calendar")
      current_path.should == admin_venue_event_path(club, event)
    end
  end
end
