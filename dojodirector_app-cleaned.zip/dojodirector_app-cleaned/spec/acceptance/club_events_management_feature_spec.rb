require 'acceptance/acceptance_helper'

feature 'Club events management feature' do
  let(:user)                          { create(:user) }
  let(:club)                          { create(:club) }
  let(:number_of_users)               { 2 }
  let!(:event) { create(:event, :club => club, :start_date => 1.day.from_now.to_s) }

  background do
    as_user(user)
    club.users << user
    user.add_role(:admin, club)
    visit admin_venue_events_path(club)
  end

  context "with many events" do
    let(:number_of_events)              { 1 }
    let(:number_of_past_events)         { 1 }

    background do
      number_of_events.times do
        @event = create(:event, :club => club, :scheduled_at => 1.day.from_now)
      end
      number_of_past_events.times { create(:event, :club => club,
                                           :start_date => (Date.today - 10.days).to_s) }
      visit admin_venue_events_path(club)
    end

    scenario 'admin should see events calendar', :js => true do
      page.should have_selector("#calendar.fc")
    end

    scenario 'admin should able to click on event in calendar', :js => true do
      click_link "Calendar"
      puts @event.scheduled_at.day.to_s
      within "div.fc-view-month" do
        click_calendar_day(@event.scheduled_at.day.to_s)
      end

      within "#day_calendar" do
        page.find('span.fc-event-title', :text => @event.name).click
      end
      page.should have_content(@event.description)
    end

    scenario 'admin should see edit shortcut in event list', :js => true do
      page.should
        have_selector("td a", :href => edit_admin_venue_event_path(club, @event))
    end
  end

  scenario 'admin should see event details', :js => true do    
    within("#calendar") do
      click_calendar_day(event.start_date.strftime("%e").strip)
    end
    find(".calendarEvent").click
        
    page.should have_content(club.events.first.name.upcase)
    page.should have_content(club.events.first.description)
  end

  scenario 'admin should create single event', :js => true do
    click_link "Add event"

    fill_in "Name", :with => "Single Event"
    fill_in "Description", :with => "Single event description"
    fill_in "Start date", :with => Date.today.strftime("%d/%m/%Y")
    select "12:00", :from => "Start time"
    select "14:00", :from => "End time"

    click_button "Create"
    page.should have_content "Event was successfully created.".upcase

    d = Date.today
    t = Time.parse("12:00")
    scheduled_at = DateTime.new(d.year, d.month, d.day, t.hour, t.min, t.sec)

    event = Event.last
    event.name.should eq("Single Event")
    event.scheduled_at.should eq(scheduled_at)
  end

  scenario 'event should have proper end_at' do
    click_link "Add event"

    fill_in "Name", :with => "Single Event"
    fill_in "Description", :with => "Single event description"
    fill_in "Start date", :with => Date.today.strftime("%d/%m/%Y")
    select "12:00", :from => "Start time"
    select "14:00", :from => "End time"

    click_button "Create"
    page.should have_content("Event was successfully created.")

    event = Event.last
    event.end_at.strftime("%H:%M").should == "14:00"
  end

  scenario 'edit event should proper display end at', :js => true do
    click_link "Add event"

    fill_in "Name", :with => "Single Event"
    fill_in "Description", :with => "Single event description"
    fill_in "Start date", :with => Date.today.strftime("%d/%m/%Y")
    select "12:00", :from => "Start time"
    select "14:00", :from => "End time"

    click_button "Create"
    page.should have_content "Event was successfully created.".upcase

    page.find(:xpath, "//span[text()='Single Event']").click
    within(".pre-content") do
      click_link "Edit"
    end
    page.has_select?('event_end_time', :selected => '14:00').should be_true
  end

  scenario 'show proper tab (validation)', :js => true do
    click_link "Add event"
    click_link "Recurring event"
    click_button "Create"

    find("#series-events").should be_visible
  end

  scenario 'admin should create series of events', :js => true do
    click_link "Add event"
    click_link "Recurring event"

    within "#series-events" do
      fill_in "Name", :with => "Collection Event"
      fill_in "Description", :with => "Collection event description"
      fill_in "Start date", :with => Date.today.strftime("%d/%m/%Y")
      fill_in "End date", :with => (Date.today + 10.days).strftime("%d/%m/%Y")
      select "12:00", :from => "Start time"
      select "14:00", :from => "End time"
      check "Monday"
      check "Friday"

      click_button "Create"
    end

    page.should have_content "Event collection was successfully created.".upcase

    number_of_days = (Date.today..(Date.today + 10.days)).select do |d|
      ["1","5"].include?(d.wday.to_s) # all mondays and fridays in date range
    end

    event_collection = EventCollection.last
    event_collection.events.first.name.should eq("Collection Event")
    event_collection.events.last.name.should eq("Collection Event")
    event_collection.events.count.should eq(number_of_days.size)
  end

  scenario 'admin should cancel single event', :js => true do
    event = create(:event, :club => club, :start_date => Date.today)

    visit admin_venue_events_path(club)

    page.find(:xpath, "//span[text()='#{event.name}']").click

    page.should have_content(event.description)
    click_link "Cancel"
    page.should have_selector("#cancel_event_modal", :visible => true)

    within("#cancel_event_modal") do
      click_button "Cancel event"
    end

    page.should have_content "Event was successfully canceled.".upcase
    event.reload.status.should eq("canceled")
  end

  scenario 'admin should cancel series of events', :js => true do
    event_collection = create(:event_collection, :club => club)
    event1 = create(:event, :club => club, :event_collection => event_collection)
    event2 = create(:event, :club => club, :event_collection => event_collection)

    visit admin_venue_events_path(club)

    within("#calendar") do
      click_calendar_day(event1.start_date.strftime("%e").strip)
    end

    page.find(:xpath, "//span[text()='#{event1.name}']").click

    click_link "Cancel"
    page.should have_selector("#cancel_event_modal", :visible => true)

    within("#cancel_event_modal") do
      find(".cancel_series").click
      click_button "Cancel event"
    end

    page.should have_content "Event was successfully canceled.".upcase
    event1.reload.status.should eq("canceled")
    event2.reload.status.should eq("canceled")
  end

  scenario 'admin should edit event', :js => true do
    within("#calendar") do
      click_calendar_day(event.start_date.strftime("%e").strip)
    end
    page.find(:xpath, "//span[text()='#{event.name}']").click
    within(".pre-content") do
      click_link "Edit"
    end

    fill_in "Name", :with => "Changed name"
    fill_in "Description", :with => "Changed desc"
    fill_in "Start date", :with => Date.today.strftime("%d/%m/%Y")
    select "12:00", :from => "Start time"
    select "14:00", :from => "End time"

    click_button "Save"

    d = Date.today
    t = Time.parse("12:00")
    scheduled_at = DateTime.new(d.year, d.month, d.day, t.hour, t.min, t.sec)

    page.should have_content "Event was successfully updated.".upcase
    page.should have_content "Changed name".upcase
    page.should have_content("Changed desc")
    page.should have_content("#{scheduled_at.to_s(:short)}")
  end


  context "validation errors" do
    shared_examples "validation virtual attributes" do
      scenario 'admin should not see virtual fields validation errors', :js => true do
        page.should have_content("NAME can't be blank")
        page.should have_content("START DATE can't be blank")
      end
    end

    before do
      click_link "Add event"
      click_link "Recurring event" if series
      click_button "Create"
    end

    describe "series" do
      it_behaves_like "validation virtual attributes" do
        let(:series) { true }
      end
    end

    describe "single event" do
      it_behaves_like "validation virtual attributes" do
        let(:series) { false }
      end
    end
  end
end
