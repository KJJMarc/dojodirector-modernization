require 'acceptance/acceptance_helper'

feature 'Super admin login feature' do
  let(:super_admin) { create(:super_admin) }
  let(:user)        { create(:user) }

  scenario 'super-admin can go to /admin/home page' do
    as_user(super_admin)
    visit admin_home_path
    page.should have_content("Dashboard")
  end

  scenario 'non-super-admin can not go to /admin/home page' do
    as_user(user)
    visit admin_home_path
    page.should_not have_content("Dashboard")
  end

  scenario 'super-admin should see Admin link' do
    as_user(super_admin)
    visit '/'
    page.should have_xpath("//a[@href='/admin/home']")
  end

  scenario 'non-super-admin should not see Admin link' do
    as_user(user)
    visit '/'
    page.should have_no_xpath("//a[@href='/admin/home']")
  end
end
