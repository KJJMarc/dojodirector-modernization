require 'acceptance/acceptance_helper'

feature 'Club management feature' do
  let(:user)          { create(:user) }
  let(:super_admin)   { create(:super_admin) }
  let(:club)          { create(:club, :twitter_url => twitter_url) }
  let!(:pending_club) { create(:club, :status => "pending") }
  let(:twitter_url)   { "twitter.com" }
  let(:phone_number)  { "12345" }

  background do
    as_user(user)
    user.add_role(:admin, club)
    visit admin_venue_path(club)
  end

  scenario 'super-admin can reject club' do
    as_user(super_admin)
    visit "/"

    click_link "Reject"
    page.should have_content("Club rejected")
    pending_club.reload.status.should == "rejected"
  end

  scenario 'super-admin can approve club' do
    as_user(super_admin)
    visit "/"

    click_link "Approve"
    page.should have_content("Club approved")
    pending_club.reload.status.should == "approved"
    
    ActionMailer::Base.deliveries.last.body.should include(pending_club.name)
  end

  scenario 'admin can see edit form' do
    click_link "Edit info"
    page.should have_content("Name")
    page.should have_content("Address")
    page.should have_content("Club type")
    page.should have_content("Club statement")
  end

  scenario 'admin can edit club information' do
    click_link "Edit info"
    fill_in "club_name", :with => "New club name"
    find("input[placeholder='Address Line 1']").set "Cracow, Sobieskiego 32/2"
    find("input[placeholder='City']").set "Cracow"
    
    click_button "Save"
        
    page.should have_content("Club was successfully updated")
    page.should have_content("New club name")

    visit club_path(club.reload)
    page.should have_content("New club name")
  end

  scenario "admin can edit club urls" do
    click_link "Edit info"
    fill_in "club_twitter_url", :with => twitter_url
    click_button "Save"

    page.should have_content("Club was successfully updated")

    within(".club_info") do
      click_link 'Public profile'
    end

    page.should have_xpath("//a[@href = '#{twitter_url}']")
  end

  scenario 'club urls should not be so strict' do
    click_link "Edit info"
    fill_in "club_twitter_url", :with => twitter_url + "||"
    click_button "Save"

    page.should have_content("is not a valid URL")
  end

  scenario 'admin can edit phone number of club' do
    click_link "Edit info"
    fill_in "Phone number", :with => phone_number
    click_button "Save"

    page.should have_content("Club was successfully updated")
    page.should have_content("Tel #{phone_number}")
  end
end
