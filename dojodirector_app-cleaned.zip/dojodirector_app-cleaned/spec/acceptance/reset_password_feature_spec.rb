require 'acceptance/acceptance_helper'

feature 'Reset password feature' do

  let(:password) { "12345a" }
  let(:password_confirmation) { password }
  let(:new_password) { "123456a" }
  let(:new_password_confirmation) { new_password }

  let(:user) do
    create(:user,
      :password => password,
      :password_confirmation => password_confirmation
    )
  end

  background do
    ActionMailer::Base.deliveries.clear
  end

  scenario 'user gets reset passwort email' do
    reset_password

    ActionMailer::Base.deliveries.last.body.tap do |body|
      body.should include(user.username)
      body.should have_link("Change my password")
    end
  end

  scenario 'user try to reset password' do
    reset_password

    visit "/users/password/edit?reset_password_token=#{user.reload.reset_password_token}"

    within(".new_password") do
      fill_in "New password", :with => new_password
      fill_in "Confirm new password", :with => new_password_confirmation
      click_button "Change my password"
    end

    click_link "Logout"

    visit '/users/sign_in'

    within("#content #new_user_short") do
      fill_in "user_username", :with => user.username
      fill_in "user_password", :with => new_password
      click_button "Login"
    end

    page.should have_content(user.full_name)
    page.should have_content("Edit profile")
  end

  scenario 'user try to reset password after 24 hours' do
    reset_password
    Timecop.freeze(Date.today + 10) do
      visit "/users/password/edit?reset_password_token=#{user.reload.reset_password_token}"
      within(".new_password") do
        fill_in "New password", :with => new_password
        fill_in "Confirm new password", :with => new_password_confirmation
        click_button "Change my password"
      end

      page.should have_content("Reset password token has expired, please request a new one")
    end
  end

end
