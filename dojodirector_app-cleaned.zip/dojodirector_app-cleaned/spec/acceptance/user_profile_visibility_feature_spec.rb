require 'acceptance/acceptance_helper'

feature 'User profile visibility' do
  let(:club)        { create(:club) }
  let(:event)       { create(:event, :club => club) }
  let(:super_admin) { create(:super_admin) }
  let(:user)        { create(:user) }
  let(:user2)       { create(:user) }
  let(:user3)       { create(:user) }
  let(:admin)       { create(:user) }

  background do
    event.attendees << user2
    user2.event_attendees.map(&:confirm)
    [admin, user].each do |u|
      club.users << u
      u.add_role :member, club
    end
    admin.add_role(:admin, club)
  end

  scenario 'super-admin can view user profile' do
    user.has_role?(:super_admin).should be_false
    as_user(super_admin)
    visit user_profile_path(user)

    page.should have_content(user.full_name)
    page.should have_content("Edit profile")
  end

  scenario 'admin can view club member profile' do
    as_user(admin)
    visit user_profile_path(user)

    page.should have_content(user.full_name)
    page.should have_content("Edit profile")
  end

  scenario 'admin can not view non-member profile' do
    as_user(admin)
    visit user_profile_path(user2)
    page.should_not have_content("Member profile")
    page.should have_content("Access Denied")
  end

  scenario 'user can not view profile of another user from different club' do
    as_user(user)
    visit user_profile_path(user2)
    page.should_not have_content("Member profile")
    page.should have_content("Access Denied")
  end

  scenario 'user can view profile of another user from my clubs' do
    club.users << user2
    as_user(user)
    visit user_profile_path(user2)
    page.should have_content(user2.full_name)
    page.should_not have_content("My calendar")
  end

  context "calendar", :js => true, :driver => :selenium do
    background do
      club.users << user2
      user2.add_role :member, club
    end

    scenario 'user can not view event from other profile from the same club' do
      as_user(user)
      visit user_profile_path(user2)
      page.should have_no_content("My calendar")
    end
  end

  scenario 'user can view own profile' do
    as_user(user)
    visit user_profile_path(user)

    page.should have_content(user.full_name)
    page.should have_content("Edit profile")
  end
end
