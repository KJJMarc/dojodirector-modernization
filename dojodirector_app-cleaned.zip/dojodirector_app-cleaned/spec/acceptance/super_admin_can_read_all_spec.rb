require 'acceptance/acceptance_helper'

feature 'Super admin can read all' do
  let(:club)        { create(:club) }
  let(:super_admin) { create(:super_admin) }
  let(:user)        { create(:user) }
  let(:admin)       { create(:admin) }
  let(:admin_club)  { admin.my_clubs.first }

  scenario 'super-admin can view all clubs' do
    as_user(super_admin)
    visit admin_venue_path(club)
    page.should have_content(club.name)
  end

  scenario 'admin can view own clubs' do
    as_user(admin)
    visit admin_venue_path(admin_club)
    page.should have_content(admin_club.name)
  end

  scenario 'non-super-admin can not view all clubs' do
    as_user(user)
    visit admin_venue_path(club)
    page.should_not have_content(club.name)
  end
end
