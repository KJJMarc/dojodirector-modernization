require 'acceptance/acceptance_helper'

feature 'User profile feature' do
  let(:user)          { create(:user, :password => password,
                                      :password_confirmation => password) }
  let(:admin)         { create(:user) }
  let(:club)          { create(:club) }
  let(:club_2)        { create(:club) }
  let(:level)         { create(:level) }
  let(:badge)         { create(:badge, :club => club, :club_type => nil) }
  let(:badge_2)       { create(:badge, :club => club_2, :club_type => nil) }
  let(:first_name)    { "changed" }
  let(:username)      { "newusername" }
  let(:new_password)  { "new_password" }
  let(:password)      { "old_password" }

  background do
    club.users << user
    club_2.users << user
    user.add_role :member, club
    user.add_role :member, club_2
    admin.add_role :admin, club
    create(:user_badge, :user => user, :badge => badge, :club => club)
    create(:user_badge, :user => user, :badge => badge_2, :club => club_2)
    user.set_level_in_club(level, club)

    as_user(user)
    visit "/"
  end

  scenario 'user should see announcements on profile' do
    within("#content") do
      page.should have_content("Latest club activity")
    end
  end

  scenario 'user should see club list on profile' do
    page.should have_content(club.name)
  end

  scenario 'user should see statement on profile' do
    page.should have_content(user.statement)
  end

  scenario 'user should upload avatar', :js => true, :driver => :selenium do
    default_avatar = user.avatar.url(:small)

    show_element(".buttons") do
      attach_file('user_avatar', Rails.root.join('spec', 'assets', 'attachments', 'image.gif'))
    end

    page.should have_selector("#logo img", :visible => true)

    within("#logo") do
      wait_for_ajax do
        page.should have_selector("#message", :visible => false)
        user.reload.avatar.url(:small).should_not eq(default_avatar)
      end
    end
  end

  scenario 'user should see first active club', :js => true do
    page.should have_link(club.name, :href => club_path(club))
  end

  scenario 'user should see image of active club' do
    page.should have_xpath("//img[contains(@src, \"#{club.logo.url(:medium)}\")]")
  end

  scenario 'user should see their level', :js => true do
    page.should have_xpath("//img[contains(@src, \"#{level.image.url(:small)}\")]")
    page.should have_content level.name.upcase
  end

  scenario 'user should see level popup with share icons', :js => true do
    find("a.level-image img").click
    page.should have_selector("#level_#{user.reload.current_user_level_in(club).id}_modal", :visible => true)

    within("#level_#{user.reload.current_user_level_in(club).id}_modal") do
      page.should have_selector("div.level-share")
    end
  end

  scenario 'user should see badges', :js => true do
    page.should have_xpath("//img[@class='user-badge' and contains(@src, \"#{badge.image.url(:small)}\")]")
  end

  scenario 'user should see proper form' do
    click_link("Edit profile")

    page.should have_content("First name")
    page.should have_content("Last name")
    page.should have_content("Date of birth")
    page.should have_content("Gender")
    page.should have_content("Username")
    page.should have_content("Email")
    page.should have_content("Phone number")
    page.should have_content("Statement")

    page.should_not have_content(/Password$/)
    page.should_not have_content("Password confirmation")
  end

  scenario 'user can edit profile' do
    click_link("Edit profile")
    fill_in "First name", :with => first_name
    fill_in "Statement", :with => "I am very hard working"
    click_button "Save"

    user.reload.first_name.should == first_name
    user.statement.should == "I am very hard working"
  end

  scenario 'user can change username' do
    click_link("Edit profile")
    fill_in "Username", :with => username
    click_button "Save"

    user.reload.username.should eq username
  end

  context 'user connect via facebook' do
    before do
      user.facebook_uid = '123456'
      user.encrypted_password = nil
      user.save

      login_as(user, :scope => :user)
    end

    scenario 'user can set password', :js => true do
      click_link("Edit profile")
      click_link "Change password"

      find("#user_password").set(new_password)
      fill_in "Password confirmation",  :with => new_password
      click_button "Update"

      save_and_open_page

      click_link "Logout"
      click_link "Login"

      within("#new_user_short") do
        fill_in "user_username", :with => user.username
        fill_in "user_password", :with => new_password
        click_button "Login"
      end

      page.should have_content(user.full_name)
    end
  end


  scenario 'user can change password', :js => true  do
    click_link("Edit profile")
    click_link "Change password"

    find("#user_password").set(new_password)
    fill_in "Password confirmation",  :with => new_password
    fill_in "Current password",       :with => password

    click_button "Update"
    click_link "Logout"
    click_link "Login"

    within("#new_user_short") do
      fill_in "user_username", :with => user.username
      fill_in "user_password", :with => new_password
      click_button "Login"
    end

    page.should have_content(user.full_name)
  end

  scenario 'user should see errors messages' do
    click_link("Edit profile")
    click_link "Change password"

    fill_in "Current password",       :with => password
    fill_in "Password confirmation",  :with => "b"
    click_button "Update"

    page.should have_selector(".field_with_errors")
  end

  scenario 'user see link to badges wallet on profile page' do
    page.should have_content("Badges")
  end

  scenario 'user should see badges wallet', :js => true do
    within "#badges" do
      click_link "View all"
    end
    page.should have_content(club.name)
    page.should have_content(club_2.name)
    page.should have_xpath("//img[contains(@src, \"#{badge.image.url(:small)}\")]")
    page.should have_xpath("//img[contains(@src, \"#{badge_2.image.url(:small)}\")]")
  end
end
