require 'acceptance/acceptance_helper'

feature 'Admin adding a new member' do
  let(:admin)                        { create(:user) }
  let(:club)                         { create(:club) }
  let!(:user)                         { create(:user) }

  background do
    admin.add_role(:admin, club)
    as_user(admin)
    visit admin_venue_members_path(club)
  end

  context "selecting all members" do
    let(:email)                       { "example@example.com" }
    let(:username)                    { "jamesbond" }
    let(:first_name)                  { "Invited" }
    let(:last_name)                   { "Member" }
    let(:invitation_message)          { "Custom message" }

    scenario 'admin can create new member' do
      click_link "Add Member"

      page.should have_content("Add Member")
      fill_in "First name", :with => first_name
      fill_in "Last name", :with => last_name
      fill_in "Username", :with => username
      fill_in "Email", :with => email
      fill_in "Custom message", :with => invitation_message
      fill_in "Date of birth", :with => Date.today.strftime("%y-%m-%d")
      click_button "Create"

      page.should have_content("User was successfully created.")
      ActionMailer::Base.deliveries.last.body.tap do |body|
        body.should include(invitation_message)
        body.should include(username)
        body.should include(club.name)
        body.should include(club.club_type.type_name)
      end
    end

    context do
      before do
        duplicate_email = create(:user, :email => email)
        club.users << duplicate_email
      end

      scenario 'admin can create new member with duplicated email' do

        click_link "Add Member"

        page.should have_content("Add Member")
        fill_in "First name", :with => first_name
        fill_in "Last name", :with => last_name
        fill_in "Username", :with => username
        fill_in "Email", :with => email
        fill_in "Custom message", :with => invitation_message
        fill_in "Date of birth", :with => Date.today.strftime("%y-%m-%d")
        click_button "Create"

        page.should have_content("User was successfully created.")
        ActionMailer::Base.deliveries.last.body.tap do |body|
          body.should include(invitation_message)
          body.should include(username)
          body.should include(club.name)
          body.should include(club.club_type.type_name)
        end
      end
    end

    context do
      before do
        taken_username = create(:user, :username => username)
      end

      scenario 'admin cant create member with already taken username' do
        click_link "Add Member"

        page.should have_content("Add Member")
        fill_in "First name", :with => first_name
        fill_in "Last name", :with => last_name
        fill_in "Username", :with => username
        fill_in "Email", :with => email
        fill_in "Custom message", :with => invitation_message
        fill_in "Date of birth", :with => Date.today.strftime("%y-%m-%d")
        click_button "Create"

        page.should have_xpath("//label[@for = 'user_username' and text() = 'has already been taken']")
      end

    end

    scenario 'admin can invite already created member' do
      click_link "Add Member"

      fill_in "First name", :with => user.first_name
      fill_in "Last name", :with => user.last_name
      fill_in "Email", :with => user.email
      click_button "Create"

      page.should have_content("User was successfully created.")
      ActionMailer::Base.deliveries.last.body.tap do |body|
        body.should include(club.name)
        body.should include(club.club_type.type_name)
      end
    end

    context 'admin should not able to invite already created member to the same club' do
      let(:taken_user) {create(:user, :email => user.email)}

      background do
        club.users << user
      end

      scenario 'should display error message' do
        click_link "Add Member"
        fill_in "First name", :with => user.first_name
        fill_in "Last name", :with => user.last_name
        fill_in "Email", :with => user.email
        click_button "Create"

        page.should have_content("This user is already a member of this club")
      end

      scenario 'should allow again invitation after the failure'  do
        click_link "Add Member"
        fill_in "First name", :with => user.first_name
        fill_in "Last name", :with => user.last_name
        fill_in "Email", :with => user.email
        click_button "Create"


        page.should have_field('Email', :with => user.email)
        page.should have_field('Username')
        page.should have_field('First name', :with => user.first_name)
        page.should have_field('Last name', :with => user.last_name)

        fill_in "First name", :with => "#{user.first_name}'s brother"


        click_button "Create"

        page.should have_content("User was successfully created.")
      end
    end
  end
end
