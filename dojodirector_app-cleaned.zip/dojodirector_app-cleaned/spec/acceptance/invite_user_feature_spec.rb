require 'acceptance/acceptance_helper'

feature 'Invite user feature' do
  let(:username)        { "jamesbond" }
  let(:first_name)      { "James" }
  let(:last_name)       { "Bond" }
  let(:club_name)       { "James Bond Club" }
  let(:email)           { "james@bond.com" }
  let(:gender)          { :male }
  let(:birthday)        { Date.parse("2011/01/01") }
  let(:password)        { "12345a" }
  let(:club)            { create(:club) }

  background do
    @user = User.invite!(
      :username       => username,
      :first_name     => first_name,
      :last_name      => last_name,
      :email          => email,
      :gender         => gender,
      :date_of_birth  => birthday,
    ) do |user|
      user.club = club
    end

    @other_user = create(:user, :club => club)
  end

  scenario 'invited user use wrong token' do
    visit accept_user_invitation_path(:invitation_token => "wrong")
    page.should have_content("We're sorry, but your invitation token has expired. Please contact your club administrator to receive the invitation again.")
  end

  context "invited user token should" do
    let(:message)  { "We're sorry, but your invitation token has expired. Please contact your club administrator to receive the invitation again." }

    context do
      before do
        Devise.stub!(:invite_for).and_return(48.hours)
      end

      scenario 'expire after 48 hours' do
        Timecop.freeze(Time.now + 48.hours) do
          visit accept_user_invitation_path(:invitation_token => @user.invitation_token)
          page.should have_content(message)
        end
      end

      scenario 'not expire before 48 hours' do
        Timecop.freeze(Time.now + 47.hours) do
          visit accept_user_invitation_path(:invitation_token => @user.invitation_token)
          page.should_not have_content(message)
        end
      end
    end

    scenario 'never expire' do
      Devise.stub!(:invite_for).and_return(0)
      Timecop.freeze(Time.now + 10.years) do
        visit accept_user_invitation_path(:invitation_token => @user.invitation_token)
        page.should_not have_content(message)
      end
    end
  end

  scenario 'invited user should see form with password' do
    visit accept_user_invitation_path(:invitation_token => @user.invitation_token)

    page.should have_content("Set your password")
    page.should have_content("Password")
    page.should have_content("Password confirmation")
  end

  scenario 'invited user fill password and should be logged in' do
    visit accept_user_invitation_path(:invitation_token => @user.reload.invitation_token)

    within(".invited_user") do
      find('#user_password').set(password)
      fill_in "Password confirmation", :with => password
      click_button "Set my password"
    end

    page.should have_content("Your password was set successfully. You are now signed in.")
  end

  context 'facebook integration' do

    let(:facebook_uid) {SecureRandom.base64}

    scenario 'invited user integrate account with facebook profile' do
      OmniAuth.config.add_mock(:facebook, {:uid => facebook_uid})
      visit accept_user_invitation_path(:invitation_token => @user.reload.invitation_token)

      within(".invited_user") do
        find(:css, 'a.facebook-button').click
      end

      page.should have_content I18n.t('flash.connected', :scope => 'authentications')
      @user.reload.facebook_uid.should eq facebook_uid
    end

    scenario 'invited user return to invitation page when facebook account already connected' do
      @other_user.update_attribute(:facebook_uid, facebook_uid)
      OmniAuth.config.add_mock(:facebook, {:uid => facebook_uid})

      visit accept_user_invitation_path(:invitation_token => @user.reload.invitation_token)

      within(".invited_user") do
        find(:css, 'a.facebook-button').click
      end

      page.should have_content I18n.t('flash.already_connected', :scope => 'authentications')
    end

    scenario 'invited user return to invitation page when facebook return exeception' do
      OmniAuth.config.mock_auth[:facebook] = :invalid_credentials
      visit accept_user_invitation_path(:invitation_token => @user.reload.invitation_token)

      within(".invited_user") do
        find(:css, 'a.facebook-button').click
      end

      current_path.should eq accept_user_invitation_path
      page.should have_content I18n.t('flash.provider_error', :message => 'invalid credentials', :scope => 'authentications')
    end

  end

end
