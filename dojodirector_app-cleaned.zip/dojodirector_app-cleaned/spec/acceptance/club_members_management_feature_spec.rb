require 'acceptance/acceptance_helper'

feature 'Club members management feature' do
  let(:user) { create(:user) }
  let(:club) do
    club = build(:club)
    club.save
    club
  end
  
  background do
    user.add_role(:super_admin)
    as_user(user)
  end

  context "with different types of members" do
    let(:number_of_members)           { 1 }
    let(:number_of_suspended_members) { 1 }

    background do
      number_of_members.times do
        @active_member = create(:user)
        club.users << @active_member
      end

      number_of_suspended_members.times do
        @suspended_member = create(:user)
        club.users << @suspended_member
        @suspended_member.suspend(club)
      end

      visit admin_venue_members_path(club, :filter => :all) 
    end

    scenario 'filters with count' do
      page.should have_content("Active (#{number_of_members})")
      page.should have_content("Suspended (#{number_of_suspended_members})")
    end

    scenario 'admin can use pagination' do
      click_link "Member name"
      page.should have_selector("a", :text => "2")
    end

    scenario 'admin can use search' do
      member = club.users.first
      fill_in "query", :with => member.first_name
      click_button "search"

      within "tr#details-#{member.id}" do
        page.should have_content(member.first_name)
      end
    end

    scenario 'admin should see link to user profile on member page' do
      member = club.users.all.sample
      fill_in "query", :with => member.email
      click_button "search"

      within "tr#details-#{member.id}" do
        click_link "Manage member"
      end

      page.should have_link("(public profile)", :href => user_profile_path(member))
    end

    context "filtering" do
      scenario 'admin can filter by active members' do
        user = @active_member
        within "thead.pre" do
          click_link "Active"
        end

        within("tr#details-#{user.id}") do
          page.should have_content(user.full_name)
          page.should have_content("Member")
        end

        page.should_not have_content(@suspended_member.full_name)
      end

      scenario 'admin can filter by suspended members' do
        user = @suspended_member
        within "thead.pre" do
          click_link "Suspended"
        end

        within("tr#details-#{user.id}") do
          page.should have_content(user.full_name)
          page.should have_content("Suspended member")
        end

        page.should_not have_content(@active_member.email)
      end

      context "generating QR codes" do
        scenario 'for active members' do
          within("#basic-filter") { click_link "Active" }
          within("thead.pre") { click_link "Print Codes" }
          all(".qrCode").length.should eq(number_of_members)
        end

        scenario 'with friendly url' do
          within("#basic-filter") { click_link "Active" }
          within("thead.pre") { click_link "Print Codes" }
          find(".qrCode")[:rel].should include(user_profile_url(@active_member, :only_path => true))
        end

        scenario 'for suspended members' do
          within("#basic-filter") { click_link "Suspended" }
          within("thead.pre") { click_link "Print Codes" }
          all(".qrCode").length.should eq(number_of_suspended_members)
        end

        scenario 'for search results' do
          within("thead.pre") do
            fill_in "query", :with => club.users.last.email
            click_button "search"
          end

          within("thead.pre") { click_link "Print Codes" }
          all(".qrCode").length.should eq(1)
        end

        context "independent of the pagination" do
          let(:additional_users) { 5 }

          before do
            additional_users.times do
              user = create(:user)
              club.users << user
            end
          end

          scenario 'qr-codes' do
            within("#basic-filter") { click_link "Active" }
            within("thead.pre") { click_link "Print Codes" }
            all(".qrCode").length.should eq(number_of_members + 5)
          end

          scenario 'qr-codes count' do
            within("#basic-filter") { click_link "Active" }
            within("thead.pre") { page.should have_content("Print Codes (#{number_of_members + 5})") }
          end
        end
      end
    end

    context "ordering" do
      scenario 'admin can order by name', :js => true do
        click_link "Member name"
        within(page.find(:xpath, '//table/tbody/tr[1]')) do
          page.should have_content(club.users.sorted_by_last_name_first_name(club, "ASC").first.full_name)
        end
      end

      scenario 'admin can order members (reverse)', :js => true do
        member    = create(:user, :first_name => "A", :last_name => "AbcdefgB")
        member_2  = create(:user, :first_name => "B", :last_name => "AbcdefgA")
        club.users << [member, member_2]
        visit admin_venue_members_path(club)
        within("#basic-filter") { click_link "All" }
        click_link "Member name"
        page.should have_content(member_2.full_name)
      end
    end
  end

  context "for an individual member" do
    let(:member) { create(:user) } 
    let(:another_member) { create(:user, :last_name => "Someone else") } 

    background do
      club.users << member
      club.users << another_member

      visit admin_venue_members_path(club, :filter => :all)

      within "#member-#{member.id}" do
        page.find("td.name", :text => member.full_name).click
      end
    end

    scenario 'admin should see qr code on modalbox', :js => true do
      within "#details-#{member.id}" do
        page.find("button.btn-qr").click
      end
      page.should have_selector("#qr-code-modal-#{member.id}", :visible => true)
    end

    scenario 'admin should expand row with user details', :js => true do
      page.should have_selector("tr.details", :text => member.full_name.upcase, :visible => true)

      within "#member-#{another_member.id}" do
        page.find("td.name", :text => another_member.full_name).click
      end

      page.should have_selector("tr.details", :text => member.full_name, :visible => false)
      page.should have_selector("tr.details", :text => another_member.full_name.upcase, :visible => true)
    end
  end

  context 'with a member who should get a new level' do
    let(:club_type)             { create(:club_type) }
    let(:level_group)           { create(:level_group, :club_type => club_type) }
    let(:level)                 { create(:level, :level_group => level_group,
                                         :club_type => club_type) }
    let(:user)                  { create(:user) }
    let(:club)                  { create(:club, :club_type => club_type) }
    let(:another_user)          { create(:user) }
    let(:last_month)            { Date.today.months_ago(1) }
    let(:start_time)            { (Time.now.utc - 1.hour).strftime("%H:%M") }
    let(:event_in_last_month)   { create(:event, :start_date => last_month.to_s,
                                         :start_time => start_time,
                                         :club => club) }

    before do
      level
      club.events << event_in_last_month
      club.users << user

      user.events << event_in_last_month

      # observer will set a new level flag
      ActiveRecord::Observer.with_observers(:new_level_flag_observer) do
        user.event_attendees.map(&:confirm)
      end

      club.users << another_user

      visit admin_venue_members_path(club)
    end

    scenario 'admin see number of new levels' do
      page.should have_content("New level (1)")
    end

    scenario 'admin can filter by new level members' do
      within "#basic-filter" do
        click_link "New level"
      end

      page.should have_css("table tbody tr.basic", :count => 1)
      page.should have_content(user.full_name)
      page.should_not have_content(another_user.full_name)
    end

    scenario 'admin should see new level on list' do
      within "#basic-filter" do
        click_link "New level"
      end

      within("tr#member-#{user.id}") do
        page.should have_content("(*)")
      end
    end

    scenario 'admin can filter members by levels' do
      level_group = create(:level_group, :club_type => club.club_type)
      level = create(:level, :level_group => level_group, :club_type => club.club_type)

      visit admin_venue_members_path(club, :filter => :all) 
      within "#level-filter" do
        click_link level.name
      end

      within("table.venue-members") do
        page.should_not have_content(user.full_name)
        page.should_not have_content(another_user.full_name)
      end

      create(:user_level, :user => user, :level => level, :club => club)

      within "#level-filter" do
        click_link level.name
      end

      within("table.venue-members") do
        page.should have_content(user.full_name)
        page.should_not have_content(another_user.full_name)
      end

      another_level = create(:level, :level_group => level_group, :club_type => club.club_type)
      create(:user_level, :user => user, :level => another_level, :club => club)

      within "#level-filter" do
        click_link level.name
      end

      within("table.venue-members") do
        page.should_not have_content(user.full_name)
      end
    end
  end
end
