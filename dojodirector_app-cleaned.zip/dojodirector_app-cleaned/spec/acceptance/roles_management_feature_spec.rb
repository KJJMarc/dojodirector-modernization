require 'acceptance/acceptance_helper'

feature 'Roles management feature' do
  let(:user)        { create(:user) }
  let(:member)      { create(:user) }
  let(:club)        { create(:club) }
  let(:super_admin) { create(:super_admin) }

  background do
    club.users << [user, member]
    member.remove_role :pending_member, club
    as_user(user)
  end

  context "manage from super_admin page" do
    background do
      as_user(super_admin)
      visit admin_user_path(member)
    end

    scenario 'super-admin should see manage roles form' do
      page.should have_selector("a", :text => "Make admin")
    end

    scenario 'super-admin can add role to user', :js => true do
      click_link "Make admin"
      page.should have_content "Remove admin".upcase
    end

    scenario 'super-admin can remove role', :js => true do
      click_link "Make admin"
      page.should have_content "Remove admin".upcase
      click_link "Remove admin"

      page.should have_content "Make admin".upcase
    end

  end

  context "admin" do
    background do
      user.add_role :admin, club
    end

    scenario 'admin can add admin role for member', :js => true do
      visit admin_venue_member_path(club, member)

      click_link "Make admin"
      page.should have_content "Make admin".upcase
    end

    scenario 'admin can not un-admin themselves' do
      visit admin_venue_member_path(club, user)
      page.should have_no_content "Remove admin".upcase
    end

    scenario 'non-admin should not able to delete role', :js => true do
      page.evaluate_script('window.confirm = function() { return true; }')
      visit admin_venue_member_path(club, member)
      click_link "Make admin"
      page.should have_content "Remove admin".upcase
      user.remove_role :admin, club
      click_link "Remove admin"
      page.should_not have_content "Make admin".upcase
    end
  end

  context "super-admin" do
    background do
      user.add_role :super_admin
    end

    scenario 'super-admin can see form to modify roles' do
      visit admin_venue_member_path(club, member)
      page.should have_content("Make admin")
    end
  end
end
