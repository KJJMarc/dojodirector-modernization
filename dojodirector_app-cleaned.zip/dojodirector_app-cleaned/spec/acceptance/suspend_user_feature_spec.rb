require 'acceptance/acceptance_helper'

feature 'Suspend user feature' do
  let(:admin)               { create(:user) }
  let(:super_admin)         { create(:super_admin) }
  let(:member)              { create(:user, :first_name => "member") }
  let(:suspended_member)    { create(:user, :first_name => "suspeneded") }
  let(:club)                { create(:club) }
  
  let(:prickly) {Prickly.new}

  background do
    club.users << [admin, member, suspended_member]

    admin.add_role(:admin, club)
    suspended_member.suspend(club)
  end

  scenario 'there is no way to suspend admin' do
    as_user(super_admin)
    visit admin_venue_member_path(club, admin)
    click_link "Suspend"
    page.should have_content("You can not suspend admin of club")
  end

  scenario 'admin can suspend member', :js => true do
    as_user(admin)
    visit admin_venue_members_path(club)
    fill_in "query", :with => member.email
    click_button "search"

    page.should have_content(member.full_name)

    find("tr#member-#{member.id}").click
    within("tr#details-#{member.id}") do
      click_link "Manage member"
    end

    click_link "Suspend"

    page.should have_content("Account suspended".upcase)
    page.should have_content("Unsuspend".upcase)
    member.membership_at(club).should be_suspended
  end

  scenario 'admin can unsuspend member' do
    as_user(admin)
    visit admin_venue_members_path(club)
    within("#basic-filter") { click_link "Suspended" }

    within("tr#details-#{suspended_member.id}") do
      click_link "Manage member"
    end

    click_link "Unsuspend"

    page.should have_content("Account unsuspended")
    page.should have_content("Suspend")
    suspended_member.membership_at(club).should be_active
  end

  scenario 'suspended member should see club as suspended on profile page' do
    as_user(suspended_member)
    visit user_profile_path(suspended_member)
    page.should have_content("Your membership in this club is suspended")
  end
end
