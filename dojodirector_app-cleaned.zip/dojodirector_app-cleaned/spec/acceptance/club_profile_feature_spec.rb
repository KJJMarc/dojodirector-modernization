require 'acceptance/acceptance_helper'

feature 'Club profile feature' do
  let(:club)              { create(:club) }
  let(:no_logo_club)      { create(:club, :logo => nil) }
  let(:event) {
    create(:event, :club => club, :start_date => 1.day.from_now.to_s)
  }
  let(:past_event) {
    create(:event, :club => club, :start_date => 1.day.ago.to_s)
  }

  let(:announcement) { create(:announcement, :club => club) }
  let(:badge) { create(:badge, :club => club) }
  let(:check_in) { create(:check_in, :club => club) }
  let(:super_admin) { create(:super_admin) }

  scenario 'user should see club details' do
    visit club_path(club)

    page.should have_content(club.name)
    page.should have_content(club.address.line_1)
    page.should have_content(club.address.city)
    page.should have_content(club.address.postcode)
    page.should have_content(club.phone_number)
    page.should have_content(club.facebook_url)
    page.should have_content(club.twitter_url)
    page.should have_xpath("//img[contains(@src, \"#{club.logo.url(:medium)}\")]")
  end

  scenario 'admin can upload club logo', :js => true, :driver => :selenium do
    as_user(super_admin)
    visit club_path(no_logo_club)
    click_link "Manage this club"
    show_element(".buttons") do
      attach_file('club_logo', Rails.root.join('spec', 'assets', 'attachments', 'logo_2.jpg'))
    end

    page.should have_xpath("//img[contains(@src, \"logo_2.jpg\")]")
  end

  scenario 'user should see club upcoming events' do
    event

    visit club_path(club)

    page.should have_content("Upcoming events")
    within("ol.events li h3") do
      page.should have_content(event.name)
    end
  end

  scenario 'user should see most popular badges' do
    create(:user_badge, :club => club, :badge => create(:badge, :club => club,
                                                        :name => "New badge"))

    visit club_path(club)

    page.should have_content("Popular badges")

    within("div.badges ol .badge-image") do
      page.should have_selector("img.user-badge")
    end
  end

  scenario 'user should see announcements' do
    announcement

    visit club_path(club)

    page.should have_content("Recent announcements")

    within("ol.announcements li a") do
      page.should have_content(announcement.title)
    end
  end

  scenario "browse venue calendar", :js => true, :driver => :selenium do
    event
    past_event
    visit club_path(club)
    click_on "Calendar"

    within("#calendar") do
      click_calendar_day(past_event.scheduled_at.day)
    end

    within("#day_calendar") do
      page.find(:xpath, "//span[text()='#{past_event.name}']").click
    end

    page.should have_no_selector("#calendar")
    current_path.should == club_event_path(club, past_event)
  end
end
