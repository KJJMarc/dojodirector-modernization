require 'acceptance/acceptance_helper'

feature "Individual member management" do

  let(:admin)                        { create(:user) }
  let(:club)                        { create(:club) }
  let(:user)                        { create(:user) }

  background do
    club.users << user
    user.add_role :member, club
    user.remove_role :pending_member, club

    admin.add_role(:admin, club)
    as_user(admin)
    visit admin_venue_member_path(club, user)
  end

  scenario 'admin can display member details' do
    page.should have_content(user.full_name)
    page.should have_content(user.email)
    page.should have_content(user.address)
    page.should have_content(user.notes)
  end

  scenario 'admin can edit member details' do
    within('dl.box-content') do
      click_link "Edit"
    end

    fill_in "First name", :with => "Changed Name"
    click_button "Save"

    page.should have_content("User was successfully updated.")
    page.should have_content("Changed Name")
  end

  scenario 'admin can change members statement' do
    within('dl.box-content') do
      click_link "Edit"
    end
    fill_in "Statement", :with => "I am World Champion 2012"
    click_button "Save"

    page.should have_content("User was successfully updated.")
    page.should have_content("I am World Champion 2012")
  end

  scenario 'admin can edit member notes' do
    within('dl.box-content') do
      click_link "Edit"
    end
    fill_in "Notes", :with => "Changed Notes"
    click_button "Save"

    page.should have_content("User was successfully updated.")
    page.should have_content("Changed Notes")
  end

  scenario 'admin can edit member address' do
    within('dl.box-content') do
      click_link "Edit"
    end
    find("input[placeholder='Address Line 1']").set "House no and street"
    find("input[placeholder='Enter a Postcode']").set "EC1R 0JH"
    find("input[placeholder='City']").set "London"
    click_button "Save"

    page.should have_content("User was successfully updated.")
    page.should have_content("EC1R 0JH")
  end

  scenario 'admin can make user an admin', :js => true do
    click_link "Make admin"
    within(".status") do
      page.should have_content("Admin".upcase)
    end
  end

  context "member levels" do
    let!(:old_level) { old_level = user.current_level_in(club) }
    let!(:new_level) do
      create(:level,
             :club_type_id => club.club_type_id,
             :level_group => create(:level_group,
                                    :club_type => club.club_type))
    end

    scenario 'admin should see level popup', :js => true do
      visit admin_venue_member_path(club, user)

      within("#level") do
        click_link "Change"
      end

      within("#change-user-#{user.id}-role") do
        find("ul.levels li:first-child").click
        click_button "Confirm"
      end

      find("a.level-image img").click
      page.should have_selector("#level_#{user.reload.current_user_level_in(club).id}_modal", :visible => true)
    end

    scenario 'admin can go to level page', :js => true do
      visit admin_venue_member_path(club, user)

      within("#level") do
        click_link "Change"
      end

      within("#change-user-#{user.id}-role") do
        find("ul.levels li:first-child").click
        click_button "Confirm"
      end

      page.should have_selector("#change-user-#{user.id}-role", :visible => false)

      visit user_profile_path(user)

      find("a.level-image img").click
      within("#level_#{user.reload.current_user_level_in(club).id}_modal") do
        page.should have_content("See how they will see #{user.full_name} level")
        click_link "See how they will see #{user.full_name} level"
      end

      user.reload.current_user_level_in(club).tap do |level|
        page.should have_content(level.name.upcase)
      end
    end

    scenario 'admin can delete level', :js => true do
      visit admin_venue_member_path(club, user)

      within("#level") do
        click_link "Change"
      end

      within("#change-user-#{user.id}-role") do
        find("ul.levels li:first-child").click
        click_button "Confirm"
      end

      within("#level") do
        page.should have_content(new_level.name.upcase)
      end

      within("#level_#{user.reload.current_user_level_in(club).id}_modal") do
        click_link "Delete level"
      end

      within("#level") do
        page.should have_no_content(new_level.name)
      end
    end

    scenario 'admin can edit member level', :js => true do
      visit admin_venue_member_path(club, user)

      within("#level") do
        click_link "Change"
      end

      find("#main_list li.level_group:first-child").click
      within("#change-user-#{user.id}-role") do
        find("ul.levels li:first-child").click
        click_button "Confirm"
      end

      wait_for_ajax do
        page.should have_content(new_level.name.upcase)
        user.current_level_in(club).should_not eq(old_level)
        user.current_level_in(club).should eq(new_level)
      end

      ActionMailer::Base.deliveries.last.body.should include(club.name)
      ActionMailer::Base.deliveries.last.body.should include(new_level.name)
    end

    scenario 'admin can edit member level from member list', :js => true do
      visit admin_venue_members_path(club)

      within "#details-#{user.id}" do
        page.find("a.change-level").click
      end

      within("#change-user-#{user.id}-role") do
        find("ul.levels li:first-child").click
        click_button "Confirm"
      end

      wait_for_ajax do
        page.should have_content(new_level.name)
        user.reload.current_level_in(club).should_not eq(old_level)
        user.reload.current_level_in(club).should eq(new_level)
      end
    end
  end

  context 'member badges' do
    let(:number_of_badges) { 2 }
    before do
      number_of_badges.times { create(:user_badge,
                                      :club => club,
                                      :user => user,
                                      :badge => create(:badge,
                                                       :club => club,
                                                       :club_type => nil))}

      visit admin_venue_members_path(club)

      find("tr#member-#{user.id}").click
      within("tr#details-#{user.id}") do
        click_link "Manage member"
      end
    end

    scenario 'admin can award badge from member list', :js => true do
      click_link "Members"
      page.find("tr#member-#{user.id}").click

      within("tr#details-#{user.id}") do
        click_link "Award badge"
      end

      within("#change-user-#{user.id}-badge") do
        page.should have_content("Award a new badge")

        first(".element_box").click
        click_button("Award")

        #NOTE: webkit redirect immediately after click and its fail
        # page.should have_content "Badge was successfully awarded"

        ActionMailer::Base.deliveries.last.body.should include(club.name)
      end

      within("tr#details-#{user.id}") do
        click_link "Manage member"
      end

      click_link "Show all badges"

      within("table#badges tbody") do
        all("tr").length.should eq(number_of_badges + 1)
      end
    end

    scenario 'admin can remove badge from member list', :js => true do
      click_link "Members"
      page.find("tr#member-#{user.id}").click

      within("tr#details-#{user.id}") do
        click_link "Award badge"
      end

      within("#change-user-#{user.id}-badge") do
        page.should have_content("Award a new badge")

        first(".element_box").click
        click_button("Award")

        #NOTE: webkit redirect immediately after click and its fail
        # page.should have_content "Badge was successfully awarded"
      end

      visit admin_venue_members_path(club)
      page.find("tr#member-#{user.id}").click

      within("#member_badge_#{user.id}_description") do
        find("img").click
        click_link "Remove badge"
      end

      within("tr#details-#{user.id}") do
        click_link "Manage member"
      end

      click_link "Show all badges"

      within("table#badges tbody") do
        all("tr").length.should eq(number_of_badges)
      end
    end

    scenario 'admin should see member latest badges' do
      within(".badges-list") do
        all(".badge-image").length.should eq(number_of_badges)
      end
    end

    scenario 'admin should see full list of member badges' do
      click_link "Show all badges"
      page.should have_content("All badges")
      within("table#badges tbody") do
        all("tr").length.should eq(number_of_badges)
      end
    end

    scenario 'admin can remove member badge' do
      click_link "Show all badges"

      within("table#badges tbody tr:last") do
        click_link "Remove"
      end
      page.should have_content("Badge removed")

      within("table#badges tbody") do
        all("tr").length.should eq(number_of_badges - 1)
      end
    end

    scenario 'admin can add new badge for member', :js => true do
      click_link "Award"
      within("#award_badge_modal") do
        page.should have_content "Award a new badge".upcase

        first(".element_box").click
        click_button("Award")

        page.should have_content "Badge was successfully awarded".upcase
      end

      click_link "Show all badges"

      within("table#badges tbody") do
        all("tr").length.should eq(number_of_badges + 1)
      end
    end
  end
end
