require 'acceptance/acceptance_helper'

feature 'Club profile feature' do
  let(:club)              { create(:club, :address => nil) }
  let(:admin)             { create(:user) }

  background do
    admin.add_role(:admin, club)
    as_user(admin)
    visit admin_venue_members_path(club) 
  end

  scenario 'admin can see popup asking to complete the information' do
    page.should have_content "Please update your club information"
    within "ul.profile-incomplete-fields" do
      ["Address", "Telephone", "Twitter","Facebook"].each do |field|
        page.should have_content field
      end
    end
    click_on "Update details"
    current_path.should == edit_admin_venue_path(club)
  end

  scenario 'admin can hide popup asking to complete the information' do
    page.should have_content "Please update your club information"
    click_on "No thanks, I'll do it later"
    visit admin_venue_members_path(club) 

    page.should_not have_content "Please update your club information"
  end

  scenario 'admin will see popup again if hidden more than 1 hour ago' do
    page.should have_content "Please update your club information"
    click_on "No thanks, I'll do it later"

    club.update_attribute :completeness_reminder_dismissed_at, 65.minutes.ago
    visit admin_venue_members_path(club) 
    page.should have_content "Please update your club information"
  end
end
