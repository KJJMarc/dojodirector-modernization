require 'acceptance/acceptance_helper'

feature 'User profile feature' do

  let(:club)          { create(:club) }
  let(:another_club)  { create(:club) }
  let(:user)          { create(:user).tap{|u| u.clubs << club } }
  let(:another_user)  { create(:user).tap{|u| u.clubs << club } }
  let(:user_from_other_club)  { create(:user, :clubs => [another_club]) }

  before do
    ActiveRecord::Observer.enable_observers
  end

  after do
    ActiveRecord::Observer.disable_observers
  end

  background do
    user.add_role :member, club
    as_user(user)
  end

  scenario 'user should see empty feed on their profile' do
    visit user_profile_path(user)
    page.should have_content("There are currently no updates")
  end

  scenario 'user should see their level awarded' do
    level = create(:level, :club_type => club.club_type)
    create(:user_level, :club => club, :level => level, :user => user)


    visit user_profile_path(user)
    within "ol.feed li.user_level_created" do
      page.should have_content(level.name)
    end
  end

  context "reload feeds", :js => true do
    background do
      @level       = create(:level, :club_type => club.club_type)
      @user_level  = create(:user_level, :club => club, :level => @level, :user => user)
    end

    scenario 'user should see only level' do
      visit user_profile_path(user)

      within "ol.feed li.user_level_created" do
        page.should have_content(@level.name)
      end
    end
  end

  context "view more feeds", :js => true do
    background do
      @check_in    = create(:check_in, :user => user, :club => club)
      @level       = create(:level, :club_type => club.club_type)
      @user_level  = create(:user_level, :club => club, :level => @level, :user => user)
      @user_badge  = create(:user_badge, :user => user, :club => club)
    end

    scenario 'user should able to use view more button' do
      visit user_profile_path(user)

      within "ol.feed li.user_badge_created" do
        page.should have_content(@user_badge.name)
      end

      within "ol.feed li.user_level_created" do
        page.should have_content(@level.name)
      end

      page.should have_no_selector("ol.feed li.check_in_created")
    end

    scenario "view more button" do
      visit user_profile_path(user)
      click_link("view more")

      within "ol.feed li.check_in_created" do
        page.should have_content("You")
      end
    end

    scenario "view more few times" do
      visit user_profile_path(user)
      3.times { click_link("view more") }
      all("ol.feed li").count == 3
    end

    scenario "no more updates" do
      visit user_profile_path(user)
      3.times { click_link("view more") }
      page.should have_selector("#view-more-announcements", :visible => false)
    end
  end

  scenario "user should see badges awarded to them" do
    badge = create(:badge, :club_type => club.club_type)
    user_badge = create(:user_badge,
                        :user => user,
                        :badge => badge,
                        :club => club)

    visit user_profile_path(user)
    within "ol.feed li.user_badge_created" do
      page.should have_content(badge.name)
    end
  end

  scenario "user should see badges awarded to another user in theirs club" do
    badge = create(:badge, :club_type => club.club_type)
    another_user_badge = create(:user_badge,
                        :user => another_user,
                        :badge => badge,
                        :club => club)
    visit user_profile_path(user)

    within "ol.feed li.user_badge_created" do
      page.should have_content(another_user.full_name)
      page.should have_content(badge.name)
    end
  end

  scenario "user should see level changes for another user in theirs club" do
    level = create(:level, :club_type => club.club_type)
    create(:user_level, :club => club, :level => level, :user => another_user)

    visit user_profile_path(user)
    within "ol.feed li.user_level_created" do
      page.should have_content(another_user.full_name)
      page.should have_content(level.name)
    end
  end

  scenario "user should not see badges for users in other clubs" do
    badge = create(:badge, :club_type => another_club.club_type)
    another_user_badge = create(:user_badge,
                        :user => user_from_other_club,
                        :badge => badge,
                        :club => another_club)
    visit user_profile_path(user)

    page.should_not have_selector "ol.feed li.user_badge_created"
  end

  scenario "user should not see levels for users in other clubs" do
    level = create(:level, :club_type => another_club.club_type)
    create(:user_level, :club => another_club, :level => level,
           :user => user_from_other_club)

    visit user_profile_path(user)
    page.should_not have_selector "ol.feed li.user_level_created"
  end
end
