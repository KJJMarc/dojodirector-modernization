require 'acceptance/acceptance_helper'

feature 'Admin adding a new club' do
  let(:admin)                        { create(:user) }
  let(:club)                         { create(:club) }
  let(:user)                         { create(:user) }

  let(:club_name) { "Club" }
  let(:club_type) { create(:club_type) }
  let(:address_line_1) { "Address" }
  let(:city) { "City" }
  let(:postcode) { "EC1R 0JH" }
  let(:club_type_name) { club_type.type_name }

  background do
    ActionMailer::Base.deliveries.clear
    admin.add_role(:admin, club)
    as_user(admin)
    club_type

    visit admin_venues_path
  end

  scenario 'admin can create new club' do
    click_link "Add new club"
    fill_in "club_name", :with => club_name
    find("input[placeholder='Address Line 1']").set address_line_1
    find("input[placeholder='Enter a Postcode']").set postcode
    find("input[placeholder='City']").set city
    select club_type_name, :from => "club_club_type_id"

    click_button "Create"

    page.should have_content("Club was successfully created")

    Club.last.status.should == "pending"
    Club.last.created_by.should == admin
    Club.last.admins.first.should == admin

    ActionMailer::Base.deliveries.should be_empty
  end

end
