require 'acceptance/acceptance_helper'

feature 'User calendar', :js => true do
  let(:user)          { create(:user, :password => password,
                                      :password_confirmation => password) }
  let(:admin)         { create(:user) }
  let(:club)          { create(:club) }
  let(:club_2)        { create(:club) }
  let(:password)      { "old_password" }
  let(:past_event) do
    create(:event,  :club => club,
                    :start_date => Time.now.beginning_of_month.to_date.to_s,
                    :status => "active")
  end
  let(:future_event) do
    create(:event,  :club => club_2,
                    :start_date => (Time.now.end_of_month - 1.hour).to_date.to_s,
                    :status => "active")
  end
  let(:attendance_date) { 2.days.ago.to_date }
  let(:attendance)    { create(:attendance, 
                               :user => user, 
                               :club => club, 
                               :date => attendance_date) }

  background do
    club.users << user
    club_2.users << user
    user.add_role :member, club
    user.add_role :member, club_2
    admin.add_role :admin, club
    user.events << past_event
    user.events << future_event

    as_user(user)
    visit "/"
  end

  scenario 'user should see event on attendance sheet' do
    date = past_event.scheduled_at.strftime('%Y-%m-%d')

    click_link "Calendar"

    find("div.attendance").click

    within "div.attendance ul" do
      click_link(club.name)
    end

    cell = attendance_cell date
    cell.should_not have_content "X"

    past_event.confirm(user)
    visit user_club_attendance_path(user, club)

    cell = attendance_cell date
    cell.should have_content "X"
  end

  scenario 'user should see daily attendance on attendance sheet' do
    attendance = create(:attendance, :user => user, :club => club, :date => 2.days.ago.to_date)
    date = attendance.date.strftime('%Y-%m-%d')

    click_link "Calendar"
    find('div.attendance').click
    within "div.attendance ul" do
      click_link(club.name)
    end

    cell = attendance_cell date

    cell.should have_content "X"
  end

  scenario 'user should see combined calendar on profile', :js => true do
    level = create(:level)
    user.set_level_in_club(level, club)

    click_link "Calendar"

    page.find("td.fc-current-month div.day-#{future_event.scheduled_at.day}").click

    within "#day_calendar" do
      page.should have_content(future_event.name)
    end

    page.find("td.fc-current-month div.day-#{past_event.scheduled_at.day}").click

    within "#day_calendar" do
      page.should have_content(past_event.name)
    end
  end

  scenario 'user should see club calendar on profile' do
    click_link "Calendar"

    find('div.calendar-selector').click
    within "div.calendar-selector ul" do
      click_link(club.name)
    end

    page.find("td.fc-current-month div.day-#{past_event.scheduled_at.day}").click
    within "#day_calendar" do
      page.should have_content(past_event.name)
    end

    find('div.calendar-selector').click
    within "div.calendar-selector ul" do
      click_link(club_2.name)
    end

    page.find("td.fc-current-month div.day-#{future_event.scheduled_at.day}").click
    within "#day_calendar" do
      page.should have_content(future_event.name)
    end
  end
end
