require 'acceptance/acceptance_helper'

feature 'Superadmin club feature' do

  let(:super_admin)     { create(:super_admin) }
  let(:user)            { create(:user) }
  let!(:club_type)      { create(:club_type) }
  let!(:club_type_2)    { create(:club_type) }

  background do
    ActionMailer::Base.deliveries.clear
    create(:federation, :name => "New Federation", :club_type => club_type)
    create(:club, :club_type => club_type)
    as_user(super_admin)
    visit admin_clubs_path
  end

  scenario 'user see clubs on navigation bar' do
    within("#bar .nav") do
      page.should have_content("Clubs")
    end
  end

  scenario 'super-admin should see proper tab' do
    page.should have_content("Name")
    page.should have_content("Type")
    page.should have_content("Federation")
    page.should have_content("Members")
    page.should have_content("Events")
    page.should have_content("Admins")
  end

  scenario 'last club should be first on table' do
    within(page.find(:xpath, '//table/tbody/tr[1]')) do
      page.should have_content(Club.last.name)
    end
  end

  scenario 'super-admin can order by name' do
    click_link "Name"
    within(page.find(:xpath, '//table/tbody/tr[1]')) do
      page.should have_content(Club.order(:name).first.name)
    end
  end

  scenario 'super-admin can click on club name' do
    club = Club.order("created_at desc").first
    click_link club.name
    page.should have_content(club.name)
    page.should have_content("Edit info")
  end

  context "pagination" do
    before do
      2.times { create(:club, :club_type => club_type) }
      as_user(super_admin)
      visit admin_clubs_path
    end

    scenario 'super-admin see pagination' do
      within(".pagination") do
        page.should have_selector(".next_page")
        page.should have_content("1")
        page.should have_content("2")
      end
    end

    scenario 'super-admin see first 2 clubs' do
      page.should have_selector('tr', :count => 2)
    end

    scenario 'super-admin can use pagination' do
      within(".pagination") do
        click_link "2"
      end

      within(page.find(:xpath, '//table/tbody/tr[1]')) do
        page.should have_content(Club.order("created_at desc").all[2].name)
      end
    end

    scenario 'super-admin can use pagination' do
      within(".pagination") do
        click_link "2"
      end

      within(page.find(:xpath, '//table/tbody/tr[1]')) do
        page.should have_content(Club.order("created_at desc").all[2].name)
      end
    end

    scenario 'super-admin can see all clubs' do
      club = Club.all.sample

      fill_in "query", :with => club.name
      click_button "search"

      page.should have_selector('tr', :count => 1)

      fill_in "query", :with => ""
      click_button "search"
      page.should have_selector('tr', :count => 2)
    end
  end

  scenario 'super admin can use search' do
    club = Club.all.sample
    fill_in "query", :with => club.name
    click_button "search"

    page.should have_content(club.name)
  end

  scenario 'super-admin can search by admin email' do
    club = Club.all.sample
    user.clubs << club
    user.add_role :admin, club

    fill_in "query", :with => user.email
    click_button "search"

    page.should have_content(club.name)
  end

  scenario 'super-admin can change federation club' do
    within(page.find(:xpath, '//table/tbody/tr[1]')) do
      page.should have_content("No Federation")
      click_link "Edit"
    end
    page.should have_content("Federation")
    select "New Federation", :from => "Federation"
    click_button "Save"

    visit admin_clubs_path
    within(page.find(:xpath, '//table/tbody/tr[1]')) do
      page.should_not have_content("No Federation")
      page.should have_content("New Federation")
    end
  end

  context "new club" do
    let(:club_name) { "Club" }
    let(:address_line_1) { "Address" }
    let(:city) { "City" }
    let(:postcode) { "EC1R 0JH" }
    let(:club_type_name) { club_type.type_name }
    let(:first_name) { "James" }
    let(:last_name) { "Bond" }
    let(:email)     { "james@bond.com" }
    let(:username)     { "jamesbond" }

    scenario 'validation fail and club type' do
      click_link "Create new club"
      select club_type_name, :from => "club_club_type_id"
      click_button "Create"

      find_field("club_club_type_id").value.should == club_type.id.to_s
    end

    scenario 'super-admin create club with already existed email' do
      click_link "Create new club"
      fill_in "club_name", :with => club_name
      find("input[placeholder='Address Line 1']").set address_line_1
      find("input[placeholder='Enter a Postcode']").set postcode
      find("input[placeholder='City']").set city
      select club_type_name, :from => "club_club_type_id"

      fill_in "First name", :with => first_name
      fill_in "Last name", :with => last_name
      fill_in "Username", :with => user.username
      fill_in "Email", :with => user.email

      click_button "Create"

      page.should have_content("Club was successfully created")

      last_club = Club.last
      admin_of_club = last_club.users.first

      last_club.name.should == club_name
      admin_of_club.username.should eq user.username
      admin_of_club.has_role?(:admin, last_club).should be_true
      ActionMailer::Base.deliveries.should_not be_empty
    end

    scenario 'super-admin can create new club' do
      click_link "Create new club"

      fill_in "club_name", :with => club_name
      find("input[placeholder='Address Line 1']").set address_line_1
      find("input[placeholder='Enter a Postcode']").set postcode
      find("input[placeholder='City']").set city
      select club_type_name, :from => "club_club_type_id"

      fill_in "First name", :with => first_name
      fill_in "Last name", :with => last_name
      fill_in "Email", :with => email
      fill_in "Username", :with => username

      click_button "Create"

      page.should have_content("Club was successfully created")

      Club.last.status.should == "approved"
      Club.last.created_by.should == super_admin
      Club.with_role(:admin, User.last).should_not be_empty
      ActionMailer::Base.deliveries.should_not be_empty
    end

    context 'fill in form with data' do

      scenario 'should auto fill personal data based on email and username' do
        click_link "Create new club"

        fill_in "Email", :with => user.email
        fill_in "Username", :with => user.username

        click_button "Create"

        page.should have_field("First name", :with => user.first_name)
        page.should have_field("Last name", :with => user.last_name)
      end

      scenario 'shouldnt auto fill personal data based only on email' do
        click_link "Create new club"

        fill_in "Email", :with => user.email
        fill_in "Username", :with => username

        click_button "Create"

        page.should_not have_field("First name", :with => user.first_name)
        page.should_not have_field("Last name", :with => user.last_name)
      end

      scenario 'shouldnt auto fill personal data based only on username' do
        click_link "Create new club"

        fill_in "Email", :with => email
        fill_in "Username", :with => user.username

        click_button "Create"

        page.should_not have_field("First name", :with => user.first_name)
        page.should_not have_field("Last name", :with => user.last_name)
      end

    end

    scenario 'super-admin can create new club for existing user' do
      click_link "Create new club"

      fill_in "club_name", :with => club_name
      find("input[placeholder='Address Line 1']").set address_line_1
      find("input[placeholder='Enter a Postcode']").set postcode
      find("input[placeholder='City']").set city
      select club_type_name, :from => "club_club_type_id"

      fill_in "Email", :with => user.email
      fill_in "Username", :with => user.username

      click_button "Create"

      page.should have_content("Club was successfully created")


      club = Club.last

      club.status.should == "approved"
      club.created_by.should == super_admin
      club.admins.first.should == user

      ActionMailer::Base.deliveries.should_not be_empty
    end
  end
end
