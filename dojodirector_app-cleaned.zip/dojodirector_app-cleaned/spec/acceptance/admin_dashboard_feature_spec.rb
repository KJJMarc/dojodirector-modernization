require 'acceptance/acceptance_helper'

feature 'Admin dashboard feature' do

  let(:federation)      { create(:federation) }
  let(:user)            { create(:user) }
  let(:number_of_clubs) { 2 }

  background do
    number_of_clubs.times do
      @club = create(:club, :federation => federation)
      @club.users << user
      user.add_role :admin, @club
    end

    as_user(user)
  end

  scenario 'admin should switch between admin dashboard and user profile' do
    visit admin_venues_path

    click_link "Profile"
    current_path.should eq(user_profile_path(user))
    click_link "Admin"
    current_path.should eq(admin_venue_members_path(user.my_clubs.first))
  end

  scenario 'admin see proper numbers of clubs' do
    visit admin_venues_path
    page.should have_selector("tbody tr", :count => number_of_clubs)
  end

  scenario 'admin see proper table' do
    visit admin_venues_path

    page.should have_content("Name")
    page.should have_content("Club Type")
    page.should have_content("Federation")
    page.should have_content("Status")
    page.should have_content("Address")
  end

  scenario "admin see club attributes" do
    club = Club.first
    visit admin_venues_path

    page.should have_content(club.name)
    page.should have_content(club.club_type.type_name)
    page.should have_content(club.federation.name)
    page.should have_content(club.status)
    page.should have_content(club.address)
  end
end
