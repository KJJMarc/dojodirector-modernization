require 'acceptance/acceptance_helper'

feature 'Admin badges management feature' do
  let(:user)                    { create(:user) }
  let(:club)                    { create(:club, :club_type => club_type) }
  let(:club_type)               { create(:club_type) }
  let(:club_type_badges_count)  { 1 }
  let(:club_badges_count)       { 1 }
  let(:level)                   { create(:level, :level_group => level_group, :club_type => club_type) }
  let(:level_group)             { create(:level_group, :club_type => club_type) }
  let(:event)                   { create(:event, :club => club) }

  let(:badge) {club.badges.first}

  background do
    club_type_badges_count.times.each { create(:badge, :club_type => club.club_type) }
    club_badges_count.times.each { create(:badge, :club_type => nil, :club => club) }

    club.users << user
    user.add_role(:admin, club)
    as_user(user)

    visit admin_venue_path(club)
    click_link "No thanks, I'll do it later"
    within "div#bar ul.nav" do
      click_link "Badges"
    end
  end

  scenario 'admin should see list of available badges' do
    page.should have_content("Available badges")

    all("#badges tr.club-type").length.should eq(club_type_badges_count)
    all("#badges tr.custom").length.should eq(club_badges_count)
  end

  scenario 'admin should not delete nor edit custom badge with users' do
    create(:user_badge, :badge => club.custom_badges.first, :club => club)

    visit admin_venue_badges_path(club)

    within("table#badges tr.custom") do
      page.should have_content("1 users")
      page.should_not have_content("Edit")
      page.should_not have_content("Delete")
    end
  end

  scenario 'admin should see custom badge details' do
    create(:user_badge, :badge => club.custom_badges.first, :club => club)
    visit admin_venue_badges_path(club)

    within("table#badges tr.custom") do
      click_link "1 user"
    end

    page.should have_content("Users")
    all("table tbody tr").length.should eq(1)
  end

  scenario 'admin should see Award this badge to members button' do
    page.should have_content("Award this badge to members")
  end

  scenario 'admin should see 3 radio button on multi-award modalbox', :js => true do
    first(:link, "Award this badge to members").click
    page.should have_content "All From Group".upcase
    page.should have_content "All From Event".upcase
    page.should have_content "All Members".upcase
  end

  scenario 'admin should see dropdown with levels', :js => true do
    UserLevel.create(:user => user, :level => level, :club => club)
    click_link "Badges"

    first(:link, "Award this badge to members").click
    find('#award_multi_badge').visible?
    choose 'for_all_from_group'

    find('#level_input').click
    page.should have_content("#{level.name} (1)")
  end

  scenario 'admin should see dropdown with events', :js => true do
    event.attendees << user
    user.event_attendees.map(&:confirm)

    click_link "Badges"
    first(:link, "Award this badge to members").click
    choose 'for_all_from_event'

    find('#event_input').click
    page.should have_content("#{event.name} (1)")
  end

  scenario 'award multi-badge (club)', :js => true do
    first(:link, "Award this badge to members").click
    choose 'for_all_members'
    click_button "Award badge"

    page.should have_content("Badge has been assigned to the users".upcase)
    visit user_profile_path(user)
    page.should have_content("All members in #{club.name} were awarded #{club.badges.first.name}")
  end

  scenario 'award multi-badge (level)', :js => true do
    UserLevel.create!(:user => user, :level => level, :club => club)

    click_link "Badges"
    first(:link, "Award this badge to members").click

    choose 'for_all_from_group'
    select "#{level.name} (#{level.users_for_club(club).count})", :from => "level"
    find('#level_input').click
    page.should have_content level.name
    click_button "Award badge"

    page.should have_content("Badge has been assigned to the users".upcase)
    visit user_profile_path(user)
    page.should have_content("All #{level.name} level members were awarded #{club.badges.first.name}")
  end

  scenario 'award multi-badge (event)', :js => true do
    event.attendees << user
    user.event_attendees.map(&:confirm)

    click_link "Badges"
    first(:link, "Award this badge to members").click
    choose 'for_all_from_event'

    select "#{event.name} (#{event.attendees.count})", :from => "event"
    click_button "Award badge"

    page.should have_content "Badge has been assigned to the users".upcase
    visit user_profile_path(user)
    page.should have_content("All #{event.name} attendees were awarded #{club.badges.first.name}")
  end
end
