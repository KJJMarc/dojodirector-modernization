require 'acceptance/acceptance_helper'

feature 'Badges management' do
  let(:super_admin)   { create(:super_admin) }
  let(:user)          { create(:user) }
  let(:club_type)     { create(:club_type) }
  let(:club)          { create(:club) }
  let(:admin)         { create(:user) }
  let(:badges_count)  { 5 }

  context "super admin" do
    background do
      as_user(super_admin)
      badges_count.times.each { create(:badge, :club_type => club_type) }
      create(:user_badge, :badge => Badge.first, :user => user, :club => club)
      visit admin_club_type_path(club_type)
    end

    scenario 'super-admin should see list of badges for club type' do
      all(".badges li").length.should eq(badges_count)
    end

    scenario 'super-admin should create new badge' do
      click_link "Add Badge"
      fill_in "Name", :with => "New badge name"
      attach_file('Image', Rails.root.join('spec', 'assets', 'attachments', 'image.gif'))
      check("Allow to add title to badge when awarding")
      fill_in "badge_description", :with => "new badge description"
      click_button "Add"
      page.should have_content("Badge was successfully created.")
      page.should have_content("New badge name")
    end

    scenario 'super-admin should edit badge' do
      within ".badges li:first" do
        click_link "Edit"
      end
      fill_in "Name", :with => "Changed badge name"
      click_button "Save"
      page.should have_content("Badge was successfully updated.")
      page.should have_content("Changed badge name")
    end

    context "admin" do
      background do
        as_user(admin)
        club.users << admin
        admin.add_role :admin, club
        visit new_admin_venue_badge_path(club)
      end

      scenario 'admin should see proper message' do
        page.should have_content("Missing an important badge? "\
                                  "Let us know"\
                                  " and we will make sure it is added to Prowd.")
      end

    end
  end


end
