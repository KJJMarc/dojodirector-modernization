require 'acceptance/acceptance_helper'

feature 'Redirect to profile after login feature' do
  let(:user)        { create(:user) }
  let(:admin)       { create(:admin) }
  let(:super_admin) { create(:super_admin) }
  let(:club)        { create(:club) }

  scenario 'user should be redirected to profile page' do
    as_user(user)
    visit '/'
    current_path.should == user_profile_path(user)
  end

  scenario 'admin should be redirected to admins first club' do
    user.add_role :admin, club
    as_user(user)
    visit '/'
    current_path.should == admin_venue_members_path(club)
  end

  scenario 'super-admin should be redirected to super-admin dashboard page' do
    as_user(super_admin)
    visit '/'
    current_path.should == admin_home_path
  end

end
