require 'acceptance/acceptance_helper'

feature 'Check-ins functionality feature' do
  let(:admin)               { create(:user) }
  let(:member)              { create(:user, :first_name => "member") }
  let(:club)                { create(:club) }
  let(:number_of_check_ins) { 21 }

  background do
    number_of_check_ins.times { create(:check_in, :user => member, :club => club) }
    club.users << [admin, member]

    admin.add_role(:admin, club)
  end

  scenario 'member can check-in to club', :js => true do
    check_ins_count = club.check_ins.count
    as_user(member)
    visit "/"

    find("#show_check_in_form").click
    page.should have_selector("#checkin_modal", :visible => true)
    within("#checkin_modal") do
      fill_in "Content", :with => "Check in comment"
      select club.name, :from => "Club"
      click_button "Check in"
    end

    page.should have_content "Check in was successfully created.".upcase
    club.reload.check_ins.count.should eq(check_ins_count + 1)
  end

  scenario 'suspended member should not able to check-in' do
    member.suspend(club)
    as_user(member)
    visit "/"
    page.should have_no_selector("#show_check_in_form")
  end
end
