require 'acceptance/acceptance_helper'

feature 'Login from homepage feature' do

  let(:username) { "JamesBond" }
  let(:password) { "12345a" }
  let(:admin) { create(:admin) }
  let(:super_admin) { create(:super_admin) }
  let(:user) do
    create(
      :user,
      :password => password,
      :password_confirmation => password
    )
  end

  scenario 'user see login button on homepage' do
    visit '/'
    page.should have_selector('a[href="/users/sign_in"]', :text => "Login")
  end

  context do
    let(:user_2) { create(:user, :username => username, :password => password, :password_confirmation => password) }

    scenario 'user login with case sensitive username', :js => true do
      visit '/'
      click_link "Login"

      within("#new_user_short") do
        fill_in "user_username", :with => user_2.username
        fill_in "user_password", :with => user_2.password
        click_button "Login"
      end

      page.should have_content(user_2.full_name)

      click_link user_2.full_name
      page.should have_content("Edit profile")
    end
  end

  scenario 'user login from homepage', :js => true do
    visit '/'
    click_link "Login"

    within("#new_user_short") do
      fill_in "user_username", :with => user.username
      fill_in "user_password", :with => user.password
      click_button "Login"
    end

    page.should have_content(user.full_name)

    click_link user.full_name
    page.should have_content("Edit profile")
  end

  scenario 'user see facebook connect button on homepage', :js => true do
    visit '/'
    page.should have_xpath("//a[contains(@href, '/auth/facebook')]")
  end

  context 'facebook integration' do

    scenario 'user sign in using facebook account' do
      uid = SecureRandom.base64
      user.update_attribute(:facebook_uid, uid)
      OmniAuth.config.add_mock(:facebook, {:uid => uid})

      visit '/'
      within("#new_user_short") do
        find(:xpath, "//a[contains(@href, '/auth/facebook')]").click
      end

      page.should have_content("Edit profile")
    end

    scenario 'redirect to login page when user facebook account is not connected' do
      uid = SecureRandom.base64
      user.update_attribute(:facebook_uid, uid)
      OmniAuth.config.add_mock(:facebook, {:uid => 'not_connected'})

      visit '/'
      within("#new_user_short") do
        find(:xpath, "//a[contains(@href, '/auth/facebook')]").click
      end

      page.should have_content I18n.t('flash.unconnected', :scope => 'authentications')
    end

    scenario 'redirect to login page when omniauth return error' do
      OmniAuth.config.mock_auth[:facebook] = :invalid_credentials

      visit '/'
      within("#new_user_short") do
        find(:xpath, "//a[contains(@href, '/auth/facebook')]").click
      end

      page.should have_content I18n.t('flash.provider_error', :message => 'invalid credentials', :scope => 'authentications')
    end
  end

end
