require 'acceptance/acceptance_helper'

feature 'Super admin users management' do
  let(:super_admin) { create(:super_admin) }
  let(:users_count) { 5 }
  let(:clubs_count) { 5 }

  background do
    as_user(super_admin)
    users_count.times      { |n| create(:user) }
    visit admin_home_path
  end

  scenario 'super-admin should see list of all users' do
    click_link "See all users"
    page.should have_content("Users")
    all("#users tbody tr").count.should eq(users_count + 1)
  end

  scenario 'super-admin should see user details' do
    click_link "See all users"
    user = User.first
    within("#users") do
      click_link "#{user.first_name} #{user.last_name}"
    end

    page.should have_content("Name: #{user.first_name} #{user.last_name}")
    page.should have_content("Email: #{user.email}")
    page.should have_content("Gender: #{user.gender}")
    page.should have_content("Address: #{user.address}")
    page.should have_content("Sign in count: #{user.sign_in_count}")
  end

  scenario 'super admin should see user clubs' do
    click_link "See all users"
    user = User.first
    clubs_count.times { user.clubs << create(:club) }

    within("#users") do
      click_link "#{user.first_name} #{user.last_name}"
    end

    all("#clubs tbody tr").count.should eq(clubs_count)
  end
end
