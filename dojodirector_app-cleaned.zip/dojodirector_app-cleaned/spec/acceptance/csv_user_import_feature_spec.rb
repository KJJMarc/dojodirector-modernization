require 'acceptance/acceptance_helper'

feature 'Csv user import feature' do
  let(:user)          { create(:user) }
  let(:club)          { create(:club) }
  let(:phone_number)  { "212121" }

  background do
    as_user(user)
    club.users << user
    user.add_role :admin, club
    create :level, :club_type => club.club_type

    @old_count = club.users.count
    visit new_admin_venue_member_path(club)
  end

  scenario 'admin should see sample csv file download link' do
    click_link "Add Members from csv"
    page.should have_selector("a", :text => "Download sample CSV file")
  end

  scenario 'admin click on csv import link and should see import instructions' do
    click_link "Add Members from csv"
    page.should have_content("All fields with a red background are required")
    page.should have_selector("tr .required", :count => 3)
    page.should have_selector("tr .optional", :count => 13)
  end

  scenario 'admin click on upload button without select file' do
    click_link "Add Members from csv"
    click_button "Upload"

    page.should have_content("csv can't be blank")
  end

  context 'with valid csv file' do
    before do
      click_link "Add Members from csv"
      attach_file('user_import[original_csv]', Rails.root.join('spec', 'assets', 'attachments', 'csv.csv'))
      click_button "Upload"
    end

    scenario 'admin can see import being processed' do
      page.should have_content("processing")
      page.should have_selector("tr.processing", :count => 1)
    end

    context 'when import is processed' do
      before do
        UserImport.last.process_csv!
        visit admin_venue_imports_path(club)
      end

      scenario 'admin can see complete import' do
        club.users.count.should == @old_count + 5
        page.should have_content("complete")
        page.should have_selector("tr.complete", :count => 1)
      end

      scenario 'admin can download csv files with failed rows' do
        page.should have_selector("tr.complete a.download", :text => 'Download failed rows csv')
      end
    end
  end
  
  scenario 'optional information should be imported' do
    click_link "Add Members from csv"
    attach_file('user_import[original_csv]', Rails.root.join('spec', 'assets', 'attachments', 'csv.csv'))
    click_button "Upload"

    UserImport.last.process_csv!

    User.find_by_username("james").extra_information.should_not be_nil
  end

  context "import already existed user" do
    before do
      @existing_user = create(:user, :email => "james@bond.com", :first_name => "James", :last_name => "Bond")
      @existing_club = create(:club)
      @existing_club.users << @existing_user
    end

    scenario 'in csv is already existing user' do
      save_and_open_page
      click_link "Add Members from csv"
      attach_file('user_import[original_csv]', Rails.root.join('spec', 'assets', 'attachments', 'csv.csv'))
      click_button "Upload"

      UserImport.last.process_csv!

      @existing_user.reload.clubs.count.should == 2
    end
  end
end
