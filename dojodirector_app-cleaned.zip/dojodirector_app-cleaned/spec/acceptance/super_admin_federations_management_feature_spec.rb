require 'acceptance/acceptance_helper'

feature 'Super admin federations management' do
  let(:super_admin)        { create(:super_admin) }
  let(:user)               { create(:user) }
  let(:club_type)          { create(:club_type) }
  let(:federations_count)  { 5 }
  let(:clubs_count)        { 5 }

  background do
    as_user(super_admin)
    federations_count.times { create(:federation, :club_type => club_type) }
    clubs_count.times { Federation.first.clubs << create(:club, :club_type => club_type) }

    visit admin_club_type_path(club_type)
  end

  scenario 'super-admin should see list of federations for club type' do
    all("#federations tbody tr").length.should eq(federations_count)
  end

  scenario 'super-admin should create new federation' do
    click_link "Add Federation"
    fill_in "Name", :with => "New federation"
    click_button "Add"
    page.should have_content("Federation was successfully created.")
    page.should have_content("New federation")
  end

  scenario 'super-admin should edit federation' do
    within("#federations tbody tr:first") do
      find(:xpath, ".//a[text()='Edit']").click
    end
    page.should have_content("Edit Federation")
    fill_in "Name", :with => "Changed federation name"
    click_button "Save"
    page.should have_content("Federation was successfully updated.")
    page.should have_content("Changed federation name")
  end

  scenario 'super-admin should delete federation' do
    within("#federations tbody tr:first") do
      find(:xpath, ".//a[text()='Delete']").click
    end
    page.should have_content("Federation was successfully destroyed.")
    all("#federations tbody tr").length.should eq(federations_count - 1)
  end

  scenario 'super-admin should see list of clubs in federation' do
    within("#federations tbody tr:first") do
      click_link 'Show all clubs'
    end
    all("#clubs tbody tr").length.should eq(Federation.first.clubs.count)
  end
end
