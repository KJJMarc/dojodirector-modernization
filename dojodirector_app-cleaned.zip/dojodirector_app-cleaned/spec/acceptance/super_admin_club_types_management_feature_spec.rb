require 'acceptance/acceptance_helper'

feature 'Super admin club types management' do
  let(:super_admin)       { create(:super_admin) }
  let(:user)              { create(:user) }
  let(:club)              { Club.last }
  let(:club_type)         { club.club_type }
  let(:club_types_count)  { 2 }

  background do
    as_user(super_admin)
    club_types_count.times.each do |n|
      club_type = create(:club_type, :type_name => "club type #{n}")
      create(:club, :club_type => club_type)
    end
  end

  scenario 'super-admin should can create new club type' do
    visit admin_club_types_path
    click_link "Create new club type"
    fill_in "Type name", :with => "New club type"
    attach_file('Header image', Rails.root.join('spec', 'assets', 'attachments', 'image.gif'))
    click_button "Add"
    page.should have_content("Successfully created!")
  end

  scenario 'image uploaded by super admin should appear on the club pages' do
    visit admin_club_types_path
    click_link "Create new club type"
    fill_in "Type name", :with => "New club type"
    attach_file('Header image', Rails.root.join('spec', 'assets', 'attachments', 'image.gif'))
    click_button "Add"

    club_type = ClubType.last
    club = create(:club, :club_type => club_type)

    {
      club_path(club) => 'header',
      admin_venue_members_path(club) => 'header'
    }.
      each do |path,css|
        visit path
        page.find("div##{css}")['style'].should include("background-image: url(")
        page.find("div##{css}")['style'].should include(club_type.header_image.url(:full))
    end
  end

  scenario 'super-admin should can edit club type' do
    visit admin_club_types_path
    click_link club_type.type_name
    within("#details") do
      click_link "Edit"
    end
    fill_in "Type name", :with => "Changed name"
    check "Levels have tokens"
    click_button "Save"
    page.should have_content("Successfully changed!")

    club_type.reload.tap do |ct|
      ct.type_name.should == "Changed name"
      ct.token_criteria.should be_true
    end
  end

  scenario 'super-admin should can see club type list' do
    visit admin_club_types_path
    all("tr").length.should eq(club_types_count)
  end

  scenario 'super-admin should can see token criteria settings' do
    visit admin_club_types_path
    page.should have_content("Levels have tokens")
  end

  scenario 'super-admin should see clubs of this club-type', :js => true do
    visit admin_club_types_path
    click_link club_type.type_name
    within('#clubTypeTabs') do
      click_link "Clubs"
    end

    page.should have_content(club.name)
  end
end
