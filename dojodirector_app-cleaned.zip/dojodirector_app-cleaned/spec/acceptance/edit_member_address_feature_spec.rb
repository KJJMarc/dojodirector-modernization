require 'acceptance/acceptance_helper'

feature 'Edit member address feature' do

  let(:user)      { FactoryGirl.create(:user) }
  let(:member)    { FactoryGirl.create(:user) }
  let(:club)      { FactoryGirl.create(:club) }
  let(:address_line_1)   { "Sample 12" }
  let(:postcode)  { "EC1R 1UP" }
  let(:city)      { "New york" }

  background do
    user.add_role :admin, club
    club.users << member
    member.add_role :member, club
    as_user(user)
    visit admin_venue_members_path(club)
  end

  scenario 'admin of club should see empty address' do
    page.should have_content(member.full_name)
  end

  scenario 'admin should see address related things on members details' do
    within "tr#details-#{member.id}" do
      click_link "Manage member"
    end

    page.should have_content("Address")
  end


  scenario 'admin can edit address related things on members details' do
    within "tr#details-#{member.id}" do
      click_link "Manage member"
    end

    within("dl.box-content") do
      click_link "Edit"
    end

    find("input[placeholder='Address Line 1']").set address_line_1
    find("input[placeholder='Enter a Postcode']").set postcode
    find("input[placeholder='City']").set city
    
    click_button "Save"

    page.should have_content(address_line_1)
    page.should have_content(postcode)
    page.should have_content(city)
  end
end
