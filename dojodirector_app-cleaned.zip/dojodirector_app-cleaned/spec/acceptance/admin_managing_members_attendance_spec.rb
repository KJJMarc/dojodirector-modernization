require 'acceptance/acceptance_helper'

feature 'Admin managing members attendance', :js => true, :driver => :webkit do

  let(:user)          { create(:user) }
  let(:admin)         { create(:user) }
  let(:club)          { create(:club) }

  let(:day)           { 10 }
  let(:month)         { Date.today.month }
  let(:event) do
    create(:event,  :club => club,
                    :start_date => Date.new(Date.today.year, month, day).to_s,
                    :status => "active")
  end

  let(:attendance_date) { 2.days.ago.to_date }
  let(:attendance)    { create(:attendance, 
                               :user => user, 
                               :club => club, 
                               :date => attendance_date) }
  background do
    club.users << user
    user.add_role :member, club
    admin.add_role :super_admin

    as_user(admin)
  end

  context "without attendances" do
    before do
      event
      visit user_club_attendance_path(user, club)
    end

    scenario 'admin can mark event attendance on attendance sheet' do
      date = event.scheduled_at.strftime('%Y-%m-%d')
      time = event.scheduled_at.strftime("%I:%M %P")

      cell = attendance_cell date
      cell['class'].should_not =~ /event/
      cell.click

      within("#attendance_#{date}_modal") do
        page.should have_content("#{time} #{event.name}")

        label = find(:xpath, "//label[@for='event_#{event.id}']")

        label.click
        click_on "Update"
      end

      cell = attendance_cell date
      cell.should have_content "X"
    end

    scenario 'admin can mark daily attendance on attendance sheet' do
      date = attendance_date.strftime('%Y-%m-%d')

      cell = attendance_cell date
      cell.should_not have_content "X"
      cell.click

      within("#attendance_#{date}_modal") do
        label = find(:xpath, "//label[@for='attendance_#{date}']")

        label.click
        click_on "Update"
      end

      cell = attendance_cell date
      cell.should have_content "X"
    end
  end

  context 'with an existing event attendance' do
    before do
      user.events << event
      event.confirm(user)

      visit user_club_attendance_path(user, club)
    end

    scenario 'admin should see and remove event attendance in popup' do
      date = event.scheduled_at.strftime('%Y-%m-%d')
      cell = attendance_cell date

      cell.should have_content "X"
      cell.click

      within("#attendance_#{date}_modal") do
        page.should have_content(event.name)

        label = find(:xpath, "//label[@for='event_#{event.id}']")

        label.click
        click_on "Update"
      end

      cell = attendance_cell date
      cell.should_not have_content "X"
    end
  end

  context 'with an existing daily attendance' do
    before do
      attendance
      visit user_club_attendance_path(user, club)
    end

    scenario 'admin should see and remove daily attendance in popup' do
      date = attendance.date.strftime('%Y-%m-%d')

      cell = attendance_cell date
      cell.should have_content "X"
      cell.click

      within("#attendance_#{date}_modal") do
        label = page.find(:xpath, "//label[@for='attendance_#{date}']", :visible => true)
        label.click
        click_on "Update"
      end

      cell = attendance_cell date
      cell.should_not have_content "X"
    end
  end
 
  scenario 'admin should be able to print attendance sheet with qr codes' do
    visit user_club_attendance_path(user, club)
    all(".qrCode", :visible => true).length.should eq(1)
    click_link "Print"
  end
end
