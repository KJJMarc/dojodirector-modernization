require 'acceptance/acceptance_helper'

feature 'Super admin levels management' do
  let(:super_admin) { create(:super_admin) }
  let(:user)        { create(:user) }
  let(:club_type)   { create(:club_type) }
  let(:level_group) { create(:level_group) }
  let(:levels_count){ 6 }
  let(:level_groups_count){ 2 }

  background do
    as_user(super_admin)
    level_groups_count.times.each { club_type.level_groups << create(:level_group) }

    # levels in first group
    (levels_count / 2).times.each { club_type.levels << create(:level, :level_group => club_type.level_groups.first) }
    # levels in second group
    (levels_count / 2).times.each { club_type.levels << create(:level, :level_group => club_type.level_groups.last) }

    visit admin_club_type_path(club_type)
  end

  scenario 'super-admin should see list of group levels for club type' do
    all(".group-level").length.should eq(level_groups_count)
  end

  scenario 'super-admin should see list of levels for club type' do
    all(".level").length.should eq(levels_count)
  end

  scenario 'super-admin should see list of levels within first group' do
    within "#level_groups_#{club_type.level_groups.first.id}" do
      all(".level").length.should eq(levels_count / 2)
    end
  end

  scenario 'super-admin should create new level group' do
    click_link "Add new Group"
    fill_in "Name", :with => "New Group name"
    click_button "Add"

    page.should have_content("Level group was successfully created.")
    within "#level_groups_#{LevelGroup.last.id}" do
      page.should have_content("New Group name")
    end
  end

  scenario 'super-admin should edit level group' do
    within "#level_groups_#{LevelGroup.last.id}" do
      click_link "Change name"
    end

    fill_in "Name", :with => "Completely new group name"
    click_button "Save"
    page.should have_content "Completely new group name"
  end

  scenario 'super-admin should remove level group' do
    level_group = LevelGroup.last

    within "#level_groups_#{level_group.id} h4.name" do
      click_link "Remove"
    end

    page.should_not have_content level_group.name
  end

  scenario 'super-admin should create new level' do
    within "#level_groups_#{club_type.level_groups.last.id}" do
      click_link "Add Level"
    end

    fill_in "Name", :with => "New level name"
    attach_file('Image', Rails.root.join('spec', 'assets', 'attachments', 'image.gif'))
    click_button "Add"

    page.should have_content("Level was successfully created.")
    within "#level_groups_#{club_type.level_groups.last.id}" do
      page.should have_content("New level name")
    end
  end

  scenario 'super-admin should edit existing level' do
    level = create(:level, :level_group => level_group, :club_type => level_group.club_type)
    visit admin_club_type_path(level_group.club_type)

    within "#levels_#{level.id}" do
      click_link "Edit"
    end

    fill_in "Name", :with => "new level name 123"
    click_button "Save"

    within "#levels_#{level.id}" do
      page.should have_content("new level name 123")
    end
  end

  scenario 'super-admin should remove existing level' do
    level = create(:level, :level_group => level_group, :club_type => level_group.club_type)

    visit admin_club_type_path(level_group.club_type)

    within "#levels_#{level.id}" do
      click_link "Remove"
    end

    page.should have_content("Level was successfully destroyed")

    within "#level_groups_#{level_group.id}" do
      page.should_not have_content(level.name)
    end
  end

  scenario 'super admin should change position of level' do
    pending "research needed"
    within "#level_groups_#{club_type.level_groups.first.id}" do
      find(".level:first").should have_content("Level name 1")
      first_element_position  = find("#levels_#{club_type.level_groups.first.levels.first.id}")
      last_element_position  = find("#levels_#{club_type.level_groups.first.levels.last.id}")
      first_element_position.drag_to(last_element_position)
    end
  end
end
