module HelperMethods
  def register_owner
    visit new_owner_registration_path

    fill_owner_form
    click_button "Register your club"
  end

  def fill_owner_form
    within(".new_club") do
      fill_in "club_name",  :with => club_name
      fill_in "club_users_attributes_0_first_name", :with => last_name
      fill_in "club_users_attributes_0_last_name", :with => first_name
      fill_in "club_users_attributes_0_username", :with => username
      fill_in "club_users_attributes_0_email", :with => email
      fill_in "club_users_attributes_0_password", :with => password
      within("#club_details") do
        page.find(:xpath, "//li[text()='#{club_type}']").click
      end
    end
  end

  def reset_password
    visit '/users/sign_in'
    click_link 'Forgot Password?'
    within(".new_password") do
      fill_in "Username", :with => user.username
      click_button "Submit"
    end
  end

  def select_date(date, options = {})
    raise ArgumentError, 'from is a required option' if options[:from].blank?
    field = options[:from].to_s
    select date.year.to_s,               :from => "#{field}_1i"
    select Date::MONTHNAMES[date.month], :from => "#{field}_2i"
    select date.day.to_s,                :from => "#{field}_3i"
  end

  def wait_for_ajax
    page.evaluate_script('$.active') == 0
    yield if block_given?
  end

  def attendance_cell date
    page.find(:xpath, "//table[@class='attendance']/tbody/tr/td[@id='#{date}']")
  end
end

RSpec.configuration.include HelperMethods, :type => :acceptance
