require 'acceptance/acceptance_helper'

feature 'Detailed badge' do
  let(:user)        { create(:user) }
  let(:alice)       { create(:user) }
  let(:club_type)   { create(:club_type) }
  let(:club)        { create(:club, :club_type => club_type) }
  let(:user_badge)  { create(:user_badge, :badge => badge, :user => user, :club => club, :featured => true) }
  let!(:badge)      { create(:badge, :club_type => club_type) }

  background do
    ActiveRecord::Observer.enable_observers
    user_badge
    club.users << [user, alice]
    as_user(user)
  end

  after do
    ActiveRecord::Observer.disable_observers
  end

  scenario 'user should see badge information after', :js => true do
    visit user_profile_path(user)
    within("#badges") do
      find(".badge-image").click
    end

    page.should have_selector("#badge_#{user_badge.id}_modal", :visible => true)
    should_see_detailed_information(badge)
  end

  scenario 'badge popup should work on news feed', :js => true do
    visit user_profile_path(user)
    within(".box_left") do
      find(".badge-image").click
    end

    page.should have_selector("#badge_#{user_badge.id}_modal", :visible => true)
    should_see_detailed_information(badge)
  end

  scenario 'badge popup should work on badge index', :js => true do
    visit user_profile_path(user)

    within("#badges") do
      click_link "View all"
    end

    within(".badges-list") do
      find(".badge-image").click
    end

    page.should have_selector("#badge_#{user_badge.id}_modal", :visible => true)
    should_see_detailed_information(badge)
  end

  scenario 'badge view' do
    visit user_badge_path(user, badge)
    should_see_detailed_information(badge, false)
  end

  scenario 'popup should have link to badge view', :js => true do
    visit user_profile_path(user)

    within("#badges") do
      find(".badge-image").click
    end

    page.should have_link("See how they will see your badge", {:href => user_badge_path(user, badge), :visible => true})
  end

  scenario 'admin popup on manage member page', :js => true do
    visit admin_venue_member_path(club, user)

    within(".badges-list") do
      find(".badge-image").click
    end

    page.should have_selector("#badge_#{user_badge.id}_modal", :visible => true)
    should_see_detailed_information(badge)
  end
end

def should_see_detailed_information(badge, upcase = true)
  page.should have_content (upcase ? badge.name.upcase : badge.name)
  page.should have_content(user_badge.title)
  page.should have_content("Issused at #{user_badge.created_at.strftime('%H:%M%p')}"\
                              " on #{user_badge.created_at.strftime('%d/%m/%y')} by #{club.name}")
end
