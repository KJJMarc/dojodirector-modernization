require 'acceptance/acceptance_helper'

feature 'Super admin dashboard page' do
  let(:super_admin)   { create(:super_admin) }
  let(:clubs_count)   { 3 }
  let(:users_count)   { 5 }
  let(:club)          { Club.last }
  let(:user)          { User.last }

  background do
    as_user(super_admin)

    clubs_count.times      { create(:club, :status => "pending") }
    users_count.times      { create(:user) }

    Club.first.approve
    User.last.update_attribute(:last_sign_in_at, 2.weeks.ago)

    visit admin_home_path
  end

  scenario 'super-admin should see pending clubs' do
    visit admin_home_path

    page.should have_content("Waiting for approval")
    within("#pending_clubs") do
      all("tr").count.should == clubs_count
    end
  end

  scenario 'super-admin should not see empty pending clubs table' do
    Club.all.map(&:approve)
    visit admin_home_path

    page.should have_content("There are no clubs waiting for approval")
  end

  scenario 'super-admin should switch between super-admin dashboard and user profile' do
    visit admin_home_path

    click_link "Profile"
    current_path.should eq(user_profile_path(super_admin))
    click_link "Admin"
    current_path.should eq(admin_home_path)
  end

  scenario 'super-admin should see number of clubs on dashboard' do
    page.should have_content("Number of registered clubs #{clubs_count}")
  end

  scenario 'super-admin should see number of approved clubs on dashboard' do
    page.should have_content("Number of approved clubs 1")
  end

  scenario 'super-admin should see table with recent pending clubs on dashboard' do
    within "#pending_clubs" do
      all("tbody tr").length.should eq(clubs_count - 1)
    end
  end

  scenario 'super-admin should see number of registered users on dashboard' do
    page.should have_content("Number of registered users: #{users_count + 1 +clubs_count}") # users + admin + club's owners
  end

  scenario 'super-admin should see number of active users on dashboard' do
    page.should have_content("Number of active users: 2") # user + admin
  end

  scenario 'super-admin should see number of active users in last week on dashboard' do
    page.should have_content("Number of active users in last week: 1") # only admin
  end

  scenario 'super-admin should see table with recent users on dashboard' do
    within "#recent_users" do
      all("tbody tr").length.should eq(users_count)
    end
  end

  scenario 'super-admin after click on club on dashboard should be on venue page' do
    click_link(club.name)
    current_path.should == admin_venue_members_path(club)
  end

  scenario 'super-admin see list of users with profile path' do
    visit "/"
    page.should have_link("(public profile)", :href => user_profile_path(user))
  end

end
