require 'acceptance/acceptance_helper'

feature 'Edit user phone number feature' do
  let(:user)          { create(:user) }
  let(:admin)         { create(:user, :first_name => "Admin") }
  let(:club)          { create(:club) }
  let(:phone_number)  { "12345" }

  background do
    admin.add_role :admin, club
    user.add_role :member, club
    club.users << [admin, user]
  end

  scenario 'admin can edit use phone number', :js => true do
    as_user(admin)
    visit admin_venue_members_path(club)
    fill_in "query", :with => user.email
    click_button "search"
    within("tr#details-#{user.id}") do
      click_link "Manage member"
    end

    page.should have_content "Phone number"

    within("dl.box-content") do
      click_link "Edit"
    end
    fill_in "Phone number", :with => phone_number
    click_button "Save"

    page.should have_content "User was successfully updated".upcase
    page.should have_content "Phone number:#{phone_number}"
  end
end
