require 'acceptance/acceptance_helper'

feature 'Group message' do
  let(:club)  { create(:club) }
  let(:user)  { create(:user) }
  let(:email) { "eve@example.com" }
  let(:topic) { "Topic" }
  let(:body)  { "Body" }
  let(:eve)   { create(:user, :email => email) }

  background do
    user.add_role :admin, club
    eve.add_role :member, club

    club.users << [user, eve]
    as_user(user)
  end

  scenario 'admin send group message to users' do
    visit admin_venue_members_path(club)
    fill_in "query", :with => "eve"
    click_button "search"
    click_link "Send message"

    fill_in "Topic", :with => topic
    fill_in "Body", :with => body
    click_button "Send"

    as_user(eve) do
      visit "/"
      page.should have_content("Messages (1)")
      click_link "Messages (1)"
      page.should have_content(topic)
      page.should have_content(user.full_name)
      click_link topic
      page.should have_content(body)
    end
  end

  scenario 'form on group message should validate' do
    pending 'outdated'

    visit admin_venue_members_path(club)
    fill_in "Topic", :with => topic
    click_button "Send"

    page.should have_selector(".field_with_errors")
  end
end

feature 'Messages feature' do
  let(:alice)       { create(:user) }
  let(:bob)         { create(:user) }
  let(:title)       { "Title" }
  let(:body)        { "Body" }
  let(:reply_title) { "Reply title" }
  let(:reply_body)  { "Reply body" }
  let(:club)        { create(:club) }

  background do
    club.users << [alice, bob]
    ActionMailer::Base.deliveries.clear

    as_user(alice) do
      visit user_profile_path(bob)
      click_link "Send message"
      fill_in "Topic", :with => title
      fill_in "Body", :with => body
      click_button "Send"
      click_link "Logout"
    end
  end

  scenario 'user should be notify about message' do
    ActionMailer::Base.deliveries.should_not be_empty
    email = ActionMailer::Base.deliveries.first

    bob.email.should == bob.email
    email.body.should include(body)
    email.subject.should == title
  end

  scenario 'bob should not see send message button' do
    as_user(bob) do
      visit user_profile_path(bob)
      within("#profile_nav") do
        page.should_not have_content("Send message")
      end
    end
  end

  scenario 'alice should see send message button' do
    as_user(alice) do
      visit user_profile_path(bob)
      page.should have_content("Send message")
    end
  end

  scenario 'alice send message to bob' do
    as_user(bob) do
      visit "/"
      page.should have_content("Messages (1)")
      click_link "Messages (1)"
      page.should have_content(alice.full_name)
      page.should have_content(title)

      click_link title
      page.should have_content(body)
    end
  end

  scenario 'user read message' do
    as_user(bob) do
      visit "/"
      page.should have_content("Messages (1)")
      click_link "Messages (1)"
      click_link title
      page.should have_content("Messages (0)")
    end
  end

  scenario "user send message to himself" do
    as_user(bob) do
      visit new_user_message_path(bob)
      fill_in "Topic", :with => title
      fill_in "Body", :with => body
      click_button "Send"
      page.should have_content("You cannot send message to yourself")
    end
  end

  scenario 'user reply do message' do
    pending
    as_user(bob) do
      visit "/"
      click_link "Messages (1)"
      click_link title
      click_link "Reply"
      fill_in "Topic", :with => reply_title
      fill_in "Body", :with => reply_body
      click_button "Send"
    end

    as_user(alice) do
      visit "/"
      page.should have_content("Messages (1)")
      click_link "Messages (1)"
      click_link reply_title
      page.should have_content(reply_body)
    end
  end

  context "user roles in messages" do
    background do
      bob.add_role(:admin, club)
      bob.add_role(:member, club)
      bob.add_role(:super_admin)
      bob.send_message(alice, "Hi", "there")
    end

    it "should see alice roles on inbox" do
      as_user(alice) do
        visit "/"
        click_link "Messages (1)"
        page.should have_content("super_admin")
        page.should have_content("admin")
        page.should have_content("member")
      end
    end
  end
end
