require 'acceptance/acceptance_helper'

feature 'Menu feature' do
  let(:admin) do
    user = create(:user)
    club.users << user
    user.add_role :admin, club

    user
  end

  let(:member) do
    member = create(:user)
    club.users << member
    member.add_role :member, club

    member
  end

  let(:super_admin) { create(:super_admin) }

  let(:club) { create(:club) }

  scenario 'user should not see venues' do
    as_user(member) do
      visit "/"
      page.should_not have_content("Clubs")
    end
  end

  scenario 'admin should see venues' do
    as_user(admin) do
      visit "/"
      page.should have_content("Clubs")
    end
  end

  scenario 'super-admin should see venues' do
    as_user(super_admin) do
      visit "/"
      page.should have_content("Clubs")
    end
  end
end
