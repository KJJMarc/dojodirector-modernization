require 'acceptance/acceptance_helper'

feature 'Owner registration feature' do
  let(:username)                  { "jamesbond" }
  let(:first_name)                { "James" }
  let(:last_name)                 { "Bond" }
  let(:club_name)                 { "James Bond Club" }
  let(:email)                     { "james@bond.com" }
  let(:password)                  { "password" }
  let(:password_confirmation)     { password }
  let(:club_type_object)          { ClubType.first }
  let(:club_type)                 { club_type_object.type_name }
  let(:federation)                { club_type_object.federations.first }
  let(:federation_name)           { federation.name }
  let(:gender)                    { "Male" }
  let(:birthday)                  { Date.parse("2011/01/01") }

  before { 2.times { create(:federation) } }

  scenario 'owner create account and club', :js => true do
    pending 'Problem with devise_invitable gem'
    register_owner

    page.should have_content "Welcome! You have signed up successfully.".upcase
    current_path.should eq(admin_venue_members_path(Club.last))
    Club.last.created_by.should == User.last
  end

  context "without club name" do
    let(:club_name) { nil }

    scenario 'owner create account without club name', :js => true do
      register_owner
      page.should_not have_content "Welcome! You have signed up successfully.".upcase
    end
  end

  context "without password" do
    let(:password) { nil }

    scenario 'owner create account without proper password', :js => true do
      register_owner
      page.should_not have_content "Welcome! You have signed up successfully.".upcase
    end
  end

  context "without username" do
    let(:username) { nil }

    scenario 'owner create account without unique username generates username', :js => true do
      register_owner
      page.should have_content "Welcome! You have signed up successfully.".upcase
      User.last.username.should_not be_blank
    end
  end

  scenario "user select club type and should see associated federations", :js => true do
    #TODO: those actions should be made into helper methods
    visit new_owner_registration_path

    find('input#club_club_type_id_input').click
    find("#club_club_type_id_input_#{club_type_object.id}").click

    find('label[for=federation_yes]').click

    find('input#user_clubs_attributes_0_federation_id_input').click
    page.should have_content federation_name
  end

  scenario "user select club type but don't select federations", :js => true do
    visit new_owner_registration_path
    select club_type, :from => "club_club_type_id"
    find('li', :text => federation_name).should_not be_visible
  end

  scenario "user select federations and after that select club type", :js => true do
    visit new_owner_registration_path

    find('input#club_club_type_id_input').click
    find("#club_club_type_id_input_#{club_type_object.id}").click

    find('label[for=federation_yes]').click

    find('input#user_clubs_attributes_0_federation_id_input').click

    page.should have_content(federation_name)

    choose "federation_no"
    !page.find('#federation_select_box').visible?
  end

  context "from homepage" do
    scenario "user register with short form from carousel", :js => true do
      visit root_path

      within("div#homepage-carousel") do
        fill_in "club_name", :with => club_name
        click_button "Sign Up"
      end

      find_field("club_name").value.should == club_name
    end

    scenario "user type club name from homepage carousel and try register via popup", :js => true do
      visit root_path

      within("div#homepage-carousel") do
        fill_in "club_name", :with => club_name
        click_button "Sign Up"
      end

      fill_owner_form
      click_button "Register your club"

      page.should have_content "Welcome! You have signed up successfully.".upcase
      current_path.should eq(admin_venue_members_path(Club.last))
    end

    scenario "user register with short form from bottom header", :js => true do
      visit root_path

      within("div#signup-end") do
        fill_in "club_name", :with => club_name
        click_button "Club Sign Up"
      end

      find_field("club_name").value.should == club_name
    end

    scenario "user type club name from homepage bottom header and try register via popup", :js => true do
      visit root_path

      within("div#signup-end") do
        fill_in "club_name", :with => club_name
        click_button "Club Sign Up"
      end

      fill_owner_form
      click_button "Register your club"

      page.should have_content "Welcome! You have signed up successfully.".upcase
      current_path.should eq(admin_venue_members_path(Club.last))
    end
  end
end
