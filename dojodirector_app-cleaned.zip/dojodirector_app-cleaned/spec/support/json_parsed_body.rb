module JSONParsedBody
  def parsed_body
    ActiveSupport::JSON.decode(response.body).with_indifferent_access
  end
end