require 'spec_helper'

shared_examples_for "user badges in API" do
  include_examples "base badges in API"

  it "returns title of user badge" do
    parsed_badge[:title].should == user_badge_to_check.title
  end

  it "returns club name of user badge" do
    parsed_badge[:club_name].should == user_badge_to_check.club.name
  end

  it "returns club id of user badge" do
    parsed_badge[:club_id].should == user_badge_to_check.club_id
  end
end

shared_examples_for "badges in API" do
  include_examples "base badges in API"

  it "returns club_id of badge" do
    parsed_badge[:club_id].should == badge_to_check.club_id
  end

end

shared_examples_for "base badges in API" do
  it "returns id of badges" do
    parsed_badge[:id].should == badge_to_check.id
  end

  it "returns name of badge" do
    parsed_badge[:name].should == badge_to_check.name
  end

  it "returns description of badge" do
    parsed_badge[:description].should == badge_to_check.description
  end

  it "returns image url of badge" do
    parsed_badge[:image_url].should == "#{request.protocol}#{request.host_with_port}#{badge_to_check.image.url(:medium)}"
  end
end
