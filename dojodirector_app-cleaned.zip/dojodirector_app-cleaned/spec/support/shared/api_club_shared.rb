shared_examples_for "clubs in API" do
  it "returns id of club" do
    parsed_club[:id].should == club.id
  end

  it "returns name of club" do
    parsed_club[:name].should == club.name
  end

  it "returns logo of club" do
    parsed_club[:logo_url].should == "#{request.protocol}#{request.host_with_port}#{club.logo.url(:medium)}"
  end

  it "returns status of club" do
    parsed_club[:status].should == club.status
  end

  it "returns twitter url of club" do
    parsed_club[:twitter_url].should == club.twitter_url
  end

  it "returns facebook url of club" do
    parsed_club[:facebook_url].should == club.facebook_url
  end

  it "returns website url of club" do
    parsed_club[:website_url].should == club.website_url
  end

  it "returns phone_number of club" do
    parsed_club[:phone_number].should == club.phone_number.to_s
  end

  it "returns emergency_phone_number of club" do
    parsed_club[:emergency_phone_number].should == club.emergency_phone_number.to_s
  end
end