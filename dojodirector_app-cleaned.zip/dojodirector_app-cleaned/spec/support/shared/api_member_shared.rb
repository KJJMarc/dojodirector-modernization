shared_examples_for "member in API" do
  it "returns user id" do
    parsed_member[:id].should == user.id
  end

  it "returns user email" do
    parsed_member[:email].should == user.email
  end

  it "returns user statement" do
    parsed_member[:statement].should == user.statement
  end

  it "returns avatar url" do
    parsed_member[:avatar_url].should == user.avatar.url(:medium)
  end
end