shared_examples_for "clubs type in API" do
  it "returns id of club_type" do
    parsed_club_type[:id].should == club_type_to_check.id
  end

  it "returns type name of club_type" do
    parsed_club_type[:type_name].should == club_type_to_check.type_name
  end

  it "returns token_criteria of club_type" do
    parsed_club_type[:token_criteria].should == club_type_to_check.token_criteria
  end
end