shared_examples_for "check_in in API" do
  it "returns id of check_in" do
    parsed_check_in[:id].should == check_in_to_check.id
  end

  it "returns name of content" do
    parsed_check_in[:content].should == check_in_to_check.content
  end

  it "returns logo of user_id" do
    parsed_check_in[:user_id].should == check_in_to_check.user_id
  end

  it "returns status of club_id" do
    parsed_check_in[:club_id].should == check_in_to_check.club_id
  end
end