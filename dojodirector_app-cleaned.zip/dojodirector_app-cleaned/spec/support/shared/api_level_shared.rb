shared_examples_for "level in API" do
  it "returns id of club" do
    parsed_level[:id].should == level_to_check.id
  end

  it "returns name of level" do
    parsed_level[:name].should == level_to_check.name
  end

  it "returns image url" do
    parsed_level[:image_url].should == "#{request.protocol}#{request.host_with_port}#{level_to_check.image.url(:medium)}"
  end

  it "returns position of level" do
    parsed_level[:position].should == level_to_check.position
  end

  it "returns code of level" do
    parsed_level[:code].should == level_to_check.code
  end

  it "returns weeks_to_achieve of level" do
    parsed_level[:weeks_to_achieve].should == level_to_check.weeks_to_achieve
  end

  it "returns times_to_achieve of level" do
    parsed_level[:times_to_achieve].should == level_to_check.times_to_achieve
  end

  it_behaves_like "clubs type in API" do
    let(:club_type_to_check)  { level_to_check.club_type }
    let(:parsed_club_type)    { parsed_level[:club_type] }
  end
end