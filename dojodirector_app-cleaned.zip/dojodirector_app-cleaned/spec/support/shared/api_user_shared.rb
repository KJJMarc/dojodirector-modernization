shared_examples_for "users in API" do
  it "returns id of user" do
    parsed_user[:id].should == user.id
  end

  it "returns email of user" do
    parsed_user[:email].should == user.email
  end

  it "returns full_name of user" do
    parsed_user[:full_name].should == user.full_name
  end

  it "returns gender of user" do
    parsed_user[:gender].should == user.gender.to_s
  end

  it "returns phone number of user" do
    parsed_user[:phone_number].should == user.phone_number
  end

  it "returns avatar url of user" do
    parsed_user[:avatar_url].should == user.avatar.url(:medium)
  end

  it "returns statement of user" do
    parsed_user[:statement].should == user.statement
  end
end
