shared_examples_for "role in API" do
  it "returns role id" do
    parsed_role[:id].should == role_to_check.id
  end

  it "returns roles name" do
    parsed_role[:name].should == role_to_check.name
  end

  it "returns roles club" do
    parsed_role[:club_id].should == role_to_check.resource.id
  end
end