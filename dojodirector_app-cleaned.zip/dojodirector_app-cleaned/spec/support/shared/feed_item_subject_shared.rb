shared_examples_for "feed item subject" do

  it "destroys associated feed item when destroyed" do
    ActiveRecord::Observer.with_observers(:feed_observer) do
      feed_item_subject
    end
    
    FeedItem.where(:subject_type => feed_item_subject.class.name,
                   :subject_id => feed_item_subject.id).count.should == 1

    expect {
      feed_item_subject.destroy
    }.to change{ FeedItem.count}.by(-1)

    FeedItem.where(:subject_type => feed_item_subject.class.name,
                   :subject_id => feed_item_subject.id).count.should == 0

  end
end
