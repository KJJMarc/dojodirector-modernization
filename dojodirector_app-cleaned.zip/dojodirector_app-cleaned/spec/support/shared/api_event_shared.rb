shared_examples_for "event in API" do
  it "returns id of event" do
    parsed_event[:id].should == event_to_check.id
  end

  it "returns name of event" do
    parsed_event[:name].should == event_to_check.name
  end

  it "returns description of event" do
    parsed_event[:description].should == event_to_check.description
  end

  it "returns club_id of event" do
    parsed_event[:club_id].should == event_to_check.club_id
  end

  it "returns scheduled_at of event" do
    DateTime.parse(parsed_event[:scheduled_at]).should == event_to_check.scheduled_at
  end

  it "returns end_at of event" do
    DateTime.parse(parsed_event[:end_at]).should == event_to_check.end_at
  end

  it "returns status of event" do
    parsed_event[:status].should == event_to_check.status
  end
end
