def click_calendar_day(day)
  page.find("td.fc-current-month div.day-#{day}").click
end