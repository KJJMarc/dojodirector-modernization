def show_element(element)
  page.execute_script("$('#{element}').show()")
    yield if block_given?
  page.execute_script("$('#{element}').hide()")
end