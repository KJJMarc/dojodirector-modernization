module Devise
  module IntegrationTestHelpers
    include Devise::TestHelpers
    include Warden::Test::Helpers

    def as_user(user=nil, &block)
      current_user = user || Factory.create(:user)
      if request.present?
        sign_in(current_user)
      else
        login_as(current_user, :scope => :user)
      end
      block.call if block.present?
      return self
    end
  end
end
