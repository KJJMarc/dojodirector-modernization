require 'spec_helper'

describe "api subdomain constraints", :type => :routing do
  let(:url)     { "http://api.prowd.com"     }
  let(:bad_url) { "http://bad_url.prowd.com" }

  it "route to /login with proper subdomain" do
    post("#{url}/login").should route_to(
      :controller => "sessions",
      :action => "create"
    )
  end

  it "does not route to /login with incorrect subdomain" do
    post("#{bad_url}/login").should_not route_to(
      :controller => "sessions",
      :action => "create"
    )
  end
end
