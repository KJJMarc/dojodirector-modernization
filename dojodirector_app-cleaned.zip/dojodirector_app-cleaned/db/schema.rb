# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended to check this file into your version control system.

ActiveRecord::Schema.define(:version => 20180517063100) do

  create_table "addresses", :force => true do |t|
    t.text     "line_1"
    t.text     "line_2"
    t.string   "postcode"
    t.string   "city"
    t.datetime "created_at", :null => false
    t.datetime "updated_at", :null => false
    t.string   "owner_type"
    t.integer  "owner_id"
  end

  create_table "announcements", :force => true do |t|
    t.text     "body"
    t.integer  "club_id"
    t.datetime "created_at", :null => false
    t.datetime "updated_at", :null => false
    t.string   "title"
  end

  add_index "announcements", ["club_id"], :name => "index_announcements_on_club_id"

  create_table "attendances", :force => true do |t|
    t.integer  "user_id"
    t.integer  "club_id"
    t.date     "date"
    t.datetime "created_at", :null => false
    t.datetime "updated_at", :null => false
  end

  add_index "attendances", ["user_id", "club_id"], :name => "index_attendances_on_user_id_and_club_id"

  create_table "badges", :force => true do |t|
    t.string   "name"
    t.text     "description"
    t.boolean  "title_available"
    t.integer  "club_type_id"
    t.datetime "created_at",         :null => false
    t.datetime "updated_at",         :null => false
    t.string   "image_file_name"
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.datetime "image_updated_at"
    t.integer  "club_id"
  end

  create_table "check_ins", :force => true do |t|
    t.text     "content"
    t.integer  "user_id"
    t.integer  "club_id"
    t.datetime "created_at", :null => false
    t.datetime "updated_at", :null => false
  end

  create_table "club_types", :force => true do |t|
    t.string   "type_name"
    t.datetime "created_at",                                   :null => false
    t.datetime "updated_at",                                   :null => false
    t.boolean  "available",                 :default => false
    t.boolean  "token_criteria",            :default => false
    t.string   "header_image_file_name"
    t.string   "header_image_content_type"
    t.integer  "header_image_file_size"
    t.datetime "header_image_updated_at"
    t.boolean  "is_deleted",                :default => false
  end

  create_table "club_users", :force => true do |t|
    t.integer  "user_id"
    t.integer  "club_id"
    t.datetime "created_at",                        :null => false
    t.datetime "updated_at",                        :null => false
    t.boolean  "new_level_flag", :default => false
    t.boolean  "suspended",      :default => false
  end

  create_table "clubs", :force => true do |t|
    t.string   "name"
    t.integer  "club_type_id"
    t.datetime "created_at",                                            :null => false
    t.datetime "updated_at",                                            :null => false
    t.integer  "federation_id"
    t.string   "status"
    t.string   "logo_file_name"
    t.string   "logo_content_type"
    t.integer  "logo_file_size"
    t.datetime "logo_updated_at"
    t.boolean  "dismiss_missing_items_popup"
    t.string   "csv_file_name"
    t.string   "csv_content_type"
    t.integer  "csv_file_size"
    t.datetime "csv_updated_at"
    t.string   "twitter_url"
    t.string   "facebook_url"
    t.string   "website_url"
    t.string   "phone_number"
    t.string   "emergency_phone_number"
    t.integer  "created_by_id"
    t.text     "statement"
    t.datetime "completeness_reminder_dismissed_at"
    t.boolean  "is_deleted",                         :default => false
    t.string   "instagram_url"
  end

  create_table "delayed_jobs", :force => true do |t|
    t.integer  "priority",   :default => 0
    t.integer  "attempts",   :default => 0
    t.text     "handler"
    t.text     "last_error"
    t.datetime "run_at"
    t.datetime "locked_at"
    t.datetime "failed_at"
    t.string   "locked_by"
    t.string   "queue"
    t.datetime "created_at",                :null => false
    t.datetime "updated_at",                :null => false
  end

  add_index "delayed_jobs", ["priority", "run_at"], :name => "delayed_jobs_priority"

  create_table "event_attendees", :force => true do |t|
    t.integer  "event_id"
    t.integer  "user_id"
    t.datetime "created_at",                    :null => false
    t.datetime "updated_at",                    :null => false
    t.integer  "token_id"
    t.boolean  "confirmed",  :default => false
  end

  add_index "event_attendees", ["event_id"], :name => "index_event_attendees_on_event_id"
  add_index "event_attendees", ["token_id"], :name => "index_event_attendees_on_token_id"
  add_index "event_attendees", ["user_id"], :name => "index_event_attendees_on_user_id"

  create_table "event_collections", :force => true do |t|
    t.date     "start_date"
    t.date     "end_date"
    t.datetime "created_at",  :null => false
    t.datetime "updated_at",  :null => false
    t.integer  "club_id"
    t.string   "name"
    t.text     "description"
    t.string   "youtube_id"
    t.time     "start_time"
    t.text     "days"
    t.time     "end_time"
  end

  create_table "event_levels", :force => true do |t|
    t.integer  "event_id"
    t.integer  "level_id"
    t.datetime "created_at", :null => false
    t.datetime "updated_at", :null => false
  end

  add_index "event_levels", ["event_id"], :name => "index_event_levels_on_event_id"
  add_index "event_levels", ["level_id"], :name => "index_event_levels_on_level_id"

  create_table "events", :force => true do |t|
    t.string   "name"
    t.text     "description"
    t.string   "youtube_id"
    t.integer  "club_id"
    t.datetime "created_at",                                :null => false
    t.datetime "updated_at",                                :null => false
    t.datetime "scheduled_at"
    t.integer  "event_collection_id"
    t.string   "status",              :default => "active"
    t.datetime "end_at"
  end

  create_table "federations", :force => true do |t|
    t.string   "name"
    t.integer  "club_type_id"
    t.datetime "created_at",   :null => false
    t.datetime "updated_at",   :null => false
  end

  create_table "feed_items", :force => true do |t|
    t.integer  "user_id"
    t.integer  "club_id"
    t.integer  "subject_id"
    t.string   "subject_type"
    t.datetime "created_at",   :null => false
    t.datetime "updated_at",   :null => false
    t.string   "action"
  end

  create_table "group_badges", :force => true do |t|
    t.integer  "subject_id"
    t.string   "subject_type"
    t.integer  "badge_id"
    t.datetime "created_at",   :null => false
    t.datetime "updated_at",   :null => false
  end

  create_table "group_messages", :force => true do |t|
    t.string   "topic"
    t.text     "body"
    t.integer  "club_id"
    t.integer  "user_id"
    t.integer  "messages_count"
    t.datetime "created_at",     :null => false
    t.datetime "updated_at",     :null => false
  end

  create_table "level_groups", :force => true do |t|
    t.string   "name"
    t.integer  "position"
    t.integer  "club_type_id"
    t.datetime "created_at",   :null => false
    t.datetime "updated_at",   :null => false
  end

  create_table "levels", :force => true do |t|
    t.string   "name"
    t.integer  "position"
    t.integer  "club_type_id"
    t.integer  "level_group_id"
    t.datetime "created_at",                        :null => false
    t.datetime "updated_at",                        :null => false
    t.string   "image_file_name"
    t.string   "image_content_type"
    t.integer  "image_file_size"
    t.datetime "image_updated_at"
    t.string   "code"
    t.integer  "weeks_to_achieve",   :default => 1
    t.integer  "times_to_achieve",   :default => 1
  end

  create_table "messages", :force => true do |t|
    t.string   "topic"
    t.text     "body"
    t.integer  "received_messageable_id"
    t.string   "received_messageable_type"
    t.integer  "sent_messageable_id"
    t.string   "sent_messageable_type"
    t.boolean  "opened",                     :default => false
    t.boolean  "recipient_delete",           :default => false
    t.boolean  "sender_delete",              :default => false
    t.datetime "created_at",                                    :null => false
    t.datetime "updated_at",                                    :null => false
    t.string   "ancestry"
    t.boolean  "recipient_permanent_delete", :default => false
    t.boolean  "sender_permanent_delete",    :default => false
  end

  add_index "messages", ["ancestry"], :name => "index_messages_on_ancestry"
  add_index "messages", ["sent_messageable_id", "received_messageable_id"], :name => "acts_as_messageable_ids"

  create_table "roles", :force => true do |t|
    t.string   "name"
    t.integer  "resource_id"
    t.string   "resource_type"
    t.datetime "created_at",    :null => false
    t.datetime "updated_at",    :null => false
  end

  add_index "roles", ["name", "resource_type", "resource_id"], :name => "index_roles_on_name_and_resource_type_and_resource_id"
  add_index "roles", ["name"], :name => "index_roles_on_name"

  create_table "temporary_clubs", :force => true do |t|
    t.string   "name"
    t.string   "email"
    t.integer  "user_id"
    t.datetime "created_at", :null => false
    t.datetime "updated_at", :null => false
  end

  create_table "tokens", :force => true do |t|
    t.datetime "created_at",                    :null => false
    t.datetime "updated_at",                    :null => false
    t.integer  "level_id"
    t.integer  "club_id"
    t.boolean  "used",       :default => false
  end

  create_table "user_badges", :force => true do |t|
    t.integer  "badge_id"
    t.integer  "user_id"
    t.datetime "created_at",                               :null => false
    t.datetime "updated_at",                               :null => false
    t.boolean  "featured"
    t.string   "title"
    t.integer  "club_id"
    t.integer  "facebook_share_counter", :default => 0
    t.boolean  "notify",                 :default => true
  end

  create_table "user_imports", :force => true do |t|
    t.integer  "club_id"
    t.integer  "user_id"
    t.string   "state"
    t.integer  "row_count",                 :default => 0
    t.integer  "imported_count",            :default => 0
    t.integer  "failed_count",              :default => 0
    t.datetime "created_at",                               :null => false
    t.datetime "updated_at",                               :null => false
    t.string   "original_csv_file_name"
    t.string   "original_csv_content_type"
    t.integer  "original_csv_file_size"
    t.datetime "original_csv_updated_at"
    t.string   "failures_csv_file_name"
    t.string   "failures_csv_content_type"
    t.integer  "failures_csv_file_size"
    t.datetime "failures_csv_updated_at"
    t.string   "aasm_state"
    t.text     "error_message"
  end

  create_table "user_levels", :force => true do |t|
    t.integer  "club_id"
    t.integer  "user_id"
    t.integer  "level_id"
    t.datetime "created_at", :null => false
    t.datetime "updated_at", :null => false
    t.datetime "awarded_at"
  end

  create_table "users", :force => true do |t|
    t.string   "email",                                :default => "",    :null => false
    t.string   "encrypted_password",                   :default => ""
    t.string   "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",                        :default => 0
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.string   "current_sign_in_ip"
    t.string   "last_sign_in_ip"
    t.datetime "created_at",                                              :null => false
    t.datetime "updated_at",                                              :null => false
    t.string   "first_name"
    t.string   "last_name"
    t.date     "date_of_birth"
    t.integer  "gender_cd"
    t.string   "invitation_token",       :limit => 60
    t.datetime "invitation_sent_at"
    t.datetime "invitation_accepted_at"
    t.integer  "invitation_limit"
    t.integer  "invited_by_id"
    t.string   "invited_by_type"
    t.text     "extra_information"
    t.text     "notes"
    t.string   "phone_number"
    t.string   "avatar_file_name"
    t.string   "avatar_content_type"
    t.integer  "avatar_file_size"
    t.datetime "avatar_updated_at"
    t.text     "statement"
    t.string   "authentication_token"
    t.string   "facebook_uid"
    t.string   "username",                                                :null => false
    t.boolean  "is_deleted",                           :default => false
  end

  add_index "users", ["authentication_token"], :name => "index_users_on_authentication_token", :unique => true
  add_index "users", ["email"], :name => "index_users_on_email"
  add_index "users", ["facebook_uid"], :name => "index_users_on_facebook_uid", :unique => true
  add_index "users", ["invitation_token"], :name => "index_users_on_invitation_token"
  add_index "users", ["invited_by_id"], :name => "index_users_on_invited_by_id"
  add_index "users", ["reset_password_token"], :name => "index_users_on_reset_password_token", :unique => true

  create_table "users_roles", :id => false, :force => true do |t|
    t.integer "user_id"
    t.integer "role_id"
  end

  add_index "users_roles", ["user_id", "role_id"], :name => "index_users_roles_on_user_id_and_role_id"

end
