# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)



# role = Role.find_or_create_by_name('admin')
# role_super = Role.find_or_create_by_name('super_admin')
# user = role_super.users.create(email: 'zikoku07@gmail.com', password: '123456789', username: 'mahabub')
#
# p "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<,"
# p user.errors.inspect
# p "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<sddddddddddddd<<<,"
#
#  user = User.create!(email: 'joshuasadraoui@hotmail.co.uk', password: 123456789, password_confirmation: 123456789 ,first_name: "Joshua", last_name: "Joshua", date_of_birth: "1975-05-24", gender: 1, username: "JoshuaSadraoui" )
#
# User.where(email: 'joshuasadraoui@hotmail.co.uk').update_all(:id => 4829)
#
# p "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<,,"
# p User.where(email: 'joshuasadraoui@hotmail.co.uk').inspect
# p "<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<,,"


# Club.all.each do |club|
#   club.users.without_suspended.each do |member|
#    club_user = ClubUser.where(:club_id => club.id, :user_id => member.id).first
#     club_user.new_level_flag = member.new_level?(club)
#    club_user.save
#   end
# end

# club = Club.find_by_id(18)
#
# club.badges.each do |bdg|
#   bdg.club_type_id = club.club_type_id
#   bdg.save
# end


# clubs =  Club.all
# c = []
# clubs.each do|club|
#   c += club.users.pluck(:id)
# end
#
# User.where("id NOT IN (?)", c).update_all(is_deleted: true)
# User.where.not(id: c).update_all(is_deleted: true)

require 'rubygems'
require 'open-uri'
require 'paperclip'
# model.update_attribute(:photo,open(website_vehicle.image_url))
club_type =  ClubType.find_by_id(13)
destination_clubtype =  ClubType.find_by_id(41)

club_type.level_groups.each do |lg|
  lg_new = destination_clubtype.level_groups.create(name: lg.name)
  lg.levels.each do |l|
    level = lg_new.levels.new(name: l.name, position: l.position, club_type: destination_clubtype, code: l.code, weeks_to_achieve: l.weeks_to_achieve, weeks_to_achieve: l.weeks_to_achieve)
    level.image =  open(l.image.url)
    level.save
  end
end


