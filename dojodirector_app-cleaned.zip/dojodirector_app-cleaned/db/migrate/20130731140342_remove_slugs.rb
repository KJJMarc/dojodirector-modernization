class RemoveSlugs < ActiveRecord::Migration
  def up
    remove_index :users, :slug
    remove_column :users, :slug

    remove_index :clubs, :slug
    remove_column :clubs, :slug
  end

  def down
    add_column :users, :slug, :string
    add_index :users, :slug, unique: true

    add_column :clubs, :slug, :string
    add_index :clubs, :slug, unique: true
  end
end
