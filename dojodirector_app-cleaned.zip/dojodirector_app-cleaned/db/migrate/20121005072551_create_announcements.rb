class CreateAnnouncements < ActiveRecord::Migration
  def change
    create_table :announcements do |t|
      t.text :body
      t.references :club

      t.timestamps
    end
    add_index :announcements, :club_id
  end
end
