class AddDefaultsToUserImports < ActiveRecord::Migration
  def change
    change_column :user_imports, :row_count, :integer, :default => 0
    change_column :user_imports, :imported_count, :integer, :default => 0
    change_column :user_imports, :failed_count, :integer, :default => 0
  end
end
