class AddDismissMissingItemsPopupToClub < ActiveRecord::Migration
  def change
    add_column :clubs, :dismiss_missing_items_popup, :boolean
  end
end
