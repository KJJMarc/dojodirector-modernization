class CreateGroupBadges < ActiveRecord::Migration
  def change
    create_table :group_badges do |t|
      t.belongs_to :subject, :polymorphic => true
      t.belongs_to :badge

      t.timestamps
    end
  end
end
