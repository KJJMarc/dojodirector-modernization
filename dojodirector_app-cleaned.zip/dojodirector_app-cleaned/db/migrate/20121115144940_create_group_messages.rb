class CreateGroupMessages < ActiveRecord::Migration
  def change
    create_table :group_messages do |t|
      t.string :topic
      t.text :body
      t.integer :club_id
      t.integer :user_id
      t.integer :messages_count
      t.timestamps
    end
  end
end
