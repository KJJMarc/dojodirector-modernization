class AddIsDeletedFieldToClubs < ActiveRecord::Migration
  def change
    add_column :clubs, :is_deleted, :boolean, default: false
  end
end
