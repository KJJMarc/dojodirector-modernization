class CreateUserLevels < ActiveRecord::Migration
  def change
    create_table :user_levels do |t|
      t.references :club
      t.references :user
      t.references :level
      t.timestamps
    end
  end
end
