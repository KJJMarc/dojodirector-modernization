class AddExtraInformationToUsers < ActiveRecord::Migration
  def change
    add_column :users, :extra_information, :text
  end
end
