class AddActionToFeedItems < ActiveRecord::Migration
  def change
    add_column :feed_items, :action, :string
  end
end
