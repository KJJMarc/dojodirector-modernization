class CreateFeedItems < ActiveRecord::Migration
  def change
    create_table :feed_items do |t|
      t.integer :user_id
      t.integer :club_id
      t.integer :subject_id
      t.string :subject_type

      t.timestamps
    end
  end
end
