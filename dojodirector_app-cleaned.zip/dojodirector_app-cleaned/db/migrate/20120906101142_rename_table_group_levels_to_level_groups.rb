class RenameTableGroupLevelsToLevelGroups < ActiveRecord::Migration
  def up
    rename_table :group_levels, :level_groups
  end

  def down
    rename_table :level_groups, :group_levels
  end
end
