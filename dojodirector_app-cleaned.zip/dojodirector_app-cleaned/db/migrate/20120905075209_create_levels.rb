class CreateLevels < ActiveRecord::Migration
  def change
    create_table :levels do |t|
      t.string :name
      t.integer :order
      t.references :club_type
      t.references :group_level
      t.timestamps
    end
  end
end
