class AddAasmStateColumnToUserImports < ActiveRecord::Migration
  def change
    add_column :user_imports, :aasm_state, :string
  end
end
