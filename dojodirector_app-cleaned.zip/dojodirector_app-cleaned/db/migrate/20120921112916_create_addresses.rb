class CreateAddresses < ActiveRecord::Migration
  def change
    create_table :addresses do |t|
      t.string :line_1
      t.string :line_2
      t.string :postcode
      t.string :city

      t.timestamps
    end
  end
end
