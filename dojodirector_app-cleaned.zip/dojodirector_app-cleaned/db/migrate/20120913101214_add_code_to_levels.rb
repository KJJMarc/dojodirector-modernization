class AddCodeToLevels < ActiveRecord::Migration
  def change
    add_column :levels, :code, :string
  end
end
