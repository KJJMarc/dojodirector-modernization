class AddEventCollectionIdToEvents < ActiveRecord::Migration
  def change
    add_column :events, :event_collection_id, :integer
  end
end
