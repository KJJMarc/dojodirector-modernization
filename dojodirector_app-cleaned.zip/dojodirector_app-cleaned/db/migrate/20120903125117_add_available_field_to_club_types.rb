class AddAvailableFieldToClubTypes < ActiveRecord::Migration
  def change
    add_column :club_types, :available, :boolean, :default => false
  end
end
