class AddPolymorphicOwnerToAddress < ActiveRecord::Migration
  def change
    add_column :addresses, :owner_type, :string
    add_column :addresses, :owner_id, :integer
  end
end
