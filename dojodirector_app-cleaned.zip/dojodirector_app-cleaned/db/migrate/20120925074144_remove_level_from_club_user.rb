class RemoveLevelFromClubUser < ActiveRecord::Migration
  def up
    remove_column :club_users, :level_id
  end

  def down
    add_column :club_users, :level_id, :integer
  end
end
