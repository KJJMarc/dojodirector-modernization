class ReplaceEventAttendeeStateWithConfirmedFlag < ActiveRecord::Migration
  def up
    add_column :event_attendees, :confirmed, :boolean, :default => false
    EventAttendee.update_all "confirmed = true", "status IN ('confirmed')"
    remove_column :event_attendees, :status
  end

  def down
    add_column :event_attendees, :status, :string, :default => 'pending'
    EventAttendee.update_all "status = 'confirmed'", "confirmed == true"
    remove_column :event_attendees, :confirmed
  end
end
