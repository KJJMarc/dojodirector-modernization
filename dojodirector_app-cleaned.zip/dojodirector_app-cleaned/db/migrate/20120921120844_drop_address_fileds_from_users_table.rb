class DropAddressFiledsFromUsersTable < ActiveRecord::Migration
  def up
    remove_column :users, :address
    remove_column :users, :postcode
    remove_column :users, :city
  end

  def down
    add_column :users, :postcode, :string
    add_column :users, :address, :string
    add_column :users, :city, :string
  end
end
