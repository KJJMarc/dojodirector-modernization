class CreateClubUsers < ActiveRecord::Migration
  def change
    create_table :club_users do |t|
      t.references :user
      t.references :club
      t.timestamps
    end
  end
end
