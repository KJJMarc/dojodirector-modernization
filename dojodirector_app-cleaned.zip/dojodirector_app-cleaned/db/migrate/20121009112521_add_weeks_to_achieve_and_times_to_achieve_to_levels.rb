class AddWeeksToAchieveAndTimesToAchieveToLevels < ActiveRecord::Migration
  def change
    add_column :levels, :weeks_to_achieve, :integer, :default => 1
    add_column :levels, :times_to_achieve, :integer, :default => 1
  end
end
