class RemoveBadgesUsersTable < ActiveRecord::Migration
  def up
    drop_table :badges_users
  end

  def down
    create_table :badges_users, :id => false do |t|
      t.references :badge
      t.references :user
    end
  end
end
