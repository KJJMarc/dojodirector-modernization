class MakeNotesOnUserTextNotString < ActiveRecord::Migration
  def up
    change_column :users, :notes, :text
  end
end
