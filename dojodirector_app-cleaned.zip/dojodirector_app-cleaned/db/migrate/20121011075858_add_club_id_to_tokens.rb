class AddClubIdToTokens < ActiveRecord::Migration
  def change
    add_column :tokens, :club_id, :integer
  end
end
