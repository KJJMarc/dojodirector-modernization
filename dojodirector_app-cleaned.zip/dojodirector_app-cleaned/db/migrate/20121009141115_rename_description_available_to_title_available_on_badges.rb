class RenameDescriptionAvailableToTitleAvailableOnBadges < ActiveRecord::Migration
  def change
    rename_column :badges, :description_available, :title_available
  end
end
