class AddTokenIdToEventAttendees < ActiveRecord::Migration
  def change
    add_column :event_attendees, :token_id, :integer
    add_index :event_attendees, :token_id
  end
end
