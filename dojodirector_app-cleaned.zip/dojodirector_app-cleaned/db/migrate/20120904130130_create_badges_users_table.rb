class CreateBadgesUsersTable < ActiveRecord::Migration
  def change
    create_table :badges_users, :id => false do |t|
      t.references :badge
      t.references :user
    end
  end
end
