class AddIsDeletedFieldToClubTypes < ActiveRecord::Migration
  def change
    add_column :club_types, :is_deleted, :boolean, default: false
  end
end
