class AddClubIdToUserBadge < ActiveRecord::Migration
  def change
    add_column :user_badges, :club_id, :integer
  end
end
