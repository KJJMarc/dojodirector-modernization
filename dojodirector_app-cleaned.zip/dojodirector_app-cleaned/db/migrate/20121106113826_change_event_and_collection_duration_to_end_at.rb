class ChangeEventAndCollectionDurationToEndAt < ActiveRecord::Migration
  def up
    add_column :events, :end_at, :datetime
    add_column :event_collections, :end_time, :time

    Event.all.each do |e|
      if e.scheduled_at
        e.update_attribute :end_at, e.scheduled_at + e.duration.to_i
      end
    end

    EventCollection.all.each do |e|
      if e.start_at
        e.update_attribute :end_time, e.start_time + e.duration.to_i
      end
    end

    remove_column :events, :duration
    remove_column :event_collections, :duration
  end

  def down
    add_column :events, :duration, :time
    add_column :event_collections, :duration, :time

    Event.all.each do |e|
      e.update_attribute :duration, e.end_at - e.scheduled_at
    end

    EventCollection.all.each do |e|
      e.update_attribute :duration, e.end_time + e.start_time
    end

    remove_column :events, :end_at
    remove_column :event_collections, :end_time
  end
end
