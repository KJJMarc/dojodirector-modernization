class AddFederationIdToClubs < ActiveRecord::Migration
  def change
    add_column :clubs, :federation_id, :integer
  end
end
