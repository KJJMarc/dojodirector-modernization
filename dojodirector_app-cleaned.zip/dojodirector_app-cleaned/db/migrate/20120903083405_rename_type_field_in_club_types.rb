class RenameTypeFieldInClubTypes < ActiveRecord::Migration
  def up
    rename_column :club_types, :type, :type_name
  end

  def down
    rename_column :club_types, :type_name, :type
  end
end
