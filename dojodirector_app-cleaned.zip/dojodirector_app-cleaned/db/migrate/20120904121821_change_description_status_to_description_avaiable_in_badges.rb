class ChangeDescriptionStatusToDescriptionAvaiableInBadges < ActiveRecord::Migration
  def up
    rename_column :badges, :description_status, :description_available
  end

  def down
    rename_column :badges, :description_available, :description_status
  end
end
