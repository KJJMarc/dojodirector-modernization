class AddImageToLevels < ActiveRecord::Migration
  def self.up
    add_attachment :levels, :image
  end

  def self.down
    remove_attachment :levels, :image
  end
end
