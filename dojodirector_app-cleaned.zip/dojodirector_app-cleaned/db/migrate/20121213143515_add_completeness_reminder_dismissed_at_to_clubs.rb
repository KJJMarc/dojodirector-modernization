class AddCompletenessReminderDismissedAtToClubs < ActiveRecord::Migration
  def change
    add_column :clubs, :completeness_reminder_dismissed_at, :datetime
  end
end
