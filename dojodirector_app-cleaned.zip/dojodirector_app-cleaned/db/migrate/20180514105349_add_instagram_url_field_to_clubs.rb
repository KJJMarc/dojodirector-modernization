class AddInstagramUrlFieldToClubs < ActiveRecord::Migration
  def change
    add_column :clubs, :instagram_url, :string
  end
end
