class CreateGroupLevels < ActiveRecord::Migration
  def change
    create_table :group_levels do |t|
      t.string :name
      t.integer :order
      t.references :club_type

      t.timestamps
    end
  end
end
