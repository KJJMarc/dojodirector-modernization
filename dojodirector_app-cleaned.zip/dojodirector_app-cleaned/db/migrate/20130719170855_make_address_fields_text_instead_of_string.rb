class MakeAddressFieldsTextInsteadOfString < ActiveRecord::Migration
  def up
    change_column :addresses, :line_1, :text
    change_column :addresses, :line_2, :text
  end

  def down
    change_column :addresses, :line_1, :string
    change_column :addresses, :line_2, :string
  end
end
