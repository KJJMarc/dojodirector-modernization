class AddStatementToClub < ActiveRecord::Migration
  def change
    add_column :clubs, :statement, :text
  end
end
