class AddTokenCriteriaToClubTypes < ActiveRecord::Migration
  def change
    add_column :club_types, :token_criteria, :boolean, :default => false
  end
end
