class AddAwardedAtToUserLevel < ActiveRecord::Migration
  def change
    add_column :user_levels, :awarded_at, :datetime
  end
end
