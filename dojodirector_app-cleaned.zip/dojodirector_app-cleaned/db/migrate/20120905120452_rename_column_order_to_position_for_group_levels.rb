class RenameColumnOrderToPositionForGroupLevels < ActiveRecord::Migration
  def up
    rename_column :group_levels, :order, :position
  end

  def down
    rename_column :group_levels, :position, :order
  end
end
