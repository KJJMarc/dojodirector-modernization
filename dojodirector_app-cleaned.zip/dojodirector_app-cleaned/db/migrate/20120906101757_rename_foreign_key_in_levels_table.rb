class RenameForeignKeyInLevelsTable < ActiveRecord::Migration
  def up
    rename_column :levels, :group_level_id, :level_group_id
  end

  def down
    rename_column :levels, :level_group_id, :group_level_id
  end
end
