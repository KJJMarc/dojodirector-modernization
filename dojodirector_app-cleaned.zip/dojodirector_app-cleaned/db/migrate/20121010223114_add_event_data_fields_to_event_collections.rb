class AddEventDataFieldsToEventCollections < ActiveRecord::Migration
  def change
    add_column :event_collections, :name, :string
    add_column :event_collections, :description, :text
    add_column :event_collections, :youtube_id, :string
    add_column :event_collections, :start_time, :time
    add_column :event_collections, :duration, :time
    add_column :event_collections, :days, :text
  end
end
