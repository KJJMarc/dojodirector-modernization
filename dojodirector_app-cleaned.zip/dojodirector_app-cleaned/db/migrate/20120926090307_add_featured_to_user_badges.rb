class AddFeaturedToUserBadges < ActiveRecord::Migration
  def change
    add_column :user_badges, :featured, :boolean
  end
end
