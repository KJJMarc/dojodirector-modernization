class AddClubIdToEventCollections < ActiveRecord::Migration
  def change
    add_column :event_collections, :club_id, :integer
  end
end
