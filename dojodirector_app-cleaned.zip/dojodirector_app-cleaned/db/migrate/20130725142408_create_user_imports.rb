class CreateUserImports < ActiveRecord::Migration
  def change
    create_table :user_imports do |t|
      t.integer :club_id
      t.integer :user_id
      t.string :state
      t.integer :row_count
      t.integer :imported_count
      t.integer :failed_count
      t.timestamps
    end
  end
end
