class AddStatusToEventAttendees < ActiveRecord::Migration
  def change
    add_column :event_attendees, :status, :string
  end
end
