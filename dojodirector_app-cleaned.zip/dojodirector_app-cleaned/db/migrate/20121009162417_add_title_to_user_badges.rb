class AddTitleToUserBadges < ActiveRecord::Migration
  def change
    add_column :user_badges, :title, :string
  end
end
