class CreateEventLevels < ActiveRecord::Migration
  def change
    create_table :event_levels do |t|
      t.references :event
      t.references :level

      t.timestamps
    end
    add_index :event_levels, :event_id
    add_index :event_levels, :level_id
  end
end
