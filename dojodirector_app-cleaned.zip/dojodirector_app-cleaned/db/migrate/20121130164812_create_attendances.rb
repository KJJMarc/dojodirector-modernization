class CreateAttendances < ActiveRecord::Migration
  def change
    create_table :attendances do |t|
      t.references :user
      t.references :club
      t.date :date
      t.timestamps
    end
    add_index :attendances, [:user_id, :club_id]
  end
end
