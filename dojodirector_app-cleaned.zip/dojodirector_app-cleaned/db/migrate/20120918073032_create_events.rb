class CreateEvents < ActiveRecord::Migration
  def change
    create_table :events do |t|
      t.string :name
      t.text :description
      t.string :youtube_id
      t.string :event_type
      t.references :club

      t.timestamps
    end
  end
end
