class RenameColumnOrderToPositionForLevels < ActiveRecord::Migration
  def up
    rename_column :levels, :order, :position
  end

  def down
    rename_column :levels, :position, :order
  end
end
