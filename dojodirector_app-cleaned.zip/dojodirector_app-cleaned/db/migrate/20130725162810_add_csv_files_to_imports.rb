class AddCsvFilesToImports < ActiveRecord::Migration
  def change
    add_attachment :user_imports, :original_csv
    add_attachment :user_imports, :failures_csv
  end
end
