class CreateBadges < ActiveRecord::Migration
  def change
    create_table :badges do |t|
      t.string :name
      t.text :description
      t.boolean :description_status
      t.references :club_type
      t.timestamps
    end
  end
end
