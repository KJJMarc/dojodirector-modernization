class AddCsvToClubs < ActiveRecord::Migration
  def self.up
    add_attachment :clubs, :csv
  end

  def self.down
    remove_attachment :clubs, :csv
  end
end
