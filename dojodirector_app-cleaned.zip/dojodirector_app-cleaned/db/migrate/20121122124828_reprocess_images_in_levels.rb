class ReprocessImagesInLevels < ActiveRecord::Migration
  def up
    Level.scoped.each do |level|
      level.image.reprocess!
    end
  end

  def down
    raise ActiveRecord::IrreversibleMigration
  end
end
