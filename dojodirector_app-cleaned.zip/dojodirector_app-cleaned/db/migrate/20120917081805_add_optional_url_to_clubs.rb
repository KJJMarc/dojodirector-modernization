class AddOptionalUrlToClubs < ActiveRecord::Migration
  def change
    add_column :clubs, :twitter_url, :string
    add_column :clubs, :facebook_url, :string
    add_column :clubs, :website_url, :string
  end
end
