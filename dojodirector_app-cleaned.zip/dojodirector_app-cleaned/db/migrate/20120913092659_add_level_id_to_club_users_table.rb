class AddLevelIdToClubUsersTable < ActiveRecord::Migration
  def change
    add_column :club_users, :level_id, :integer
  end
end
