class AddUsernameColumnToUsers < ActiveRecord::Migration
  def up
    add_column :users, :username, :string

    execute('UPDATE users SET username = users.email')
    execute('ALTER TABLE users ALTER COLUMN username SET NOT NULL')

    add_index :users, :username, :unique => true

    remove_index :users, :email
    add_index :users, :email
  end

  def down
    remove_column :users, :username

    remove_index :users, :email
    add_index :users, :email, :unique => true
  end
end
