class CreateCheckIns < ActiveRecord::Migration
  def change
    create_table :check_ins do |t|
      t.text :content
      t.references :user
      t.references :club
      t.timestamps
    end
  end
end
