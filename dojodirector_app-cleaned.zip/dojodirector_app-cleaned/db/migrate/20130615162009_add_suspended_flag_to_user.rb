class AddSuspendedFlagToUser < ActiveRecord::Migration
  def change
    add_column :club_users, :suspended, :boolean, :default => false
  end
end
