class AddNotifyToUserBadges < ActiveRecord::Migration
  def change
    add_column :user_badges, :notify, :boolean, :default => true
  end
end
