class AddScheduledAtFieldToEvents < ActiveRecord::Migration
  def change
    add_column :events, :scheduled_at, :datetime
  end
end
