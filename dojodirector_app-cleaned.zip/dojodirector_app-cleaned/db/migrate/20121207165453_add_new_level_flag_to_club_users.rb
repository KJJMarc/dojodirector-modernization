class AddNewLevelFlagToClubUsers < ActiveRecord::Migration
  def change
    add_column :club_users, :new_level_flag, :boolean, :default => false
  end
end
