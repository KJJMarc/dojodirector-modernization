class AddStatementToUser < ActiveRecord::Migration
  def change
    add_column :users, :statement, :text
  end
end
