class RecreateSlugForUsers < ActiveRecord::Migration
  def up
    User.where(:slug => nil).map(&:save!)
  end

  def down
  end
end
