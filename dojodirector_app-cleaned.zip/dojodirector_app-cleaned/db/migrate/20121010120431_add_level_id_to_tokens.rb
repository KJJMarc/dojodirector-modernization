class AddLevelIdToTokens < ActiveRecord::Migration
  def change
    add_column :tokens, :level_id, :integer
  end
end
