class AddErrorMessageToUserImports < ActiveRecord::Migration
  def change
    add_column :user_imports, :error_message, :text
  end
end
