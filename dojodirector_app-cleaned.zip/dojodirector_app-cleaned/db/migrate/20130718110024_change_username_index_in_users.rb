class ChangeUsernameIndexInUsers < ActiveRecord::Migration
  def up
    remove_index :users, :username
    execute("CREATE UNIQUE INDEX index_users_on_lower_username ON users (LOWER(username));")
  end

  def down
    execute("DROP INDEX index_users_on_lower_username;")
    add_index :users, :username, :unique => true
  end
end
