class AddFacebookShareCounterToUserBadge < ActiveRecord::Migration
  def change
    add_column :user_badges, :facebook_share_counter, :integer, :default => 0
  end
end
