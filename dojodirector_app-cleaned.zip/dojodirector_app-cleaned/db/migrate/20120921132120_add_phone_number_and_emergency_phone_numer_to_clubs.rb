class AddPhoneNumberAndEmergencyPhoneNumerToClubs < ActiveRecord::Migration
  def change
    add_column :clubs, :phone_number, :string
    add_column :clubs, :emergency_phone_number, :string
  end
end
