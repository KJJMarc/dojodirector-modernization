class CreateEventCollections < ActiveRecord::Migration
  def change
    create_table :event_collections do |t|
      t.date :start_date
      t.date :end_date

      t.timestamps
    end
  end
end
