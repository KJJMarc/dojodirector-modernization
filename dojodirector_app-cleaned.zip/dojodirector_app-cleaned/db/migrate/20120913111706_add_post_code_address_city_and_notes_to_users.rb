class AddPostCodeAddressCityAndNotesToUsers < ActiveRecord::Migration
  def change
    add_column :users, :postcode, :string
    add_column :users, :address, :string
    add_column :users, :city, :string
    add_column :users, :notes, :string
  end
end
