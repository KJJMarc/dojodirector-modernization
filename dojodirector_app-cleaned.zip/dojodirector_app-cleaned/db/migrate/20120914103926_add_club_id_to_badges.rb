class AddClubIdToBadges < ActiveRecord::Migration
  def change
    add_column :badges, :club_id, :integer
  end
end
