class AddSomeFieldsToClubs < ActiveRecord::Migration
  def change
    add_column :clubs, :address, :string
  end
end
