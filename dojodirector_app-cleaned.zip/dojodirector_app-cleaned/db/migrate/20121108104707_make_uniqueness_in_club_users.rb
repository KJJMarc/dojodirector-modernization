class MakeUniquenessInClubUsers < ActiveRecord::Migration
  def up
    Club.scoped.each do |club|
      grouped_club_users = club.club_users.group_by do |club_user|
        [club_user.club_id, club_user.user_id]
      end

      grouped_club_users.values.each do |users|
        users[1..-1].map(&:destroy)
      end
    end
  end

  def down
  end
end
