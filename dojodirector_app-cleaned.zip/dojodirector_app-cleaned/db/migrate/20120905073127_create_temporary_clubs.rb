class CreateTemporaryClubs < ActiveRecord::Migration
  def change
    create_table :temporary_clubs do |t|
      t.string :name
      t.string :email
      t.references :user

      t.timestamps
    end
  end
end
