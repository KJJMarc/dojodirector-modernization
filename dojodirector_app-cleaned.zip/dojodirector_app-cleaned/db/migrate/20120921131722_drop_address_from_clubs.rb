class DropAddressFromClubs < ActiveRecord::Migration
  def up
    remove_column :clubs, :address
  end

  def down
    add_column :clubs, :address, :string
  end
end
