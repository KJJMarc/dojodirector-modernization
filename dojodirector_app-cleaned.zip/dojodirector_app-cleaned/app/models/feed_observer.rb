class FeedObserver < ActiveRecord::Observer
  observe :user_level, :check_in, :user_badge

  def after_create subject
    create_feed_item subject, "created"
  end
  
  private

  def create_feed_item subject, action
    item = FeedItem.new :subject => subject,
      :club => subject.club,
      :user => subject.respond_to?(:user) ? subject.user : nil,
      :action => "#{subject.class.name.underscore}_#{action}"
    item.save
  end
end
