class Level < ActiveRecord::Base
  belongs_to :club_type
  belongs_to :level_group
  has_many :user_levels, :dependent => :destroy

  has_many :clubs, :through => :user_levels
  has_many :users, :through => :user_levels

  attr_accessible :name, :position, :image, :level_group, :club_type, :code,
                  :weeks_to_achieve, :times_to_achieve

  DEFAULT_IMAGE_THUMB_URL = ActionController::Base.helpers.asset_path("logos/default_logo_thumb.png")

  has_attached_file :image, :styles => { :xlarge => "400x400#", :large => "285x285#", :medium => "154x154#",
                                         :small => "104x104#", :thumb => "74x74#"
                                       },
                                         :default_url => "logos/default_logo_:style.png"
                                    
  validates :name, :club_type, :level_group, :position, :presence => true
  validates :image, :attachment_presence => true
  validates :position, :uniqueness => { :scope => :level_group_id, :message => "should be unique per group" }
  validates :weeks_to_achieve, :times_to_achieve,
            :numericality => { :only_integer => true, :greater_than => 0 },
            :if => :has_tokens?

  before_validation :set_position

  default_scope order("levels.position ASC")
  scope :ordered, joins("INNER JOIN level_groups lg ON lg.id = levels.level_group_id").
    order("lg.position ASC, levels.position ASC")

  def as_json(options = {})
    if options[:calendar]
      if options[:with_club_names]
        user_level = user_levels.find_by_user_id(options[:user_id])
        club_name  = user_level.club.name if user_level.club.present?
        created_at = user_level.created_at
        title      = "Club: #{club_name}\n Level achieved: #{name}\n Date: #{created_at.to_s(:short)}".html_safe
      else
        "Level achieved: #{name}"
      end
      {
        :title => title,
        :start => created_at,
        :allDay => false,
        :className => "calendarLevel"
      }
    else
      super(options)
    end
  end

  def next(club)
    next_in_group || first_in_next_group(club) || nil
  end

  def next_in_group
    level_group.levels.where("position > ?", position).first if level_group.present?
  end

  def first_in_next_group(club)
    group = level_group.next(club) if level_group.present?
    group.levels.first if group
  end

  def has_tokens?
    club_type.token_criteria?
  end

  def tokens_to_achieve
    has_tokens? ? weeks_to_achieve * times_to_achieve : nil
  end

  def users_for_club(club)
    users.where("user_levels.club_id" => club)
  end

  private
  def set_position
    self.position ||= (self.level_group.levels.maximum(:position) || 0) + 1
  end
end
