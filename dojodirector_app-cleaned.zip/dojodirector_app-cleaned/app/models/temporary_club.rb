class TemporaryClub < ActiveRecord::Base
  after_create :notify_super_admins

  attr_accessible :email, :name, :user

  belongs_to :user

  validates :email, :name, :presence => true

  def notify_super_admins
    mail    = Admin::Notifier.temporary_club(self)
    options = { :body => mail.body, :subject => mail.subject }

    User.with_role(:super_admin).each do |super_admin|
      CustomMessage.new(super_admin, options).deliver
    end
  end
end
