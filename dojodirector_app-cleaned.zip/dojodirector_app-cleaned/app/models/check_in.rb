class CheckIn < ActiveRecord::Base
  self.authorizer_name = 'CheckInAuthorizer'
  attr_accessible :content, :club_id, :club, :user_id, :user

  has_one :feed_item, :as => :subject, :dependent => :destroy

  belongs_to :club
  belongs_to :user

  validates :club, :user, :content, :presence => true

  scope :latest, lambda{|limit| order("created_at DESC").limit(limit) }
  scope :recent, order("created_at DESC").limit(20)
  scope :latest_first, order("created_at DESC")
end
