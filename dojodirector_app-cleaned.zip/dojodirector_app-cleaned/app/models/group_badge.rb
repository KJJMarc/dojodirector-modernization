class GroupBadge < ActiveRecord::Base
  attr_accessible :subject, :badge

  validates :subject, :badge, :presence => true

  belongs_to :subject, :polymorphic => true
  belongs_to :badge

  has_many :feed_items, :as => :subject
end
