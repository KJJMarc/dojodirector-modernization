class Token < ActiveRecord::Base
  attr_accessible :level_id, :club_id
  has_one :event_attendee

  belongs_to :level
  belongs_to :club

  validates_uniqueness_of :level_id, :scope => :club_id

  def self.find_or_create(attributes)
    Token.where(attributes).first || Token.create(attributes)
  end
end
