class EventCollection < ActiveRecord::Base
  attr_accessible :name, :description, :youtube_id, :start_time, :end_time,
                  :end_date, :start_date, :days, :level_ids

  attr_accessor :level_ids

  belongs_to :club
  has_many :events

  with_options :on => :create do
    validates :name, :description, :club_id, :start_date, :end_date,
      :start_time, :end_time, :presence => true
    validates :youtube_id, :length => { :minimum => 11, :allow_blank => true }
    validate :at_least_one_day_selected, :if => 
    Proc.new{|c| [:days, :start_date, :end_date].all?{|att| send(att).present?} }
  end
  
  validate :days_validation

  def days_validation
    errors.add(:days, "Please check at least one checkbox.") if days.nil?
  end

  accepts_nested_attributes_for :events
  scope :not_finished, lambda {
    where("end_date > ?",Time.now)
  }
  serialize :days

  after_create :create_events
  after_validation :remove_virtual_attributes


  def cancel_and_notify(notify_attendees = false)
    events.each do |e| 
      e.cancel_and_notify notify_attendees
    end

    notify_observers :cancelled
  rescue Exception => e
    Rails.logger.error e.inspect
  end

  private

  def create_events
    event_attributes = attributes.except "id", "end_date", "created_at",
      "updated_at", "days"

    event_dates_to_create.each do |date|
      events.create event_attributes.merge :start_date => date, :level_ids => level_ids
    end
  end

  def event_dates_to_create
    start_date.upto(end_date).select{|date| days.include? date.wday.to_s }
  end

  def at_least_one_day_selected
    error_msg = " - selected range of days and dates does not include any date"
    errors.add(:days, error_msg) unless event_dates_to_create.any?
  end

  def remove_virtual_attributes
    errors.messages.delete(:scheduled_at)
    errors.messages.delete(:end_at)
  end
end
