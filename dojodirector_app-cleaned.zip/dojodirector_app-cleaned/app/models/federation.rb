class Federation < ActiveRecord::Base
  attr_accessible :club_type, :name

  belongs_to :club_type
  has_many :clubs

  validates :name, :presence => true, :uniqueness => true
  validates :club_type, :presence => true
  validates_associated :club_type
end
