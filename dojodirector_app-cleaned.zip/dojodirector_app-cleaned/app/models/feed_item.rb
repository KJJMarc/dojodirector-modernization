class FeedItem < ActiveRecord::Base
  ALLOWED_ACTIONS = %w{user_badge_created user_level_created check_in_created group_badge_created}

  attr_accessible :subject, :club, :user, :action
  belongs_to :subject, :polymorphic => true
  belongs_to :user
  belongs_to :club

  validates_presence_of :club
  validates_presence_of :subject

  validates_inclusion_of :action, :in => ALLOWED_ACTIONS, :on => :create

  scope :latest, lambda{ |limit| order("created_at DESC").limit(limit) }
end
