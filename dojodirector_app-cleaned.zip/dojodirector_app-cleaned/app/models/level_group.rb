class LevelGroup < ActiveRecord::Base
  has_many :levels
  belongs_to :club_type

  attr_accessible :name, :position

  validates :name, :club_type, :position, :presence => true
  validates :position, :uniqueness => true

  before_validation :set_position

  default_scope order("position ASC")

  def self.update_positions!(groups)
    groups.to_a.each_with_index do |id, index|
     find(id).update_attribute(:position, index + 1)
    end
  end

  def update_levels_positions!(levels)
    levels.to_a.each_with_index do |id, index|
      self.levels.find(id).update_attribute(:position, index + 1)
    end
  end

  def next(club)
    club.level_groups.where("position > ?", position).first
  end

  private
  def set_position
    self.position ||= (LevelGroup.maximum(:position) || 0) + 1
  end
end
