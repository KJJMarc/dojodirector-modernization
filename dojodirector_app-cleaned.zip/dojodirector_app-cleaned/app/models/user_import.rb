require 'csv'
require 'iconv'

class UserImport < ActiveRecord::Base
  include AASM
  belongs_to :club
  belongs_to :admin, :class_name => "User"

  attr_accessible :original_csv

  has_attached_file :original_csv,
    :path => ":rails_root/imports/:class/:attachment/:id_partition/:style/:filename",
    :storage => :filesystem

  has_attached_file :failures_csv

  validates_attachment :original_csv, :presence => true,
      :content_type => { :content_type => "text/csv" }

  aasm do
    state :uploaded, :initial => true
    state :processing
    state :failed
    state :complete

    event :process do
      transitions :from => :uploaded, :to => :processing,
        :on_transition => Proc.new {|obj| obj.delay.process_csv! }
    end

    event :fail do
      transitions :from => :processing, :to => :failed
    end

    event :finish do
      transitions :from => :processing, :to => :complete
    end
  end

  def process_csv!
    invalid_rows = []
    self.row_count = 0
    self.imported_count = 0

    contents = File.read original_csv.path
    fixed_contents = UserImport.fix_encoding(contents)

    CSV.parse(fixed_contents, :headers => true,
               :header_converters => [:downcase, :symbol]) do |row|

      self.row_count += 1
      user_attributes = prepare_attributes_from_csv_row(row)
      user = User.create_and_add_to_club user_attributes, club

      if user.new_record?
        row << user.errors.full_messages
        invalid_rows << row
      else
        self.imported_count += 1
      end
    end

    write_failures(invalid_rows)
    save && club.save && finish!
  rescue Exception => e
    self.error_message = e.message
    self.save
    fail!
  end

  private

  def write_failures invalid_rows
    failures_csv_file = Tempfile.new('csv')
    failures_csv_file.write(CSV::Table.new(invalid_rows).to_csv)
    failures_csv_file.flush

    self.failures_csv = failures_csv_file
    self.failed_count = invalid_rows.count
  end

  def prepare_attributes_from_csv_row(row)
    row = row.to_hash.with_indifferent_access

    attributes = User.attribute_names.map do |attr|
      attr == "gender_cd" ? "gender" : attr
    end

    user_attributes = row.select do |key, _|
      attributes.include?(key.to_s)
    end

    address_fields = %w{address_line_1 address_line_2 postcode city}

    unless address_fields.all?{|af| row[af].blank?}
      user_attributes[:address_attributes] = {
        :line_1 => row[:address_line_1],
        :line_2 => row[:address_line_2],
        :postcode => row[:postcode],
        :city => row[:city]
      }
    end
    user_attributes[:extra_information] = row.except *(address_fields + attributes)

    user_attributes
  end

  def self.fix_encoding contents
    # bit of a mystery, but if this is run, Ruby detects content correctly
    c = CharDet.detect(contents)
    if c.confidence > 0.6
      contents.force_encoding(c.encoding)
      contents.encode!('UTF-8', c.encoding, :invalid => :replace)
    end
    contents
  end
end
