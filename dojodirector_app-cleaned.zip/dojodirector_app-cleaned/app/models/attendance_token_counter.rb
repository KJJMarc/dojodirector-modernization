class AttendanceTokenCounter
  attr_reader :days_requirement, :weeks_requirement, :tokens, :last_graduation

  def initialize user, club
    @user = user
    @club = club
    calculate
  end

  def new_level?
    enabled? && (@tokens >= @weeks_requirement)
  end

  def enabled?
    @club.has_tokens? && @weeks_requirement && @days_requirement
  end

  private

  def calculate
    @last_graduation = @user.current_user_level_in(@club).try(:awarded_at)

    attendance_by_week = all_attendances.
      group_by{|att| Rails.logger.info(att.inspect) if att.date.nil?;"#{att.date.cweek}/#{att.date.cwyear}" }

    next_level = @user.next_level_in(@club)

    if next_level
      @days_requirement = next_level.times_to_achieve
      @weeks_requirement = next_level.weeks_to_achieve

      @tokens = attendance_by_week.reject do |_, att|
        att.count < @days_requirement
      end.keys.count
    end
  end

  def all_attendances
    (event_attendees + attendances).compact
  end

  def event_attendees
    att = @user.event_attendees.confirmed.in_club(@club)
    att = att.since(last_graduation) if last_graduation
    att
  end

  def attendances
    att = @user.attendances.at_club(@club)
    att = att.since(last_graduation) if last_graduation
    att
  end
end
