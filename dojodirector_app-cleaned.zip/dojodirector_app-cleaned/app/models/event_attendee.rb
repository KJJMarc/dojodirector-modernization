class EventAttendee < ActiveRecord::Base
  attr_accessible :user, :event

  delegate :club, :scheduled_at, :to => :event

  belongs_to :event
  belongs_to :user

  validates_uniqueness_of :user_id, :scope => :event_id, :if => :event

  scope :pending,           where(:confirmed => false)
  scope :confirmed,         where(:confirmed => true)

  scope :in_club, lambda { |club|
    joins(:event).
    where(:events => {:club_id => club})
  }

  scope :since, lambda{|datetime|
    joins(:event).
    where(["events.scheduled_at > ?", datetime])
  }

  def date
    scheduled_at.to_date
  end

  def week
    scheduled_at.strftime('%W')
  end

  def confirm
    update_attribute :confirmed, true
    notify_observers(:confirmed)
  end
end
