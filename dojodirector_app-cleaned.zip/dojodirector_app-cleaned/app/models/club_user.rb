class ClubUser < ActiveRecord::Base
  attr_accessible :user, :club

  validates :user, :club, :presence => true
  validates :user_id, :uniqueness => { :scope => :club_id }

  belongs_to :user
  belongs_to :club

  def update_new_level_flag
    self.update_attribute :new_level_flag, attendance_token_counter.new_level?
  end

  def suspend!
    self.update_attribute :suspended, true
  end

  def unsuspend!
    self.update_attribute :suspended, false
  end

  def active?
    !suspended?
  end

  def status
    if user.has_role?(:admin, club)
      'Admin'
    elsif suspended?
      'Suspended member'
    else
      'Member'
    end
  end

  def attendance_token_counter
    @token_counter ||= AttendanceTokenCounter.new(user, club)
  end
end
