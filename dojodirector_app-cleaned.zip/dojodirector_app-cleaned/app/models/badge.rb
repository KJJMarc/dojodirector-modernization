class Badge < ActiveRecord::Base
  self.authorizer_name = "BadgeAuthorizer"

  belongs_to :club_type
  belongs_to :club
  has_many :user_badges, :dependent => :destroy
  has_many :users, :through => :user_badges

  attr_accessible :description, :title_available, :name, :image

  has_attached_file :image, :styles => { :xlarge => "400x400#", :large => "285x285#", :medium => "154x154#", :small => "104x104#", :thumb => "74x74#" }
  validates :name, :presence => true
  validates :image, :attachment_presence => true
  validate :check_club_or_club_type

  def custom?
    club_id.present?
  end

  private

  def check_club_or_club_type
    errors.add(:base, "Please provide club or club type") if club.nil? && club_type.nil?
  end
end
