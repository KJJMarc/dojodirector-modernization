class MemberSearch
  attr_reader :basic_filter, :level_filter, :sort, :direction, :query, :members

  LIST_FILTERS = [
    ["All members",:all],
    ["Active",:member],
    ["Suspended",:suspended_member],
    ["New level",:new_level]
  ]

  def initialize club, params
    @club = club
    @basic_filter = params['filter']
    @level_filter = params['level_filter'] || "All levels"
    @query = params['query']

    @sort = params[:sort]
    @direction = %w[asc desc].include?(params[:direction]) ? params[:direction] : "desc"
    @page = params[:page]

    prepare_members
  end

  def basic_filters
    LIST_FILTERS
  end

  def current_filter
    basic_filters.select{|n,v| v.to_s == @basic_filter}.
      first.try(:first) || "Active"
  end

  def member_count
    @member_count ||= @members.count
  end
 
  def sort_column
    sortable_column? || sort_by_column? ? @sort : "created_at"
  end

  private
  def prepare_members
    @members = @club.users.search(@query)


    set_filter_for_members
    set_level_filter_for_members
    member_count #setting member count before pagination or sorting

    if sort_by_column?
      scope_name = :"sorted_by_#{@sort}"
      if User.respond_to?(scope_name)
        @members = @members.send(scope_name, @club, @direction)
      else
        if @members.first.method(@sort).arity > 0
          @members = @members.sort_by { |member| member.send(@sort, @club) }
        else
          @members = @members.sort_by { |member| member.send(@sort) }
        end
        @members = @members.reverse if sort_by_direction.desc?
        @members = Kaminari.paginate_array(@members)
      end
    else
      @members = @members.order(sort_column + " " + sort_by_direction) if sortable_column?
    end

    @members = @members.page(@page)
  end

  def sortable_column?
    User.column_names.include?(@sort)
  end

  def sort_by_column?
    User::SORT_METHODS.include?(@sort)
  end

  def sort_by_direction
    ActiveSupport::StringInquirer.new(@direction)
  end
 
  def set_filter_for_members
    if ["member","suspended_member", "new_level"].include?(@basic_filter)
      @filter_by = @basic_filter 
    end

    if @filter_by == "new_level"
      @members = @members.where(:"club_users.new_level_flag" => true)
    elsif @filter_by == "member"
      @members = @members.without_suspended
    elsif @filter_by == "suspended_member"
      @members = @members.only_suspended
    elsif @basic_filter.blank?
      @members = @members
    end
  end
 
  def set_level_filter_for_members
    if level = @club.levels.find_by_name(@level_filter)
      @members = @members.with_level_at(level, @club)
    end
  end
end
