class BadgeAward
  include Authority::Abilities
  self.authorizer_name = 'BadgeAwardAuthorizer'

  TYPES = %w{all_from_group all_from_event all_members}

  attr_accessor :params, :club, :badge, :group_badge

  def initialize(club, badge, params)
    @badge  = badge
    @club   = club
    @params = params
  end

  def award!
    if supported_type? params[:for]
      ActiveRecord::Base.transaction do
        create_badge_for_users
        group_badge.save!
        create_feed_item!
      end
    end
  end

  def award
    award!
  rescue ActiveRecord::RecordInvalid, ActiveRecord::RecordNotFound
    false
  end

  private

  def all_from_group
    level = club.levels.find(params[:level])
    @group_badge = GroupBadge.new(:subject => level, :badge => badge)

    build_badge_for_users(User.with_level_at level, club)
  end

  def all_from_event
    event = club.events.find(params[:event])
    @group_badge = GroupBadge.new(:subject => event, :badge => badge)
    build_badge_for_users(event.attendees)
  end

  def all_members
    @group_badge = GroupBadge.new(:subject => club, :badge => badge)
    build_badge_for_users(club.users)
  end

  def build_badge_for_users(users)
    users.map do |user|
      user.user_badges.build(:club => club, :badge => badge, :title => title, :notify => notify)
    end
  end

  def create_badge_for_users
    send(params[:for]).map do |user_badge|
      UserBadge.observers.disable(FeedObserver) { user_badge.save! }
    end
  end

  def create_feed_item!
    FeedItem.create!(:subject => group_badge, :club => club, :action => "group_badge_created")
  end

  def supported_type?(type)
    TYPES.include? type
  end

  def title
    params[:message]
  end

  def notify
    !!params[:notify]
  end

end
