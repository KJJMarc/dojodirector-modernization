class Announcement < ActiveRecord::Base
  belongs_to :club
  attr_accessible :body, :title

  validates :title, :body, :presence => true

  scope :latest_first, order("updated_at DESC")
  scope :latest, lambda { |n| limit(n).order("updated_at DESC") }
end
