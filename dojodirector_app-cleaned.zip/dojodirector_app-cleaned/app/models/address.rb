class Address < ActiveRecord::Base
  attr_accessible :city, :line_1, :line_2, :postcode
  validates_presence_of :line_1

  belongs_to :owner, :polymorphic => true

  def as_array
    [line_1, line_2, city, postcode].reject(&:blank?)
  end

  def to_s
    as_array.join(", ")
  end
end
