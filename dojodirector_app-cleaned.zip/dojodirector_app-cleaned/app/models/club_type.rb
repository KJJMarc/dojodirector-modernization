class ClubType < ActiveRecord::Base
  has_many :badges

  attr_accessible :type_name, :available, :token_criteria, :header_image

  has_many :federations
  has_many :clubs
  has_many :levels
  has_many :level_groups

  has_attached_file :header_image, :styles => { :full => "1500>x500>", :preview => "300x64#" }

  validates :type_name, :presence => true
  default_scope { where(is_deleted: false) }
end
