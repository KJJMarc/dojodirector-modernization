class Message < ActsAsMessageable::Message
  validate :send_message_to_yourself

  def send_message_to_yourself
    errors.add(:base, "You cannot send message to yourself") if to == from
  end
end
