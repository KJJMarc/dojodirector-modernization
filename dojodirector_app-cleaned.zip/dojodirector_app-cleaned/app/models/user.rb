class User < ActiveRecord::Base
  include Authority::UserAbilities
  include Authority::Abilities

  SORT_METHODS = %w{full_name level_in attendances_in badges_in check_ins_in last_name_first_name}

  self.authorizer_name = 'UserAuthorizer'

  has_attached_file :avatar, :styles => { :medium => "154x154#", :small => "104x104#", :thumb => "74x74#" },
    :default_url => "logos/default_user_:style.png"

  before_save :ensure_authentication_token
  before_validation :generate_username_if_blank, :on => :create

  rolify
  # Include default devise modules. Others available are:
  # :token_authenticatable, :encryptable, :confirmable, :lockable, :timeoutable and :omniauthable
  devise :username_authenticatable, :invitable, :database_authenticatable, :registerable, :recoverable, :rememberable, :trackable, :token_authenticatable

  acts_as_messageable :class_name => "Message"

  # Setup accessible (or protected) attributes for your model
  attr_accessible :username, :email, :password, :password_confirmation, :remember_me,
                  :first_name, :last_name, :clubs_attributes,
                  :temporary_clubs_attributes, :club, :date_of_birth,
                  :gender, :invitation_message, :address_attributes, :extra_information,
                  :city, :notes, :address, :phone_number, :avatar, :statement

  attr_accessor :club, :fields_with_validation, :invitation_message

  as_enum :gender, [:female, :male], :whiny => false

  serialize :extra_information

  validates :facebook_uid, :length => {:in => 0..255}, :uniqueness => true, :allow_blank => true

  has_many :check_ins
  has_many :club_users
  has_many :user_levels
  has_many :clubs, :through => :club_users do
    def active
      where(:club_users => {:suspended => false})
    end
  end

  has_many :levels, :through => :user_levels
  has_many :temporary_clubs
  has_many :user_badges
  has_many :badges, :through => :user_badges
  has_many :event_attendees
  has_many :events, :through => :event_attendees
  has_one :address, :as => :owner, :dependent => :destroy
  has_many :feed_items
  has_many :attendances

  accepts_nested_attributes_for :clubs
  accepts_nested_attributes_for :club_users
  accepts_nested_attributes_for :temporary_clubs
  accepts_nested_attributes_for :address

  scope :recent,           limit(5).order("id DESC")
  scope :active,           where("last_sign_in_at IS NOT NULL")
  scope :active_last_week, where("last_sign_in_at > ?", Date.today - 1.week)

  scope :with_level_at, lambda{ |level, club|
    joins(:user_levels).
      where(:"user_levels.level_id" => level.id.to_s).
      where(:"user_levels.club_id" => club.id).
      joins("LEFT JOIN user_levels ul2 ON user_levels.club_id = ul2.club_id
           AND user_levels.user_id = ul2.user_id
           AND ul2.awarded_at > user_levels.awarded_at").
           where("ul2.id IS NULL")
  }

  scope :with_levels_at, lambda{|level_ids, club|
    joins(:user_levels).
      where(:"user_levels.level_id" => level_ids).
      where(:"user_levels.club_id" => club.id).
      joins("LEFT JOIN user_levels ul2 ON user_levels.club_id = ul2.club_id
           AND user_levels.user_id = ul2.user_id
           AND ul2.awarded_at > user_levels.awarded_at").
           where("ul2.id IS NULL")
  }

  scope :sorted_by_attendances_in, lambda{|club, direction|
    joins("LEFT JOIN attendances a ON a.user_id = users.id and a.club_id = #{club.id}").
    joins("LEFT JOIN event_attendees ea ON ea.user_id = users.id
           LEFT JOIN events e ON e.id = ea.event_id AND e.club_id = #{club.id}").
           group("users.id, club_users.id").
           order("COUNT(a.id) + COUNT(ea.id) #{direction}")
  }

  scope :sorted_by_check_ins_in, lambda{|club, direction|
    joins("LEFT JOIN check_ins c ON c.user_id = users.id and c.club_id = #{club.id}").
    group("users.id, club_users.id").
    order("COUNT(c.id) #{direction}")
  }

  scope :sorted_by_badges_in, lambda{|club, direction|
    joins("LEFT JOIN user_badges b ON b.user_id = users.id and b.club_id = #{club.id}").
    group("users.id, club_users.id").
    order("COUNT(b.id) #{direction}")
  }

  scope :sorted_by_level_in, lambda{|club, direction|
    joins("LEFT JOIN user_levels ul ON ul.user_id = users.id and ul.club_id = #{club.id}").
    joins("LEFT JOIN levels l ON l.id = ul.level_id
           LEFT JOIN level_groups lg ON lg.id = l.level_group_id").
           joins("LEFT JOIN user_levels ul2 ON ul.club_id = ul2.club_id
           AND ul.user_id = ul2.user_id
           AND ul2.awarded_at > ul.awarded_at").
           where("ul2.id IS NULL").
           order("lg.position #{direction}, l.position #{direction}")
  }

  scope :sorted_by_last_name_first_name, lambda{|_, direction|
    order("LOWER(last_name), lower(first_name) #{direction}")
  }

  default_scope { where(is_deleted: false) }

  def to_param
    "#{id}-#{"#{first_name}#{last_name}".downcase.gsub(/[^0-9a-z]/i, '')}"
  end

  def roles_for(resource)
    roles.where(
      :resource_type => resource.class,
      :resource_id => resource.id
    )
  end

  def active_clubs
    clubs.active
  end

  def events_in_active_clubs
    clubs_events = []
    active_clubs.each do |club|
      club.events.each do |event|
        clubs_events << event
      end
    end
    return clubs_events
  end

  def levels_in_active_clubs
    user_levels.where(:club_id => active_clubs).map(&:level)
  end

  def levels_in_club(club)
    user_levels.where(:club_id => club).map(&:level)
  end

  def full_name
    [first_name, last_name].any?(&:blank?) ? self.username : "#{first_name} #{last_name}"
  end

  def suspend(club)
    if has_role?(:admin, club)
      errors.add(:base, "You can not suspend admin of club")
    else
      membership_at(club).suspend!
    end
  end

  def unsuspend(club)
    membership_at(club).unsuspend!
  end

  def suspended?(club)
    membership_at(club).suspended?
  end

  def my_clubs
    Club.with_role(:admin, self).select("clubs.*")
  end

  def my_club_ids
    my_clubs.map(&:id)
  end

  def is_admin_of_approved_club?
    my_clubs.where(:status => "approved").any?
  end

  def self.search(query)
    results = scoped
    if query
      results = results.where("CONCAT(first_name,' ',last_name) ILIKE :query OR
                            CONCAT(last_name,' ',first_name) ILIKE :query OR
                            first_name ILIKE :query OR last_name ILIKE :query OR
                            email ILIKE :query", :query => "%#{query}%")
    end
    results
  end

  def badges_grouped_by(field)
    badges.group_by(&field).each_with_object({}) do |(key, value), h|
      h[key] = value.sort_by(&:updated_at).reverse
    end
  end

  def events_in_last_month
    events.confirmed.monthly_events(Date.today.months_ago(1))
  end

  def role
    all_roles = roles_name
    %w{super_admin admin}.detect do |role|
      all_roles.include?(role)
    end.try(:humanize) || "None"
  end

  def set_level_in_club(level, club, awarded_at = nil)
    user_levels.create(:club => club, :level => level, :awarded_at => awarded_at)
  end

  def remove_level_in_club(level, club)
    user_levels.where(:club_id => club.id, :level_id => level.id).first.destroy
  end

  def current_user_level_in(club)
    user_levels.where(:club_id => club).order("awarded_at DESC").first
  end

  def current_level_in(club)
    @current_levels ||= {}
    @current_levels[club.id] ||= current_user_level_in(club).try(:level)
  end

  def next_level_in(club)
    club.next_level(current_level_in(club))
  end

  def super_admin_or_admin?
    has_role?(:super_admin) || my_clubs.present?
  end

  def as_json(options)
    { :email => email, :authentication_token => authentication_token }
  end

  def has_unread_messages?
    true || messages.unreaded.any?
  end

  def unread_messages_count
    received_messages.unreaded.count
  end

  def attendances_in(club)
    events.confirmed.where(:club_id => club).count +
      attendances.where(:club_id => club).count
  end

  def badges_in(club)
    user_badges.where(:club_id => club).count
  end

  def check_ins_in(club)
    check_ins.where(:club_id => club).count
  end

  def latest_badge
    user_badges.latest(1).first
  end

  def latest_badge_in(club)
    user_badges.at_club(club).latest(1).first
  end

  def total_attendance
    events.confirmed.count + attendances.count
  end

  def total_attendance_at club
    events.where(:club_id => club.id).confirmed.count + attendances.where(:club_id => club.id).count
  end

  def last_attendance_at club
    last_event_date = events.where(:club_id => club.id).confirmed.
      order("scheduled_at DESC").first.try(:scheduled_at).try(:to_date)
    last_attendance_date = attendances.where(:club_id => club.id).
      order("date DESC").first.try(:date)
    [last_event_date, last_attendance_date].compact.min
  end

  def new_level?(club)
    attendance_token_counter(club).new_level?
  end

  def attendance_token_counter club
    membership_at(club).attendance_token_counter
  end

  def membership_at club
    club_users.where(:club_id => club.try(:id)).first
  end

  def status_at club
    membership_at(club).try(:status)
  end

  def active_at? club
    membership_at(club).try(:active?)
  end

  def self.find_by_email_and_name email, first_name, last_name
    User.where(:email => email,
               :first_name => first_name,
               :last_name => last_name).first
  end

  def generate_username_if_blank
    return unless username.blank?
    proposed = base = "#{first_name} #{last_name}".gsub(/\s/,'')
    i = 0
    while User.find_by_username(proposed)
      proposed = "#{base}#{i}"
      i += 1
    end
    self.username = proposed
  end

  def self.create_and_add_to_club attributes, club

    attributes = attributes.with_indifferent_access
    user = User.find_by_email_and_name(attributes[:email],
                                attributes[:first_name],
                                attributes[:last_name])

    if user && user.clubs.include?(club)
      user = User.new(attributes)
      user.errors.add(:base, "This user is already a member of this club")
    else
      if user
        user.club = club
        user.deliver_another_invitation
      else
        user = User.invite!(attributes, nil) do |u|
          u.club = club
        end
      end

      club.users << user if user.valid?
    end
    user
  end
end
