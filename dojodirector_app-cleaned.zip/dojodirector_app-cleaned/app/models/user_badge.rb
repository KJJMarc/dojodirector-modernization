class UserBadge < ActiveRecord::Base
  attr_accessible :badge_id, :title, :badge, :club, :user, :subject, :notify
  delegate :name, :image, :description, :title_available, :to => :badge

  after_create :send_notification, :if => :notify?

  validates :user, :badge, :club, :presence => true

  has_one :feed_item, :as => :subject, :dependent => :destroy

  belongs_to :user
  belongs_to :badge
  belongs_to :club
  belongs_to :subject, :polymorphic => true

  scope :with_badge, includes(:badge)
  scope :for_badge, lambda {|badge| where(:badge_id => badge.id) }
  scope :latest, lambda{|no| limit(no).order("created_at DESC") }
  scope :latest_first, order("created_at DESC")
  scope :with_user, includes(:user)
  scope :at_club, lambda {|club| where(:club_id => club.id)}

  private

  def send_notification
    User::Notifier.new_badge(self).deliver
  end
end
