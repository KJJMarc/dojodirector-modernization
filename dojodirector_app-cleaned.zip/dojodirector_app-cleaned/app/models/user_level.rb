class UserLevel < ActiveRecord::Base
  attr_accessible :user, :club, :level, :awarded_at

  delegate :level_group, :image, :name, :title, :to => :level

  validates :user, :club, :level, :presence => true

  before_create :set_awarded_at

  after_create :remove_later_levels, :send_notification

  has_one :feed_item, :as => :subject, :dependent => :destroy

  belongs_to :user
  belongs_to :club
  belongs_to :level
  default_scope order("awarded_at DESC")

  private

  def remove_later_levels
    user.user_levels.where(:club_id => club.id).
      where(["awarded_at >= ?",awarded_at]).
      where(["id <> ?",id]).destroy_all
  end

  def send_notification
    User::Notifier.new_level(self).deliver
  end

  def set_awarded_at
    self.awarded_at = Time.now unless self.awarded_at
  end
end
