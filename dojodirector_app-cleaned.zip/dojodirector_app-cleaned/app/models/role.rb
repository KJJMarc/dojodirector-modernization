class Role < ActiveRecord::Base
  ADMIN_ROLES     = [:admin, :super_admin]

  self.authorizer_name = 'RoleAuthorizer'

  attr_accessible :name
  attr_accessor :user

  has_and_belongs_to_many :users, :join_table => :users_roles
  belongs_to :resource, :polymorphic => true
  
  scopify

  def admin?
    ADMIN_ROLES.include? name.to_sym
  end
end
