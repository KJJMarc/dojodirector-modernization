class Event < ActiveRecord::Base
  self.authorizer_name = "EventAuthorizer"

  attr_accessor :level_ids

  attr_accessible :description, :name, :youtube_id, :club_id, :start_date, 
    :end_time, :start_time, :scheduled_at, :end_at, :status, :level_ids

  belongs_to :club
  belongs_to :event_collection

  has_many :event_attendees
  has_many :attendees, :through => :event_attendees, :source => :user
  has_many :event_levels
  has_many :levels, :through => :event_levels

  before_validation :set_scheduled_at_and_end_at
  after_validation :remove_virtual_attributes

  validates :name, :club_id, :presence => true
  validates :start_date, :start_time, :presence => true, :if => "scheduled_at.nil?"
  validates :end_time, :presence => true, :if => "end_at.nil?"

  validates :youtube_id, :length => { :minimum => 11, :allow_blank => true }
  validates_date :scheduled_at
  validates_date :end_at

  after_update :notify_rescheduled_if_changed
  after_create :add_levels
  after_update :add_levels

  attr_writer :start_date, :start_time, :end_time

  state_machine :status, :initial => :active do
    event :activate do
      transition all => :active
    end
    event :cancel do
      transition all => :canceled
    end
  end

  scope :latest_first, order("scheduled_at ASC")
  scope :upcoming, lambda { |n=3| where("scheduled_at >= ?", Time.now).limit(n).order("scheduled_at ASC") }
  scope :past, lambda { where("scheduled_at < ?", Time.now).order("scheduled_at ASC") }
  scope :period_events, lambda { |date_from, date_until|
    where("scheduled_at >= ? and scheduled_at <= ?", date_from, date_until)
  }

  scope :pending,   EventAttendee.pending
  scope :confirmed, EventAttendee.confirmed
  scope :active,   where(:status => "active")
  scope :canceled, where(:status => "canceled")
  scope :at_club, lambda{|club| where(:club_id => club.id) }
  scope :for_year, lambda {|year| where("scheduled_at >= ? and scheduled_at <= ?", "#{year}0101", "#{year}1231")}

  def cancel_and_notify(notify = false)
    cancel
    send_cancel_notification if notify
    notify_observers :cancelled
  end

  def start_date
    @start_date = scheduled_at.try(:to_date)
  end

  def start_time
    scheduled_at.try(:strftime, "%H:%M") || @start_time
  end

  def end_time
    end_at.try(:strftime, "%H:%M") || @end_time
  end

  def self.monthly_events(date)
    self.period_events(date.beginning_of_month, date.to_time.end_of_month)
  end

  def self.daily_events(date)
    self.period_events(date.beginning_of_day, date.to_time.end_of_day)
  end

  def attend(user)
    self.event_attendees.create!(:user => user)
  rescue ActiveRecord::RecordInvalid
    nil
  end

  def unattend(user)
    self.event_attendees.find_by_user_id(user).try(:destroy)
  end
  
  def confirm(user)
    self.event_attendees.find_by_user_id(user).try(:confirm)
  end
  
  def deny(user)
    self.event_attendees.find_by_user_id(user.id).try(:destroy)
  end

  def toggle_attendance(user, attended)
    if attended
      attend(user) unless attending?(user)
      confirm(user)
    else
      deny(user) if attending?(user)
    end
  end

  def attending?(user)
    self.attendee_ids.include?(user[:id])
  end

  def send_cancel_notification
    mail    = User::Notifier.canceled_event(self)
    options = { :body => mail.body, :subject => mail.subject }
    attendees.each do |member|
      CustomMessage.new(member, options).deliver
    end
  end

  def as_json(options = {})
    if options[:calendar]
      path = options[:admin] ? :admin_venue_event_path : :club_event_path

      title = options[:with_club_names] ? "Club: #{club.name}, #{name}" : name
      {
        :title => title,
        :start => scheduled_at,
        :end => end_at,
        :description => description.truncate(90),
        :video => youtube_id,
        :allDay => false,
        :url => Rails.application.routes.url_helpers.send(path, club, self),
        :className => "calendarEvent"
      }
    else
      super(options)
    end
  end

  def notify_rescheduled_if_changed
    notify_observers(:rescheduled) if scheduled_at_changed?
  end

  private

  def set_scheduled_at_and_end_at
    if @start_date.present? && @start_time.present?
      d = @start_date.is_a?(Date) ? @start_date : Date.parse(@start_date)
      t = @start_time.is_a?(Time) ? @start_time : Time.parse(@start_time)
      self.scheduled_at = DateTime.new(d.year, d.month, d.day, t.hour, t.min, t.sec)
    end

    if @start_date.present? && @end_time.present?
      d = @start_date.is_a?(Date) ? @start_date : Date.parse(@start_date)
      t = @end_time.is_a?(Time) ? @end_time : Time.parse(@end_time)
      self.end_at = DateTime.new(d.year, d.month, d.day, t.hour, t.min, t.sec)
    end
  end

  def add_levels
    if level_ids
      level_attributes = level_ids.map { |level_id| { :level_id => level_id } }
      event_levels.destroy_all
      event_levels.create(level_attributes)
    end
  end

  def remove_virtual_attributes
    errors.messages.delete(:scheduled_at)
    errors.messages.delete(:end_at)
  end
end
