class Club < ActiveRecord::Base
  include Authority::Abilities

  self.authorizer_name = 'ClubAuthorizer'
  delegate :url_helpers, to: 'Rails.application.routes'

  attr_accessible :name, :club_type, :club_type_id, :address_attributes, :logo,
                  :users_attributes, :twitter_url, :facebook_url, :website_url,
                  :federation_id, :phone_number, :emergency_phone_number,
                  :statement, :instagram_url

  has_attached_file :logo, :styles => { :medium => "154x154#" },
    :default_url => "logos/default_logo_:style.png"
  has_attached_file :csv

  validates :name, :presence => true, :uniqueness => true
  validates :club_type, :presence => true
  validates_associated :club_type, :address
  validates :twitter_url, :facebook_url, :website_url, :url => { :allow_blank => true }
  validates :statement, :length => { :maximum => 100 }

  has_many :check_ins
  has_many :events
  has_many :event_collections
  has_many :club_users
  has_many :user_imports

  has_many :users, :through => :club_users do
    def only_suspended
      where(:club_users => {:suspended => true})
    end

    def without_suspended
      where(:club_users => {:suspended => false})
    end
  end

  default_scope { where(is_deleted: false) }
  # scope :active,           where(is_deleted: false)

  has_many :levels, :through => :club_type
  has_many :level_groups, :through => :club_type
  has_many :user_badges
  has_many :custom_badges, :conditions => { :club_type_id => nil }, :class_name => Badge
  has_one :address, :as => :owner
  has_many :announcements
  has_many :event_attendees, :through => :events
  has_many :attendances

  has_many :admins, :through => :roles, :source => :users, :conditions => {:"roles.name" => 'admin'}
  has_many :feed_items
  has_many :group_messages

  belongs_to :club_type
  belongs_to :federation
  belongs_to :created_by, :class_name => "User"

  before_validation :set_already_existed_user, :on => :create

  resourcify

  accepts_nested_attributes_for :club_type, :users, :club_users, :address

  state_machine :status, :initial => :pending do
    event :approve do
      transition all => :approved
    end
    event :reject do
      transition all => :rejected
    end

    after_transition :on => :approve, :do => :send_approve_notification
    after_transition :on => :reject,  :do => :send_reject_notification
  end

  scope :approved, where(:status => "approved")
  scope :pending,  where(:status => "pending")
  scope :rejected, where(:status => "rejected")
  scope :recent,   limit(5).order("id DESC")

  def to_param
    "#{id}-#{super}"
  end

  def self.create_with_user club_data, creator
    username = club_data[:users_attributes]["0"][:username] rescue nil
    email = club_data[:users_attributes]["0"][:email] rescue nil

    if username && email && existing_user = User.find_by_username_and_email(username, email)
      club_data.delete(:users_attributes)
    end

    club = Club.new(club_data)

    if !creator.has_role? :super_admin
      club.users << creator
    elsif existing_user
      club.users << existing_user
    else
      club.users.first.skip_password = true
    end

    club.created_by = creator


    if club.save
      user = club.users.first
      user.add_role :admin, club
      if creator.has_role? :super_admin
        user.club = club
        user.invite!
        club.approve
      end
    end

    club
  end

  def badges
    Badge.where("badges.club_id = ? OR badges.club_type_id = ?", id, club_type.id)
  end

  def most_popular_badges(limit = 6)
    badges.select("badges.*, count(user_badges.id) as award_count").
      joins("left join user_badges ON user_badges.badge_id =
                            badges.id AND user_badges.club_id = #{id}").
      group("badges.id").
      order("award_count DESC").limit(limit)
  end

  def send_approve_notification
    mail    = User::Notifier.approved_club(self)
    options = { :body => mail.body, :subject => mail.subject }
    admins.each { |admin| CustomMessage.new(admin, options).deliver }
  end

  def send_reject_notification
    mail    = User::Notifier.rejected_club(self)
    options = { :body => mail.body, :subject => mail.subject }
    admins.each { |admin| CustomMessage.new(admin, options).deliver }
  end

  def missing_steps
    missing_steps = []
    missing_steps.push({ :label => "Enter club address",
                          :url => url_helpers.edit_admin_venue_path(self)}) if address.blank?
    missing_steps.push({ :label => "Upload a logo",
                          :url => url_helpers.admin_venue_path(self)}) if logo_file_name.blank?
    missing_steps.push({ :label => "Add members",
                          :url => url_helpers.admin_venue_path(self)}) if users.blank?
    missing_steps.push({ :label => "Add phone number",
                         :url => url_helpers.edit_admin_venue_path(self)}) if phone_number.blank?
    return missing_steps
  end

  def add_admin(user)
    user.add_role :member, self
    user.add_role :admin, self
  end

  def next_level(level = nil)
    return unless has_tokens?
    if level.nil?
      level_groups.first.try(:levels).try(:first)
    else
      level.try(:next, self)
    end
  end

  def set_already_existed_user
    admin = users.first
    user = User.find_by_username_and_email(admin.username, admin.email) if admin

    self.users = [user] if user
  end

  def number_of_members(filter = nil)
    filter = nil unless ["member", "suspended_member", "new_level"].include?(filter)

    if filter == "new_level"
      users.where(:"club_users.new_level_flag" => true).count
    elsif filter == "member"
      users.without_suspended.count
    elsif filter == "suspended_member"
      users.only_suspended.count
    else
      users.count
    end
  end

  def truncated_name
    name.truncate(38)
  end

  def total_attendance
    event_attendees.confirmed.count + attendances.count
  end

  def profile
    @club_profile ||= ClubProfile.new(self)
  end

  def has_tokens?
    club_type.token_criteria
  end

  def to_param
    "#{id}-#{name.downcase.gsub(/[^0-9a-z]/i, '')}"
  end
end
