class ClubProfile
  REQUIRED_FIELDS = {
    "Address" => Proc.new{|club| club.address.nil? },
    "Telephone" => Proc.new{|club| club.phone_number.blank? },
    "Twitter" => Proc.new{|club| club.twitter_url.blank? },
    "Facebook"=> Proc.new{|club| club.facebook_url.blank? }
  }
  REMINDER_DISMISS_COOLDOWN = 1.hour

  def initialize club
    @club = club
  end

  def complete?
    ! missing_fields.any?
  end

  def incomplete?
    ! complete?
  end
  
  def completeness_degree
    "#{100-(100/REQUIRED_FIELDS.length*missing_fields.length)}"
  end

  def show_reminder?
    !reminder_dismissed_recently? && incomplete?
  end

  def missing_fields
    REQUIRED_FIELDS.map do |name, check|
      check.call(@club) ? name : nil
    end.compact
  end

  private

  def reminder_dismissed_recently?
    @club.completeness_reminder_dismissed_at.try(:>, REMINDER_DISMISS_COOLDOWN.ago)
  end
end
