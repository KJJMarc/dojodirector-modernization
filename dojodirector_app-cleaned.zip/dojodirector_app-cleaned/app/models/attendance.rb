class Attendance < ActiveRecord::Base
  attr_accessible :club, :user, :date

  belongs_to :user
  belongs_to :club

  scope :at_club, lambda{|club| where(:club_id => club.id) }
  scope :on_date, lambda{|date| where(:date => date) }
  scope :since, lambda{|datetime|
    where(["attendances.date > ?", datetime])
  }
  scope :for_year, lambda {|year| where("date >= ? and date <= ?", "#{year}0101", "#{year}1231")}

  validates_presence_of :user, :club, :date
  validates_uniqueness_of :date, :scope => [:user_id, :club_id]

  def self.toggle date, attended
    attendance = self.on_date(date).first

    if attendance && !attended
      attendance.destroy
    elsif !attendance && attended
      attendance = create!(:date => date)
    end
    attendance
  end
end
