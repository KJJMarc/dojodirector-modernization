class EventLevel < ActiveRecord::Base
  attr_accessible :level_id

  belongs_to :event
  belongs_to :level

  validates :level_id, :uniqueness => { :scope => :event_id }
end
