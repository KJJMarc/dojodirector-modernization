class GroupMessage < ActiveRecord::Base
  attr_accessor :members
  attr_accessible :topic, :body

  validates :topic, :body, :presence => true
  validate :at_least_one_member 

  after_validation :send_individual_messages, :on => :create

  scope :latest_first, order("created_at DESC")
  belongs_to :club
  belongs_to :user

  private

  def send_individual_messages
    self.messages_count = members.size

    members.each do |member|
      user.send_message(member, topic, body)
    end
  end

  def at_least_one_member
    errors.add(:base, "must be sent to at least one member, but no members were selected") if members.size < 1
  end
end
