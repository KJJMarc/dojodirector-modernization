module Admin::ClubsHelper
  def federation_link(club)
    if club.federation
      link_to club.federation.name, admin_club_type_federation_path(club.club_type, club.federation)
    else
      t(:no_federation)
    end
  end

  def federations_for_club(club)
    options_from_collection_for_select(club.club_type.federations, 'id', 'name' , club.federation_id)
  end

  def members_count(club)
    club.users.count
  end

  def events_count(club)
    club.events.count
  end

  def admins_of(club)
    if club.admins.any?
      club.admins.map(&:email).join(", ")
    else
      "No admins"
    end
  end

  def website_url(club, type)
    url = club.send("#{type}_url")
    if type == :twitter
      unless url[/\Ahttp:\/\//] || url[/\Ahttps:\/\//]
        url = "https://twitter.com/#{url}"
      end
      content_tag(:p, :class => type) do
        "#{link_to(h(url), h(url), style: 'word-wrap: break-word;', target: '_blank')}".html_safe
      end
    else
      unless (club.send("#{type}_url")).blank?
        unless url[/\Ahttp:\/\//] || url[/\Ahttps:\/\//]
          url = "http://#{url}"
        end
        content_tag(:p, :class => type) do
          "#{link_to(h(url), h(url), style: 'word-wrap: break-word;', target: '_blank')}".html_safe
        end
      end
    end
  end

  def get_all_badges_count(club_type)
    count =  club_type.badges.count
    # count = 0
    club_type.clubs.each do |club|
      count += club.custom_badges.count
    end
    count
  end

  def get_all_badges(club)
    badges = club.club_type.badges
    club.club_type.clubs.each do |clb|
      badges +=  clb.custom_badges
    end
    badges
  end

  def phone_numbers(club)
    unless club.phone_number.blank?
      "<b>Tel</b> #{h club.phone_number}".html_safe
    end
  end
end
