module Admin::Venues::MembersHelper
  def member_level_name(member, club)
    level = member.current_level_in(club)
    level ? level.name : t(:no_level)
  end

  def member_level_thumb_image(member, club)
    level = member.current_level_in(club)
    path = level ? level.image.url(:thumb) : Level::DEFAULT_IMAGE_THUMB_URL
    image_tag(path)
  end

  def member_field(member, field)
    attribute = member.send(field)
    attribute ? attribute : t("unknown")
  end

  def last_attendance(member, club)
    member.last_attendance_at(club) || t("no_attendance")
  end

  def current_level?(member, level, club)
    member.current_level_in(club) == level
  end

  def checked_level_class(member, level, club)
    "checked" if current_level?(member, level, club)
  end
end
