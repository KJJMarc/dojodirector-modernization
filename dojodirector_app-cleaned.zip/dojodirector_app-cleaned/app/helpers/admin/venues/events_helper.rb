module Admin::Venues::EventsHelper

  def youtube_video(video_id)
    if video_id.present?
      "<iframe width='560' height='315' src='http://www.youtube.com/embed/#{video_id}' frameborder='0' allowfullscreen></iframe>".html_safe
    else
      t(:no_video)
    end
  end

  def hours_for_select
    hours = []
    (7..24).each do |h|
      hour = (h < 10 ? "0#{h}" : h)

      hours << "#{hour}:00"
      if hour.to_i < 24 
        [15, 30, 45].each do |min|
          hours << "#{hour}:#{min}"
        end
      end
    end
    hours
  end
  
  def events_collection_days
    [[1, "Monday"], [2, "Tuesday"], [3, "Wednesday"], [4, "Thursday"], [5, "Friday"], [6, "Saturday"], [7, "Sunday"]]    
  end
end
