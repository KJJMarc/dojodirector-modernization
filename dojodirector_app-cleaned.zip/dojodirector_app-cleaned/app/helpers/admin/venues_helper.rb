module Admin::VenuesHelper
  def federation_name(club)
    federation = club.federation
    federation ? federation.name : t(:no_federation)
  end
end