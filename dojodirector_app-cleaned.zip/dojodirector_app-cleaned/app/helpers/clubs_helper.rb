module ClubsHelper
  def club_federation(club)
    club.federation ? club.federation.name : t(:no_federation)
  end

  def club_phone_number(club)
    club.phone_number ? club.phone_number : t(:no_phone)
  end

  def club_emergency_phone_number(club)
    club.emergency_phone_number ? club.emergency_phone_number : t(:no_phone)
  end
end
