module Users::LevelsHelper
  def facebook_level_url(user, level)
    "https://www.facebook.com/dialog/feed?" + facebook_level_query(user, level).to_query
  end

  def twitter_level_url(user, level)
    "http://twitter.com/share?" + twitter_level_query(user, level).to_query
  end

  def linked_in_level_url(user, level)
    "http://www.linkedin.com/shareArticle?" + linked_in_level_query(user, level).to_query
  end

  def level_show_link(user, level)
    member = user == current_user ? "your" : user.full_name
    link_to "See how they will see #{member} level", user_level_path(user, level)
  end

  private

  def level_owner(user)
    user == current_user ? "I" : user.full_name
  end

  def facebook_level_query(user, level)
    facebook_query.merge(
        {
            :link         => url_for_level(user, level),
            :picture      => level.image.url(:thumb),
            :name         => level.name,
            :redirect_uri => user_level_url(user, level)
        }
    )
  end

  def twitter_level_query(user, level)
    twitter_query.merge(
        {
            :text => "#{level_owner(user)} just received a level: #{level.name}",
            :url  => url_for_level(user, level)
        }
    )
  end

  def url_for_level user, level
    user_profile_url(user, :level_id => level.id, :club_id => level.club_id)
  end

  def linked_in_level_query(user, level)
    summary = "New level was awarded to #{user.first_name} on Prowd"
    linked_in_query.merge(
        {
            :url      => user_level_url(user, level),
            :source   => user_level_url(user, level),
            :title    => "#{level_owner(user)} just received a level: #{level.name} #{user_level_url(user, level)}",
            :mini => true,
            :title => level.name,
            :summary => summary
        }
    )
  end
end
