module Users::MessagesHelper
  def message_tr_class(message)
    "info" unless message.open?
  end

  def sender_roles(message)
    user_roles = message.from.roles
    roles = user_roles.where(:resource_id => nil).map(&:name)
    user_roles.map(&:resource).compact.each do |res|
      roles << message.from.roles_for(res).map(&:name)
    end

    "(#{roles.uniq.join(", ")})" if roles.count > 0
  end

  def sender_description(message)
    [
      link_to(message.from.full_name, user_profile_path(message.from)),
      sender_roles(message)
    ].compact.join(" ").html_safe
  end
end
