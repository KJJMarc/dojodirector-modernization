module Users::BadgesHelper
  def facebook_badge_url(user, badge)
    "https://www.facebook.com/dialog/feed?" + facebook_badge_query(user, badge).to_query
  end

  def twitter_badge_url(user, badge)
    "http://twitter.com/share?" + twitter_badge_query(user, badge).to_query
  end

  def linked_in_badge_url(user, badge)
    "http://www.linkedin.com/shareArticle?" + linked_in_badge_query(user, badge).to_query
  end

  def badge_show_link(user, badge)
    member = user == current_user ? "your" : user.full_name
    link_to "See how they will see #{member} badge", user_badge_path(user, badge)
  end

  private

  def badge_owner(user)
    user == current_user ? "I" : user.full_name
  end

  def facebook_badge_query(user, badge)
    facebook_query.merge(
      {
          :link         => url_for_badge(user, badge),
          :picture      => badge.image.url(:thumb),
          :name         => badge.name,
          :description  => badge.description || "",
          :redirect_uri => user_badge_url(user, badge, :fb_share => "true")
      }
    )
  end

  def twitter_badge_query(user, badge)
    twitter_query.merge(
      {
        :text => "#{badge_owner(user)} just received a badge: #{badge.name}",
        :url  => url_for_badge(user, badge)
      }
    )
  end

  def url_for_badge user, badge
    user_profile_url(user, :badge_id => badge.id, :club_id => badge.club_id)
  end

  def linked_in_badge_query(user, badge)
    summary = "New badge was awarded to #{user.first_name} on Prowd"
    summary += (badge.title == "") ? "." : ": #{badge.title}"
    
    linked_in_query.merge(
      {
        :url => show_badge_user_profile_url(user, :badge_id => badge.id, :club_id => badge.club_id, :_tag => "a3r1de"),
        :source => show_badge_user_profile_url(user, :badge_id => badge.id, :club_id => badge.club_id),
        :mini => true,
        :title => badge.name,
        :summary => summary,
      }
    )
  end
end
