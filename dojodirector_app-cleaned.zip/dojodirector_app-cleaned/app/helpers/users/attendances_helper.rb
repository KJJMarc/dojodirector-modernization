module Users::AttendancesHelper
  def current_month_class(year, number_of_month)
    if year == Date.today.year
      Date.today.month == number_of_month ? "current_month" : "month"
    else
      "month"
    end
  end
  
  def can_change_attendance
    current_user.has_role?(:super_admin) || current_user.has_role?(:admin, @club)
  end
end