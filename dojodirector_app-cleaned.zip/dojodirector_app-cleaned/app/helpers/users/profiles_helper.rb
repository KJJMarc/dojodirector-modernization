module Users::ProfilesHelper
  def club_description(user)
    user.clubs.empty? ? t(:without_club) : t(:with_club)
  end

  def own_profile?
    @user == current_user
  end

  def days_head
    html = ""
    1.upto(31).each { |day| html << content_tag(:th) { day.to_s } }
    html.html_safe
  end

  def attendance_image(user_events, attendances, date)
    user_attendance = attendances.detect{ |attendance| attendance.date == date }
    user_event = user_events.detect { |event| event.scheduled_at.to_date == date }

    if user_event || user_attendance
      image_tag("attendance/mark.png").html_safe
    end
  end
  
  def attendance_day_class(club_events, date, can_change = false)
    day_events = club_events.detect { |event| event.scheduled_at.to_date == date }

    result = []
    result << "attendance_day" if can_change and day_events
    result << "today" if date == Date.today
      
    return result.join(" ")
  end
  
  def attendance_day_mark(user_events, attendances, awarded_levels, date)
    user_attendance = attendances.detect{ |attendance| attendance.date == date }
    user_event = user_events.detect { |event| event.scheduled_at.to_date == date }
        
    if awarded_levels
      result = "<span class='g-mark'>G</span>"
    elsif (user_event || user_attendance)
      result = "<span class='x-mark'>X</span>"
    end
    
    return result.html_safe if result
  end
  
  def day_events(events, date)
    events.detect { |event| event.scheduled_at.to_date == date }
  end
end
