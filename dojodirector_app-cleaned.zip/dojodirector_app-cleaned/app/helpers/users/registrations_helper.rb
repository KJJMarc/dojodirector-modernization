require 'ostruct'

module Users::RegistrationsHelper
  def club_types_for_select(selected = nil)
    options_from_collection_for_select(ClubType.all, 'id', 'type_name', selected)
  end

  def clubs_for_select(select = nil)
    clubs = Club.approved
    clubs << OpenStruct.new(:id => 0, :name => "Other")
    options_from_collection_for_select(clubs, 'id', 'name', select)
  end
end
