module Users::AuthenticationsHelper

  def facebook_button(options = {})
    path = "/auth/facebook"
    path += "?#{options.to_query}" if options.present?

    text = options[:text] || t('facebook_login_label')
    link_to path, :class => 'facebook-button' do
      content_tag(:i, nil, :class => 'icon') + text
    end
  end
end
