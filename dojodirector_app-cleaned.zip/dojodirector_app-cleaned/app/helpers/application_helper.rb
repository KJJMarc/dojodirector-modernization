module ApplicationHelper
  include Users::BadgesHelper

  def current_user
    super || User.new
  end

  def sortable(column, title = nil)
    title ||= column.titleize
    css_class = column == sort_column ? "current #{sort_direction}" : nil
    direction = sort_direction == "asc" ? "desc" : "asc"
    link_to title,
            params.merge({:sort => column, :direction => direction}),
            {:class => css_class}
  end

  def role_change(user, club, role_name=:admin)
    return if me?(user) && role_name.to_s == "admin"
    data_params = {
      :'data-user-id'   => user.id,
      :'data-club-id'   => club.id,
      :'data-role-name' => role_name,
      :class => 'btn-small make-role'
    }

    if user.has_role?(role_name, club)
      role = user.roles_for(club).find_by_name(role_name) || Role.find_by_name(role_name)
      link_to "Remove #{role_name}",
              admin_role_path(role, :user_id => user.id, :club_id => club.id),
              :confirm => 'Are you sure?',
              :method => :delete, :class => "btn-small"
    else
      link_to "Make #{role_name}", "#", data_params
    end
  end

  def admin_dashboard_page
    current_user.has_role?(:super_admin) ? admin_home_path :
      admin_venue_path(current_user.my_clubs.first)
  end

  def admin_clubs_page
    current_user.has_role?(:super_admin) ? admin_clubs_path : admin_venues_path
  end

  def nav_item title, path, active_if = nil
    active_if ||= /^#{path}/
    content_tag 'li', :class => (request.fullpath =~ active_if ? 'active' : '') do
      link_to title, path, :"data-target" => '#'
    end
  end

  def user_profile(user)
    user_profile = ""
    user_profile += user.full_name unless user.email == user.full_name
    user_profile += " <a href='mailto:#{user.email}'>#{user.email}</a> "
    user_profile += link_to '(public profile)', user_profile_path(user)
    user_profile.html_safe
   end

  def me?(user = @user)
    current_user == user
  end

  def badge_description(badge)
    "#{badge.name},#{badge.title.blank? ? '' : " #{badge.title},"} #{time_ago_in_words badge.created_at} ago"
  end

  def facebook_query
    {
        :app_id   => 1550475868413199,
        :display  => :popup
    }
  end

  def twitter_query
    { :via => "Prowdcom" }
  end

  def linked_in_query
    {
        :mini     => true,
        :source   => root_url
    }
  end

  def get_attendance_value(member, club, date)
    Attendance.where(user_id: member.id, club_id: club.id, date: date).present?
  end
end
