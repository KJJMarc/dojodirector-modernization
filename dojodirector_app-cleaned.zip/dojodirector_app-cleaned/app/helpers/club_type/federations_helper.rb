module ClubType::FederationsHelper
end
