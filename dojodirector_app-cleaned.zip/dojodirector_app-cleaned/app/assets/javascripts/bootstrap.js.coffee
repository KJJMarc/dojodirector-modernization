jQuery ->
  $("a[rel=popover]").popover()
  $(".tooltip").tooltip()
  $("a[rel=tooltip]").tooltip()

  
  selectTab = ->
    if location.hash.indexOf("=") == -1
      activeTab = $('[href=' + location.hash + ']')
      activeTab && activeTab.tab('show')

  setTimeout selectTab, 1000 # ugly but works
