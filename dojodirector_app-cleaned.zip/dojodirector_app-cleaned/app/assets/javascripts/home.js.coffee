$ ->
  $('.carousel').carousel(
    interval: 5000
  )

  $(".register-inline").click ->
    $('.carousel').carousel('pause')

  $(".datepicker_with_year").datepicker
    changeMonth: true,
    changeYear: true,
    dateFormat: "yy-mm-dd",
    yearRange: "1900:c"

#$(window).scroll ->
#  elem = $("div#how_does_prowd_work .slide")
#  if elem.length != 0
#    if $(".flash").length > 0
#      flash_height = $(".flash").height()
#    else
#      flash_height = 0
#
#    if $("#content").length != 0
#      content_margin = parseInt($("#content").css("margin-top"))
#    else
#      content_margin = 0
#
#    original_position = 0
#    original_position += (content_margin + $(".navbar").outerHeight() + $(elem).outerHeight())
#
#    if elem.parents().find("#homepage").length > 0
#      original_position += $("#homepage-carousel-height").outerHeight()
#    else if elem.parents().find("#registration").length > 0
#      original_position += $("#registration").outerHeight()
#
#    scroll = $(window).scrollTop() + window.innerHeight - flash_height
#
#    if scroll < original_position
#      elem.addClass "active_before"
#      elem.removeClass "active_after"
#    else
#      elem.removeClass "active_before"
#
#    if scroll > original_position + window.innerHeight - $(elem).outerHeight()
#      elem.addClass "active_after"
#      elem.removeClass "active_before"
#      $("#about-target").css("margin-top", $(elem).outerHeight())
#    else
#      elem.removeClass "active_after"
#      $("#about-target").css("margin-top", "0")
      