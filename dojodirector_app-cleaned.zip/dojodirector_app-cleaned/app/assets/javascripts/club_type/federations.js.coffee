class window.FederationLoader
  load_federations: (select, after_callback) ->
    club_type_id  = select.attr('value')
    select_id     = 'user_clubs_attributes_0_federation_id'
    select_name   = 'user[clubs_attributes][0][federation_id]'
    label         = $('<label>').attr('for', select_id).addClass("federation").append('Federation')
    box           = $('<div>').addClass("select")
    select        = $('<select>').attr('id', select_id).attr('name', select_name)
    select_box    = box.append(select)
    federation    = $('<div>').attr('id', 'federation_select_box').addClass("fields bottom_space")

    $.getJSON "/club_types/#{club_type_id}/federations.json", (data) ->
      if data.length > 0
        select_template = federation.append(label).append(select_box)
        $.each data, ->
          id    = $(this).attr('id')
          name  = $(this).attr('name')

          $('<option>').
          attr('value', id).append(name).
          appendTo($(select_template).find("select"))
        
        $(select_template).find("select").width('340').selectbox()
        $("#federation_radio_buttons").after(select_template)
        $("#federation_radio_buttons").show()
        select_template.hide()
        after_callback.call()
      else
        $("#federation_radio_buttons").hide()
