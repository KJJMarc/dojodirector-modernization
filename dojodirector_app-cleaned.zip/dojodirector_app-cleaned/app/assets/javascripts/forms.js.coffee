$(document).ready ->
	$('select').selectbox();