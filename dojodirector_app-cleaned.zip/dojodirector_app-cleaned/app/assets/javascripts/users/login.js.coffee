$(document).ready ->
  $(".login-inline").click ->
    $("#login_modal").modal 'show'
    return false
