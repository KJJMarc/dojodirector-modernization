$ ->
  $(".send-message-button").click (event) ->
    modal = $(this).parents(".new-message-modal")
    form = modal.find("form")
    url  = "#{form.attr('action')}.json"
    $.ajax(
      type: "POST"
      url: url
      data: form.serialize()
      dataType: 'json'

      success: (data) ->
        flash = $("<div>").attr('class', 'flash success').append('Message was sent')
        result = $("<div>").attr('class', 'sent-message').append(
          $("<div>").attr('class', 'sent-message-title').append(
            "topic:" + data["topic"]
          )
        ).after(
          $("<div>").attr('class', 'sent-message-body').append(
            "body:" + data["body"]
          )
        )        
        close_button = $("<button>").attr({'class' : 'btn btn-primary', 'data-dismiss' : 'modal', 'aria-hidden' : 'true'}).append("Close")
        modal.find(".modal-footer").html(close_button)
        modal.find('.modal-body').fadeOut ->
          $(this).html(flash)
          $(this).append(result).fadeIn()
      error: (data) =>
        $(this).unbind('click').click()
    )
    false
    