$(document).ready ->
  load_federations = (club_type) ->
    $('#federation_select_box').remove()
    club_type_select = $(club_type)
    if club_type_select.find(":selected").val() != ""
      federation_loader = new FederationLoader
      federation_loader.load_federations(club_type_select, ->
        if $("#federation_yes").is(':checked')
          $('#federation_select_box').show()
      )
    else
      $('#federation_radio_buttons').hide()

  club_type_select = $("#club_club_type_id")
  load_federations(club_type_select)

  club_type_select.change ->
    load_federations(this)

  $("#federation_yes").change ->
     $('#federation_select_box').show()

  $("#federation_no").change ->
     $('#federation_select_box').hide()
