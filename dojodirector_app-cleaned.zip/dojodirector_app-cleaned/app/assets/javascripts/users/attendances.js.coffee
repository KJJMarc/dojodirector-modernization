$ ->
  $("table.attendance tr td").click ->
    data = $(this).attr("id")
    $("#attendance_#{data}_modal").modal 'show'
