$ ->
  $("#show_check_in_form").click ->
    $("#checkin_modal").modal 'show'
