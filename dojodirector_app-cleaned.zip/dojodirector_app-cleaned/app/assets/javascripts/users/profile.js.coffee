$ ->
  init_file_upload = ->
    $('#user_avatar').fileupload
      forceIframeTransport: true,
      dataType: 'json',
      type: 'post',
      url: $(this).attr('action'),
      add: (e, data) ->
        $("#logo img").hide()
        $("#logo #message").show()
        data.submit()
      done: (e, data) ->
        $("#logo img").attr("src", data.result).show()
        $("#logo #message").hide()
      fail: (ev, data) ->
        alert("Sorry, something went wrong!")

  $(document).on "click", "button.enable-webcam", ->
    $('div[data-webcam]').toggleClass('webcam')
    $("#take_photo_modal").modal 'show'

    loadComplete = (msg) ->
      # fetch the CSRF meta tag data
      csrf_param = $('meta[name=csrf-param]').attr('content')
      csrf_token = $('meta[name=csrf-token]').attr('content')
      # reset the api URL appending the auth token parameter

      url = $('div[data-webcam]').data('upload-url')
      if $('div[data-webcam]').data('upload-url').search("\\?") > 0
        url += '&' + csrf_param + "=" + encodeURIComponent(csrf_token)
      else
        url += '?' + csrf_param + "=" + encodeURIComponent(csrf_token)
      webcam.set_api_url(url)

    uploadComplete = (html) ->
      if html
        $("#take_photo_modal").modal 'hide'
        $('#avatar_upload_wrapper').replaceWith(html)
      else
        alert('An error occured')
        webcam.reset()
      init_file_upload()

    webcam.set_hook('onLoad', loadComplete)
    webcam.set_hook('onComplete', uploadComplete)
    webcam.set_swf_url('/webcam.swf')
    webcam.set_quality(90)
    webcam.set_shutter_sound(false)
    $('div[data-webcam]').html(webcam.get_html(340, 255))

  $(document).on "click", "button.take-snapshot", ->
    webcam.snap()

  init_file_upload()
  
  is_old_ie = ->
    $.browser.msie and (parseInt($.browser.version) < 9)

  $(".qrCode").each ->
    size = $(this).attr('data-size') or 112
    render = 'canvas'
    if is_old_ie() == true
      render = 'table'
    $(this).qrcode({render:render, width:size, height:size, text:$(this).attr('rel')})

  if $(".nav-tabs a[data-active=true]").length > 0
    $(".nav-tabs a[data-active=true]").tab("show")
  else
    $(".nav-tabs a:first").tab("show")

  $("#print_attendance_sheet").click ->
    $(".qrCode-printed .qrCode").show()
    window.print()
    $(".qrCode-printed .qrCode").hide()
    false

  $("#view-more-announcements").click ->
    $.ajax(
      url: $(this).attr('href')
      data:
        page: $(this).attr('data-page')
      success: (data) =>
        $(this).hide() if !!data
        $("ol.feed").append(data)
    )
    $(this).attr('data-page', parseInt($(this).attr('data-page')) + 1)
    false
    
  if $("#fb_badge_modal").length != 0
    $("#fb_badge_modal").modal("show")

  if $("#fb_level_modal").length != 0
    $("#fb_level_modal").modal("show")
