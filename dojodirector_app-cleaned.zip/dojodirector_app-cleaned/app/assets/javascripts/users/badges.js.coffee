$ ->
  $(".badge-image").click ->
    badge_id = $(this).find('img').data('badge-id')
    $("#badge_#{badge_id}_modal").modal 'show'

  $(".award-badge-button").click ->
    form = $(this).parents("form")
    url  = form.attr('action')

    $.ajax(
      type: "POST",
      url: url,
      data: form.serialize(),
      dataType: 'json'
      success: (data) ->
        flash = $("<div>").attr('class', 'flash success').append('Badge was successfully awarded')
        result = $("<div>").attr('class', 'awarded-badge').append(
          $("<div>").attr('class', 'awarded-badge-name').append(
            data["name"]
          ).after(
            $("<div>").attr('class', 'awarded-badge-image').append(
              $("<img>").attr('src', data['image_url'])
            ).after(
              $("<div>").attr('class', 'awarded-badge-description').append(
                data["description"]
              )
            )
          )
        )

        form.find('.modal-body').fadeOut ->
          $(this).html(flash)
          $(this).append(result).fadeIn()
          setTimeout (-> window.location.reload()), 1000
          
        form.find('.modal-footer').fadeOut()
    )
    false

  $(".share-icon").click ->
    object  = $(this).parents('a')
    width   = object.data('width')
    height  = object.data('height')
    href    = object.attr('href')
    window.open(href, '_blank', "width=#{width},height=#{height}")
    false

  $(".remove-badge").click ->
    $.ajax(
      url: $(this).attr('href'),
      type: "DELETE",
      dataType: 'json',
      success: (data) =>
        $(this).parents(".modal").modal('hide')
    )
    false