$ ->
  $('#club_logo').fileupload
    dataType: 'json',
    add: (e, data) ->
      $("#logo img").hide()
      $("#logo #message").show()
      data.submit()
    done: (e, data) ->
      $("#logo img").attr("src", data.result).show()
      $("#logo #message").hide()
    fail: (ev, data) ->
      alert("Sorry, something went wrong!")
