$ ->
  hash = window.location.hash || "#details"
  $('.nav-tabs a[href="'+hash+'"]').tab('show')
