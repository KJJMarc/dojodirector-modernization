$ ->
  show_event_fields = ->
    $("#new_event_collection #event_fields").show()
    $("#new_event_collection #event_collection_fields").hide()

  show_event_collection_fields = ->
    $("#new_event_collection #event_fields").hide()
    $("#new_event_collection #event_collection_fields").show()

  getParameterByName = (name) ->
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]")
    regexS = "[\\?&]" + name + "=([^&#]*)"
    regex = new RegExp(regexS)
    results = regex.exec(window.location.search)
    unless results?
      ""
    else
      decodeURIComponent results[1].replace(/\+/g, " ")

  $("#new_event_collection #event_type input[type=radio]").change ->
    if $(this).val() == "single"
      show_event_fields()
    else
      show_event_collection_fields()

  if $("#event_collection_event_type_single").is(":checked")
    show_event_fields()
  else if $("#event_collection_event_type_collection").is(":checked")
    show_event_collection_fields()


  $("input.datepicker").datepicker({ dateFormat: "yy-mm-dd" })
  $("input.datepicker").datepicker('option', 'firstDay', 1);

  event_start_date = $("#event_collection_events_attributes_0_start_date")
  event_start_date.datepicker("option", "minDate", new Date())

  event_collection_start_date = $("#event_collection_start_date")
  event_collection_end_date = $("#event_collection_end_date")
  event_collection_start_date.datepicker("option", "minDate", new Date())
  event_collection_end_date.datepicker("option", "minDate", event_collection_start_date.val())
  event_collection_start_date.change =>
    event_collection_end_date.datepicker("option", "minDate", event_collection_start_date.val())

  eventElems = []

  fields = $("#new_event_collection .fields.checkboxes .list .field_with_errors")
  fields.hide()
  fields.first().show()

  $('#calendar').fullCalendar
    loading: (check) ->
      if check
        eventElems = []
        $('.fc-day-number').each ->
          elem = $(this)[0]
          $(elem).removeClass('event-day')

        $('.fc-day-number').each ->
          content = $(this).text()
          $(this).addClass("day-#{content}")
          if !$(this).parents('td').hasClass("fc-state-highlight")
            $(this).html("<div class='inner-border'>" + content + "</div><div class='inner-image'></div>")

        $('.fc-header-left .fc-button-content').html(".");
        $('.fc-header-right .fc-button-content').html(".");

      else
        for elem in eventElems
          $(elem).addClass('event-day')


    eventRender: (event, element) ->
      thisDay = $('#calendar').fullCalendar('getDate')
      thisMonth = thisDay.getMonth()
      thisYear = thisDay.getFullYear()

      if (event.start.getFullYear() == thisYear)
        $('.fc-day-number').each ->
          eventDay = parseInt($(this).text());
          if (eventDay == event.start.getDate())
            elem = $(this)[0]
            if (!$(elem).parents("td").hasClass("fc-other-month") && event.start.getMonth() == thisMonth) ||
               ($(elem).parents("td").hasClass("fc-other-month") && event.start.getMonth() != thisMonth)
              eventElems.push(elem)
      $('.fc-widget-content').each ->
        if !$(this).hasClass("fc-other-month")
          $(this).addClass("fc-current-month")
        

      
      element.attr('title', event.title)

    weekends: true
    titleFormat: 'MMMM'
    header:
      left: 'prev'
      center: 'title'
      right: 'next'
    firstDay: 1
    events:
      url: window.location.pathname + '.json?club_id=' + getParameterByName("club_id")
      cache: false
    dayClick: (date, allDay, jsEvent, view) ->
      if $('#day_calendar').length > 0
        $('#day_calendar').fullCalendar('gotoDate', date)
      else
        true

      $(".fc-widget-content .fc-day-number").removeClass("active")
      $(this).find(".fc-day-number").addClass("active")

    eventClick: ( event, jsEvent, view ) ->
      if $('#day_calendar').length > 0
        $('#day_calendar').fullCalendar('gotoDate', event.start)
        false
      else
        true

  eventsPresence = false

  $('#day_calendar').fullCalendar
    loading: (check) ->
      if (check)
        eventsPresence = false
        if $('#day_calendar .fc-content span.none').length == 0
          $('#day_calendar .fc-content').prepend("<span class='none'>There are no events</span>")
      else
        none_message = $('#day_calendar .fc-content span.none')
        if eventsPresence
          none_message.hide()
        else
          none_message.show()

    eventRender: (event, element) ->
      # if there is even one event eventsPresence is true
      eventsPresence = Boolean(event)

    eventAfterRender: (event, element) ->
      if typeof event.description != "undefined"
        element.find(".fc-event-inner").append("<span class='fc-event-description'>" + event.description + "</span>")
      has_video = Boolean(event.video)
      element.find(".fc-event-inner").prepend("<span class='fc-event-video " + has_video + "'></span>")

    defaultView: 'basicDay'
    titleFormat: "dddd dS MMMM"
    height: 500
    weekends: true
    header:
      left: false
      center: 'title'
      right: false
    firstDay: 1
    events:
      url: window.location.pathname + '.json?club_id=' + getParameterByName("club_id")
      cache: true
    timeFormat: 'hh:mmtt { - hh:mmtt}'

  $('#eventsTabs a[href="#events_calendar"]').on 'shown', ->
    $('#calendar').fullCalendar("render")
    $('#day_calendar').fullCalendar("render")

  $('a[href="#user_calendar"]').on 'shown', ->
    $('#calendar').fullCalendar("render")
    $('#day_calendar').fullCalendar("render")

  $(".level_group_checkbox").each ->
    container = $(this).parents(".level-group-container")
    if container.find(".level_checkbox").length  == container.find(".level_checkbox:checked").length
      $(this).click()


  check_youtube_url = (string) ->
    url = "http://gdata.youtube.com/feeds/api/videos/#{string}"
    http = new XMLHttpRequest()
    http.open "HEAD", url, false
    http.send()
    http.status is 200

  $("#show_video_modal").click ->
    val = $(this).parents("form").find("#event_youtube_id").val()
    $("#choose_video #video_string").val(val)
    $("#choose_video").modal('show')

  $("#choose_video").on "hide", (e) ->
    $("#youtube_video").remove()

  $("#show_preview").click ->
    $("#youtube_video").remove()
    modal = $(this).parents("#choose_video")
    modal_body = modal.find(".modal-body")
    value = modal.find("#video_string").val()
    error = modal_body.find(".error")
    if value != "" and check_youtube_url(value)
      error.remove()
      youtube = "<embed width='480' height='270' id='youtube_video' src='http://www.youtube.com/embed/#{value}?autoplay=1' frameborder='0'></embed>"
      modal_body.append(youtube)
    else
      if error.length == 0
        error_field = "<span class='error'>Please fill in correct youtube url.</span>"
        modal_body.append(error_field)

  $("#update_video_input").click ->
    modal = $(this).parents("#choose_video")
    modal_body = modal.find(".modal-body")
    value = modal.find("#video_string").val()
    error = modal_body.find(".error")
    if value != "" and check_youtube_url(value)
      $("#event_youtube_id").val(value)
      $("#event_youtube_id").parent().find("#youtube_value").html(value)
      $("#youtube_video").remove()
      modal.modal('hide')
    else
      if error.length == 0
        error_field = "<span class='error'>Please fill in correct youtube url.</span>"
        modal_body.append(error_field)
