$ ->
  $(".award_badge_modal .element_box").click ->
    value = $(this).attr("data-badge-id")
    $(".element_box").removeClass("checked")
    $(this).addClass("checked")
    $(".award_badge_modal #user_badge_badge_id").val(value)
    
    title_available = $(this).attr("data-title-available")
    console.log(title_available == "true")
    if title_available == "true"
      $(".award_badge_modal .title_available").addClass("show")
    else
      $(".award_badge_modal .title_available").removeClass("show")

  $("#award_multi_badge input#for_all_members, input#for_all_from_group, input#for_all_from_event, input#for_single_member").click ->
    $("#award_multi_badge .dropdown").slideUp()

  $("#award_multi_badge input#for_all_from_group").click ->
    $("#award_multi_badge .levels_dropdown").slideDown()

  $("#award_multi_badge input#for_single_member").click ->
    $("#award_multi_badge .members_dropdown").slideDown()

  $("#award_multi_badge input#for_all_from_event").click ->
    $("#award_multi_badge .events_dropdown").slideDown()

  $(".award-multi-badge").click ->
    badgeId = $(this).data('badge-id')
    $("#award_multi_badge input#badge_id").val(badgeId)