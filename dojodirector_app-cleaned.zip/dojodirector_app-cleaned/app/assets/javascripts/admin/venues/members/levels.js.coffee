$ ->    
  $(".levels li.checked").parents("ul.levels").show()
  $(".levels li.checked").parents(".level_group").find("span").addClass("unfolded")
  
  $(".confirm_level").click ->
    member_id = $(this).data('member-id')
    venue_id =  $(this).data('club-id')
    level_id = $("#change-user-#{member_id}-role #main_list .checked").data("level-id")
    awarded_at = $("#change-user-#{member_id}-role input.awarded_at").val()
    
    $.ajax
      url: "/admin/venues/#{venue_id}/members/#{member_id}/levels/#{level_id}"
      type: 'PUT'
      data:
        awarded_at: awarded_at
        
      success: ->
        window.location.reload()
        
      error: ->
        console.log("error")

    return false
    
  $(".level_group span").click ->
    levels = $(this).parent().find(".levels")
    visible = levels.is(':visible')
    if visible
      $(this).removeClass("unfolded")
      levels.hide()
    else
      $(this).addClass("unfolded")
      levels.show()

  $(".levels li").click ->
    $(".levels li").removeClass("checked")
    $(this).addClass("checked")
