$ ->
  is_old_ie = ->
    $.browser.msie and (parseInt($.browser.version) < 9)
    
  $("#print_qr_codes").click ->
    if is_old_ie() == true
      alert("We're sorry, you cannot print this document in your browser, please use another one.")
    else
      window.print()
    return false

  if $('.venue-members tbody').length > 0
    @table = $('.venue-members tbody');
    @table.find("tr.details").hide();

    @table.find("tr.accordion").click ->
      detail_row = $(this).next("tr")
      visible = detail_row.is(":visible")
      $('.venue-members tbody').find("tr.accordion").removeClass("open")
      $('.venue-members tbody').find("tr.details").hide()
      unless visible
        $(this).addClass("open")
        detail_row.show()
        window.location.hash = detail_row.parents('tbody').find('tr.open').data('member-id')
      false

  if window.location.hash
    member_id = parseInt(window.location.hash[1..-1])
    $("tr.accordion[data-member-id=#{member_id}]").click() if !isNaN(member_id)

  $("a[rel='tooltip']").click ->
    return false

  $(".element_box").click ->
    $(".element_box").removeClass("checked")
    $(this).addClass("checked")
