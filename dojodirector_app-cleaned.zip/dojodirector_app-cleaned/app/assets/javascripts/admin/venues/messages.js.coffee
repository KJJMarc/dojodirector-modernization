$ ->
  get_params = ->
    values = new Array
    $(".level_checkbox:checked").each ->
      value = $(this).val()
      values.push(value)
    return {
    levels: values
    suspended: $(".include_suspended").is(":checked")
    }

  get_levels_names = (levels_ids) ->
    values = []
    for id in levels_ids
      label = $(".label_check[data-level-id='" + id + "']")
      name = label.find("span").html()
      value = []
      value = [name, id]
      values.push(value)

    return values

  levels_ajax_request = ->
    $.ajax(
      url: $("#level_checkboxes").data('messages-url'),
      dataType: "json"
      data: get_params()
      cache: false
      success: (data) ->
        $("span.members_count").fadeOut ->
          $(this).html(data['users'])
          $(this).fadeIn()
    )

  $(".filter").click ->
    levels_ajax_request()

  $("#send_group_message").click ->
    href = $("#new_message").attr('action')
    $("#new_message").attr('action', "#{href}?#{$.param(get_params())}")
    $("#new_message").submit()
    return false

  $(".level_group_checkbox").click ->
    checked = $(this).is(":checked")
    $(this).parent().parent().find(".filter").each ->
      $(this).attr('checked', checked)
      $(this).trigger("click")
      $(this).attr('checked', checked)

  if $("#level_checkboxes").size > 0
    levels_ajax_request()

  $(".choose_levels_modal").on "hide", (e) ->
    levels_ajax_request()
    field = $(".fields.for span.levels")
    params = get_params()
    levels = get_levels_names(params.levels)
    suspended = params.suspended

    if (levels and levels.length != 0) or suspended
      $(field).html("")
      span = "<span class='level'></span>"
      for key, val of levels
        $(field).append($(span).append("<span>Level</span>: #{val[0]}"))
      if suspended
        $(field).append($(span).append("suspended members"))

  if $(".choose_levels_modal").length != 0
    $(".choose_levels_modal").modal("hide")
