$ ->
  $(".sortable").each (i, object) ->
    $("#" + $(object).attr("id")).sortable({
      handle: '.name',
      update: (e, ui) ->
        $.ajax
          type: "PUT",
          url: $(e.target).data("sort-url"),
          data: $(e.target).sortable("serialize")
    })
