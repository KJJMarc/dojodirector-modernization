$ ->
  if $(".make-role").length > 0
    $(".make-role").click ->
      $.ajax
        url: '/admin/roles',
        type: 'POST',
        data:
          user_id: $(this).data('user-id')
          club_id: $(this).data('club-id')
          'role[name]': $(this).data('role-name')
        success: ->
          window.location.reload()
        error: ->
          alert "Something went wrong"
      return false


