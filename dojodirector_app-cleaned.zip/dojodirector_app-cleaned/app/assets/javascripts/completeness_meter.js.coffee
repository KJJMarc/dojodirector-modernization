$(document).ready ->    
  if $(".completeness_meter").length > 0
    counter = parseFloat($(".completeness_meter .progress-counter span").html())
    meter_width = $(".completeness_meter .border").width()
    bar_width = $(".completeness_meter .progress-bar").width(meter_width * (counter / 100))