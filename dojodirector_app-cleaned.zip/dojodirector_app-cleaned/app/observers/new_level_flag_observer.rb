class NewLevelFlagObserver < ActiveRecord::Observer
  observe :event_attendee, :attendance, :user_level

  %w{after_create after_update after_destroy confirmed}.each do |callback|
    define_method callback do |record|
      update_new_level_flag_on_club_user record
    end 
  end

  private

  def update_new_level_flag_on_club_user record
    user = record.user
    club = record.club

    club_user = ClubUser.where(:club_id => club.id, :user_id => user.id).first
    club_user.update_new_level_flag
  end
end
