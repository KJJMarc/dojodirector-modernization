class EventAuthorizer < ApplicationAuthorizer
  def readable_by?(user)
    user.events.include?(resource) ||
    user.clubs.any? { |club| club.events.include?(resource) } ||
    super
  end
end
