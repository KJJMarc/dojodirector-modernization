class BadgeAuthorizer < Authority::Authorizer
  def self.default(adjective, user)
    true
  end

  def self.creatable_by?(user)
    super_admin(user)
  end

  def self.updatable_by?(user)
    super_admin(user)
  end

  def self.deletable_by?(user)
    super_admin(user)
  end

  private

  def self.super_admin(user)
    user.has_role?(:super_admin)
  end
end