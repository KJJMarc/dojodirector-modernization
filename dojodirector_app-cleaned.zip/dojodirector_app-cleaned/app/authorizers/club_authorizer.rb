class ClubAuthorizer < ApplicationAuthorizer
  def readable_by?(user)
    true
  end

  def self.creatable_by?(user)
    user.has_role?(:super_admin) || user.is_admin_of_approved_club?
  end
end
