class RoleAuthorizer < Authority::Authorizer
  def creatable_by?(user)
    permissions_for(user)
  end

  def readable_by?(user)
    true
  end

  def updatable_by?(user)
    permissions_for(user)
  end

  def deletable_by?(user)
    permissions_for(user) && !(resource.name == "admin" && resource.user == user)
  end

  private

  def permissions_for(user)
    if user.has_role?(:super_admin)
      true
    else
      club = resource.resource
      user.has_role?(:admin, club) && resource.name != "super_admin"
    end
  end
end
