# Other authorizers should subclass this one
class ApplicationAuthorizer < Authority::Authorizer

  # Any class method from Authority::Authorizer that isn't overridden
  # will call its authorizer's default method.
  #
  # @param [Symbol] adjective; example: `:creatable`
  # @param [Object] user - whatever represents the current user in your app
  # @return [Boolean]
  def self.default(adjective, user)
    user.has_role? :super_admin
  end

  def creatable_by?(user)
    club_admin_or_super_admin(user)
  end

  def readable_by?(user)
    club_admin_or_super_admin(user)
  end

  def updatable_by?(user)
    club_admin_or_super_admin(user)
  end

  def deletable_by?(user)
    club_admin_or_super_admin(user)
  end

  protected

  def self.super_admin?(user)
    user.has_role?(:super_admin)
  end

  def club_admin_or_super_admin(user)
    user.my_clubs.include?(resource) || user.has_role?(:super_admin)
  end
end
