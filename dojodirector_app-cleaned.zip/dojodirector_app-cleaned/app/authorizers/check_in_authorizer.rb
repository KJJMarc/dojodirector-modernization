class CheckInAuthorizer < ApplicationAuthorizer
  def self.creatable_by?(user)
    super_admin?(user) || user.active_clubs.any?
  end

  def creatable_by?(user)
    club_admin_or_super_admin(user) || user.active_at?(resource.club)
  end
end
