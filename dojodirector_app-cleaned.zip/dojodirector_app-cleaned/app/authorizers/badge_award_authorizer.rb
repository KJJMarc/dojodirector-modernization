class BadgeAwardAuthorizer < Authority::Authorizer
  def self.default(adjective, user)
    false
  end

  def awardable_by?(user)
    club_admin_or_super_admin(user)
  end

  private

  def club_admin_or_super_admin(user)
    user.my_clubs.include?(resource.club) || self.class.super_admin?(user)
  end

  def self.super_admin?(user)
    user.has_role?(:super_admin)
  end
end
