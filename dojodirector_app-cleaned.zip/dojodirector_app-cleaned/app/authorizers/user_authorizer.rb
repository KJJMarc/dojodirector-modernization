class UserAuthorizer < ApplicationAuthorizer
  def readable_by?(user)
    (resource == user) || club_admin_or_super_admin(user) || resource.clubs.map(&:users).flatten.include?(user)
  end

  def updatable_by?(user)
    (resource == user) || club_admin_or_super_admin(user)
  end

  private

  def club_admin_or_super_admin(user)
    user.my_clubs.any? { |club| resource.clubs.include?(club) } || user.has_role?(:super_admin)
  end
end
