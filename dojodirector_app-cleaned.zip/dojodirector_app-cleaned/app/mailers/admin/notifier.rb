class Admin::Notifier < ActionMailer::Base
  default from: "jjbpayments@gmail.com"

  def custom_message(recipient, options = {})
    @subject  = options[:subject]
    @body     = options[:body].to_s

    mail(
      :to       => recipient.email,
      :subject  => @subject,
      :body     => @body
    )
  end

  def temporary_club(club)
    @club = club

    mail
  end
end
