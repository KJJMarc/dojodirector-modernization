class User::Notifier < ActionMailer::Base
  default from: "jjbpayments@gmail.com"

  def custom_message(recipient, options = {})
    @subject  = options[:subject]
    @body     = options[:body].to_s

    mail(
      :to       => recipient.email,
      :subject  => @subject,
      :body     => @body
    )
  end

  def approved_club(club)
    @club = club
    mail(
      :subject => "Congratulations! Your club has been approved by Dojo Director"
    )
  end

  def rejected_club(club)
    @club = club
    mail
  end

  def canceled_event(event)
    @event = event
    mail
  end

  def new_level(user_level)
    @level  = user_level.level
    @club   = user_level.club
    @user   = user_level.user

    mail(
      :to       => @user.email,
      :subject  => "Congratulations! You've just received a new level from #{@club.name}"
    )
  end

  def new_badge(user_badge)
    @user   = user_badge.user
    @badge  = user_badge.badge
    @club   = user_badge.club

    mail(
      :to => @user.email,
      :subject => "Congratulations! You've just been awarded a new badge from #{@club.name}"
    )
  end

  def contact_us(sender, sender_name, subject, message)
    @message = message
    @name = sender_name
    @sender =  sender
    if Rails.env.development?
      to = 'zikoku07@gmail.com'
    else
      to = 'jjbpayments@gmail.com'
    end
    mail(
        :to => to,
        :subject => subject,
    )
  end
end
