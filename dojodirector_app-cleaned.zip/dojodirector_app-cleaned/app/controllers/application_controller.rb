class ApplicationController < ActionController::Base
  responders :flash

  protect_from_forgery

  before_filter :authenticate_user!
  before_filter :set_current_request
  before_filter :set_meta_tags

  after_filter :unset_current_request

  private

  def after_sign_in_path_for(resource = nil)
    if current_user.has_role? :super_admin
      admin_home_path
    elsif current_user.my_clubs.count > 0
      admin_venue_members_path(current_user.my_clubs.first)
    else
      user_profile_path(current_user)
    end
  end

  def set_current_request
    Thread.current[:current_request] = request
  end

  def unset_current_request
    Thread.current[:current_request] = nil
  end

  def load_and_authorize_club
    @club = Club.find(params[:id])
    authorize_action_for(@club)
  end

  def set_user
    @club = Club.find(params[:club_id]) rescue nil
    if current_user.has_role?(:super_admin)
      @user = User.find(params[:user_id])
    elsif @club && current_user.has_role?(:admin, @club)
      @user = @club.users.find(params[:user_id])
    else
      @user = current_user
    end
  end

  def search_users
    levels = params[:levels] ? params[:levels] : nil
    @members = @club.users.with_levels_at(levels, @club)

    if params[:suspended] != "true"
      @members = @members.without_suspended
    end

    @members = @members.to_a.uniq
  end

  def set_meta_tags
    @page_title = "Dojo Director - Manage Your Martial Arts Club"
    @meta_description = "Dojo Director is a new platform for sports clubs. Dojo Director enables clubs to track, manage & reward members"
    @meta_keywords = "Dojo Director, sport clubs, sport events, club members, badges, levels, events, manage sport clubs"
  end
end
