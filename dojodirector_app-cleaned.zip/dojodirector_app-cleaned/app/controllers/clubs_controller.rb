class ClubsController < ApplicationController
  skip_before_filter :authenticate_user!
  respond_to :html, :json

  def show
    @club = Club.find(params[:id])
    @feed_items = @club.feed_items.latest(Kaminari.config.default_per_page)
    @events = @club.events.upcoming
  end

  def updates
    @club       = Club.find(params[:id])
    @feed_items = @club.feed_items.order("updated_at DESC").page(params[:page]) if @club

    respond_with(@feed_items) do |format|
      format.html do
        if last_page?
          render :nothing => true
        else
          render :partial => "clubs/feed_item", :collection => @feed_items
        end
      end
    end
  end

  private

  def last_page?
    params[:page].to_i > @feed_items.num_pages
  end

end
