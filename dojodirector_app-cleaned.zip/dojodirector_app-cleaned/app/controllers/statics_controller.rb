class StaticsController < ApplicationController
  skip_before_filter :authenticate_user!
  layout "static"

  def terms
  end

  def faq
  end

  def contact
  end

  def submit_query
    User::Notifier.contact_us(params[:email], params[:name], params[:subject], params[:message]).deliver
    redirect_to contact_static_path, notice: 'Your message successfully submitted to Dojo DIrector Admin'
  end
end
