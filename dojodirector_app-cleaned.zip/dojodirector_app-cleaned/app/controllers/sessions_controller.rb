class SessionsController < Devise::SessionsController
  before_filter :check_username, :only => :create

  private

  def check_username
    if params[:user] && params[:user][:username].blank?
      params[:user][:username] = params[:user][:email]
    end
  end
end
