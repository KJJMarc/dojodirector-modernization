class Users::MessagesController < ApplicationController
  respond_to :html, :js, :json

  before_filter :set_user
  after_filter :notify_recipient, :only => :create

  def index
    @messages = current_user.received_messages
  end

  def show
    @message = current_user.messages.find(params[:id])
    @message.read if @message.to == current_user
  end

  def destroy
    @message = current_user.messages.find(params[:id])
    current_user.delete_message(@message)

    respond_with(@message, :location => user_messages_path(@user))
  end

  def new
    @message = Message.new
  end

  def create
    @to = User.find(params[:user_id])
    @message = current_user.send_message(@to, params[:message][:topic], params[:message][:body])

    respond_with(current_user, @message, :location => user_messages_path(@user),
                                         :notice => "Message was sent") do |format|
      format.html {
        render :new
      } unless @message.valid?
    end
  end

  def reply
    @message = current_user.messages.find(params[:id])
    @reply_message = request.post? ? @message.reply(params[:message]) : Message.new

    render :show if @reply_message && @reply_message.valid?
  end

  private

  def set_user
    @user = User.find(params[:user_id])
  end

  def notify_recipient
    CustomMessage.new(@message.to,
      :subject => @message.topic,
      :body => @message.body
    ).deliver if @message.valid?
  end
end


