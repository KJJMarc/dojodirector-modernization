class Users::RegistrationsController < Devise::RegistrationsController
  skip_before_filter :authenticate_user!
  before_filter :check_invitation, :only => :new_owner
  respond_to :html

  def new_owner
    @club = Club.new params[:club]
    @club.name ||= params[:club_name]
    @user = @club.users.build

    respond_with @club, :location => new_owner_registration_path
  end

  def create
    @club = Club.new params[:club]
    @user = @club.users.first
    if @club.valid? && @user.valid?
      @user.save
      @club.created_by = @user
      @club.save!

      @club.add_admin(@user)

      flash[:notice] = "Welcome! You have signed up successfully."
      sign_in(:user, @user)
      respond_with @user, :location => admin_venue_path(@club)
    else
      respond_with @user do |format|
        format.html { render 'new_owner' }
      end
    end
  end

  private

  def check_invitation
    if ProwdRails::Application::INVITATION_ONLY
      redirect_to invitation_only_static_path
    end
  end
end
