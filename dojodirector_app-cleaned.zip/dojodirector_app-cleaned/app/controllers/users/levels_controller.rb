class Users::LevelsController < ApplicationController
  before_filter :get_user
  skip_before_filter :authenticate_user!

  def show
    @level = @user.user_levels.find(params[:id])
  end

  private

  def get_user
    @user = User.find(params[:user_id])
  end
end


