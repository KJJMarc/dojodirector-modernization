class Users::CalendarController < ApplicationController
  respond_to :html, :json

  def show
    @user = User.find(params[:user_id])
    @clubs = @user.clubs
    @club = Club.find(params[:club_id]) rescue nil
    
    if @club
      events = @club.events.active
      levels = @user.levels_in_club(@club)
    else
      events = @user.events_in_active_clubs
      levels = @user.levels_in_active_clubs
    end
       
    @events = events.to_a
    @levels = levels.to_a
      
    @objects = @events + @levels
        
    @selected_calendar_club = @club.nil? ? "Select club" : @club.name
    @controller = "calendar"
    
    @objects_to_cal = @objects.to_json(calendar_options)

    respond_with(@objects) do |format|
      format.json {
        render :json => @objects.to_json(calendar_options) if current_user.can_update?(@user)
      }
    end
  end

  private

  def calendar_options
    { :calendar => true, :with_club_names => true, :user_id => @user.id }
  end

end
