class Users::CheckInsController < ApplicationController
  respond_to :html

  def create
    @check_in = current_user.check_ins.build(params[:check_in])
    authorize_action_for(@check_in)
    @check_in.save
    respond_with(@check_in, :location => user_profile_path(current_user))
  end
end
