class Users::AuthenticationsController < ApplicationController
  skip_before_filter :authenticate_user!

  def create
    if invite_token.present?
      require_no_authentication
      accept_invitation
    elsif user = User.find_by_facebook_uid(omniauth["uid"])
      require_no_authentication
      log_in(user)
    elsif current_user && omniauth["uid"]
      current_user.facebook_uid = omniauth["uid"]
      current_user.save

      flash[:notice] = "Your facebook account was connected"
      redirect_to user_profile_path(current_user)
    else
      redirect_to new_user_session_path, :alert => t('flash.unconnected', :scope => 'authentications')
    end
  end

  def failure
    error_message = t(params[:message], scope: 'authentications.error_messages', :default => params[:message])

    flash[:alert] = t('flash.provider_error', :message => error_message, :scope => 'authentications')
    redirect_to invite_token.present? ? accept_user_invitation_path(:invitation_token => invite_token) : new_user_session_path
  end

  private

  def accept_invitation
    if User.find_by_facebook_uid(omniauth['uid'])
      redirect_to accept_user_invitation_path(:invitation_token => invite_token), :alert => t('flash.already_connected', :scope => 'authentications') and return
    end

    if user = User.accept_invitation!(:invitation_token => invite_token) and user.errors.empty?
      user.update_attribute(:facebook_uid, omniauth['uid'])
      sign_in(:user, user)
      redirect_to user_profile_path(user), :notice => t('flash.connected', :scope => 'authentications')
    else
      redirect_to accept_user_invitation_path(:invitation_token => invite_token)
    end
  end

  def omniauth
    request.env["omniauth.auth"]
  end

  def log_in(user)
    flash[:notice] = t("devise.sessions.signed_in")
    sign_in_and_redirect(:user, user)
  end

  def invite_token
    omniauth_params['invite_token']
  end

  def omniauth_params
    request.env['omniauth.params'] || session['omniauth.params'] || {}
  end

  def require_no_authentication
    if warden.authenticated?(:user) && resource = warden.user(:user)
      flash[:alert] = I18n.t("devise.failure.already_authenticated")
      redirect_to after_sign_in_path_for(resource)
    end
  end

end
