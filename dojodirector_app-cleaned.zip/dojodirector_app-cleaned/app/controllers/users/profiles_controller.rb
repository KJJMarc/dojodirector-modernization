class Users::ProfilesController < ApplicationController
  respond_to :html, :json

  before_filter :set_user, :only => [:webcam_avatar, :update, :avatar_upload]

  skip_before_filter :authenticate_user!, :only => [:show, :show_badge]

  def show
    @user = User.find(params[:user_id])
    @clubs = @user.clubs

    @club = @clubs.find(params[:club_id] || @clubs.first.try(:id)) rescue nil
    @check_in = CheckIn.new(:club => @club)
    @feed_items = @club.feed_items.latest(Kaminari.config.default_per_page) if @club

    @badge = Badge.find_by_id(params[:badge_id]) if params[:badge_id]
    @level = Level.find_by_id(params[:level_id]) if params[:level_id]

    authorize_action_for(@user) if current_user
  end

  def update
    authorize_action_for(@user)
    @user.update_attributes(params[:user])
    respond_with(@user, :location => user_profile_path(@user)) do |format|
      format.json { render :json => @user.avatar.url(:thumb).to_json }
    end
  end

  def avatar_upload
    authorize_action_for(@user)
    @user.update_attributes(params[:user])
    render :json => @user.avatar.url(:thumb).to_json
  end

  def webcam_avatar
    authorize_action_for(@user)
    Tempfile.open("uploaded_photo.png") do |f|
      f.write request.raw_post.force_encoding("UTF-8")
      @user.avatar = f
      @user.save!
    end

    render :partial => "/shared/user_avatar_upload", :locals => { :user => @user }
  end

  def show_badge
    @user = User.find(params[:user_id])
    @clubs = @user.clubs
    @club = @clubs.find(params[:club_id] || @clubs.first.try(:id)) rescue nil
    @badge = @user.user_badges.find(params[:badge_id]) if params[:badge_id] rescue nil

    authorize_action_for(@user) if current_user
  end
end
