class Users::InvitationsController < Devise::InvitationsController
  prepend_before_filter :invalid?, :if => :invitation_token

  protected

  def after_accept_path_for(resource)
    user_profile_path(resource)
  end

  private

  def invitation_token
    params[:invitation_token]
  end

  def invalid?
    user = User.find_by_invitation_token(params[:invitation_token])
    token_expired = (Devise.invite_for == 0) ? false : (user.invitation_sent_at.to_time <= (Time.now - Devise.invite_for).to_time)
    if !user or token_expired
      redirect_to invalid_token_static_path
    end
  end
end
