class Users::BadgesController < ApplicationController
  respond_to :html
  before_filter :get_user
  
  skip_before_filter :authenticate_user!

  def index
    @badges = @user.user_badges.latest_first.group_by(&:club)
    respond_with(@badges)
  end

  def show
    @badge = @user.user_badges.find(params[:id])
    if params[:fb_share] == "true"
      @badge.facebook_share_counter += 1
      @badge.save
      render :text => '<script type="text/javascript"> window.close() </script>'
    end
  end

  private

  def get_user
    @user = User.find(params[:user_id])
  end
end
