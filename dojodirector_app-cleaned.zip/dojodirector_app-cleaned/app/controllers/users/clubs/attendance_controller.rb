class Users::Clubs::AttendanceController < ApplicationController

  def show
    @user = User.find params[:user_id]
    @clubs = @user.clubs
    @club = @user.clubs.find params[:club_id]
    @club_events = @club.events.active
    @club_events_by_date = @club_events.order("scheduled_at asc").
      group_by{|e| e.scheduled_at.to_date}

    @user_events = @user.events.active.confirmed.where(:club_id => @club.id)
    @attendances = @user.attendances.at_club(@club)
    @attendance_days = @attendances.map(&:date)

    @awarded_levels = @user.user_levels.where(:club_id => @club.id)
    @awarded_levels_by_date = @awarded_levels.
      group_by{|ul| ul.awarded_at.to_date }

    @year = params[:year] ? params[:year] : Date.today.year
    @total = @user_events.for_year(@year).count + @attendances.for_year(@year).count
    @selected_attendance_club = @club.nil? ? "Select club" : @club.name
    @controller = "attendance"
  end
  
  def update
    @user = User.find params[:user_id]
    @club = @user.clubs.find params[:club_id]

    date = params[:date].to_date
    
    # toggle daily attendance
    day_attendance = params[:attendance] == "true"
    @user.attendances.at_club(@club).toggle(date, day_attendance)

    event_ids = params[:events].nil? ? [] : params[:events].map(&:to_i)

    @club.events.daily_events(date).each do |event|
      event.toggle_attendance @user, event_ids.include?(event.id)
    end

    redirect_to user_club_attendance_path(:year => date.year)
  end

  def update_attendance
    user = User.find params[:user_id]
    club = user.clubs.find params[:club_id]

    date = params[:date].to_date
     attendance =  Attendance.where(user_id: user.id, club_id: club.id, date: date).first
    if attendance.present?
      attendance.destroy
    else
    Attendance.create(user: user, club: club, date: date)
    end
    respond_to do |format|
      format.js
    end
  end
end
