class Api::UsersController < Api::ApiController
  respond_to :json

  before_filter :load_and_authorize_user, :only => :show

  authority_action :show => 'update'

  def show
    @user = UserPresenter.new(@user)

    respond_with(@user)
  end
end
