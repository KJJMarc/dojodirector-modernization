class Api::Users::MessagesController < Api::ApiController
  respond_to :json

  def index
    @user     = User.find(params[:user_id])
    @messages = @user.received_messages
    @messages = CollectionPresenter.new(@messages, :root => :messages, :presenter => MessagePresenter)

    respond_with(@messages)
  end
end
