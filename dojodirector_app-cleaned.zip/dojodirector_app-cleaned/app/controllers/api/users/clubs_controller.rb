class Api::Users::ClubsController < Api::ApiController
  respond_to :json

  before_filter :load_and_authorize_user, :only => :index

  def index
    @clubs = @user.clubs
    @clubs = CollectionPresenter.new(@clubs, :root => :clubs, :presenter => ClubPresenter)

    respond_with(@clubs)
  end

  private

  def load_and_authorize_user
    @user = User.find(params[:user_id])
    authorize_action_for(@user)
  end
end
