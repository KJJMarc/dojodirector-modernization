class Api::Users::CheckinsController < ApplicationController
  respond_to :json

  before_filter :load_and_authorize_user, :only => :index

  def index
    @check_ins = @user.check_ins
    @check_ins = CollectionPresenter.new(@check_ins, :root => :check_ins, :presenter => CheckInPresenter)

    respond_with(@check_ins)
  end

  private

  def load_and_authorize_user
    @user = User.find(params[:user_id])
    authorize_action_for(@user)
  end
end
