class Api::Users::BadgesController < Api::ApiController
  respond_to :json

  def index
    @user   = User.find(params[:user_id])
    @badges = CollectionPresenter.new(@user.user_badges.includes(:badge), :root => :badges,
                                      :presenter => UserBadgePresenter)

    respond_with(@badges)
  end
end
