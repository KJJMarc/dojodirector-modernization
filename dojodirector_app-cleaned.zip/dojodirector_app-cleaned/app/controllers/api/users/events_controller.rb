class Api::Users::EventsController < Api::ApiController
  respond_to :json

  def index
    @user   = User.find(params[:user_id])
    @events = CollectionPresenter.new(@user.events, :root => :events, :presenter => EventPresenter)

    respond_with(@events)
  end
end
