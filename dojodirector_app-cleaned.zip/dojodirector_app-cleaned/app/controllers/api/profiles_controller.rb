class Api::ProfilesController < Api::ApiController
  respond_to :json

  def show
    respond_with ProfilePresenter.new(current_user)
  end
end
