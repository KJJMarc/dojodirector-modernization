class Api::EventsController < ApplicationController
  respond_to :json

  def show
    @event = Event.find(params[:id])
    respond_with(EventPresenter.new(@event))
  end

  def update
    @event = Event.find(params[:id])
    if @event.update_attributes(params[:event])
      @event = EventPresenter.new(@event.reload)
    end

    respond_with(@event, :location => "")
  end

  def attendees
    @event  = Event.find(params[:id])
    @club   = @event.club
    authorize_action_for(@club)
    @users  = params[:users_ids].map { |user_id| User.find(user_id) }

    @users.each do |user|
      @event.event_attendees.create(:user => user, :event => @event)
    end

    @users = CollectionPresenter.new(@users, :root => :attendees, :presenter => UserPresenter)

    respond_with(@users, :location => "")
  end
end
