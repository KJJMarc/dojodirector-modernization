class Api::ApiController < ApplicationController
  before_filter :skip_trackable

  def skip_trackable
    request.env['devise.skip_trackable'] = true
  end

  private

  def load_and_authorize_user
    @user = User.find(params[:id])
    authorize_action_for(@user)
  end
end
