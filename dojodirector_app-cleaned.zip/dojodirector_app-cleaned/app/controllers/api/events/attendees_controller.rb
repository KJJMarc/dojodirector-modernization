class Api::Events::AttendeesController < Api::ApiController
  respond_to :json

  before_filter :load_and_authorize_event

  def index
    @attendees = @event.attendees
    @attendees = CollectionPresenter.new(@attendees, :root => :attendees, :presenter => UserPresenter)

    respond_with(@attendees)
  end

  private

  def load_and_authorize_event
    @event = Event.find(params[:event_id])
    authorize_action_for(@event)
  end
end
