class Api::ClubsController < Api::ApiController
  respond_to :json

  before_filter :load_and_authorize_club, :only => :show

  def show
    @club = ClubPresenter.new(@club)

    respond_with(@club)
  end
end
