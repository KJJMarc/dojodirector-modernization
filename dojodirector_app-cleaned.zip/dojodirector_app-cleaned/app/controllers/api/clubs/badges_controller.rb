class Api::Clubs::BadgesController < ApplicationController
  respond_to :json

  def index
    @club = Club.find(params[:club_id])
    @badges = @club.badges
    @badges = CollectionPresenter.new(@badges, :root => :badges, :presenter => BadgePresenter)

    respond_with(@badges)
  end
end
