class Api::Clubs::MembersController < Api::ApiController
  respond_to :json

  def index
    @club     = Club.find(params[:club_id])
    @members  = @club.users
    @members  = CollectionPresenter.new(@members, :root => :members, :presenter => UserPresenter)

    respond_with(@members)
  end

  def search
    @club     = Club.find(params[:club_id])
    @members  = @club.users
    @members  = @members.search(params[:query])
    @members  = CollectionPresenter.new(@members, :root => :members, :presenter => UserPresenter)

    respond_with(@members)
  end
end
