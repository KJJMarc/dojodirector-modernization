class Api::Clubs::EventsController < ApplicationController
  respond_to :json

  def index
    load_events
  end

  def upcoming
    load_events :upcoming
  end

  def past
    load_events :past
  end

  def create
    @club   = Club.find(params[:club_id])
    authorize_action_for(@club)

    @event  = @club.events.create(params[:event])
    @event  = EventPresenter.new(@event) if @event.valid?

    respond_with(@event, :location => "")
  end

  def cancel
    @club   = Club.find(params[:club_id])
    @event  = @club.events.find(params[:id])
    authorize_action_for(@club)
    @event.cancel

    respond_with(@event)
  end

  private

  def load_events(filter = nil)
    @club   = Club.find(params[:club_id])
    @events = filter ? @club.events.send(filter) : @club.events
    @events = CollectionPresenter.new(@events, :root => :events, :presenter => EventPresenter)

    respond_with(@events)
  end
end
