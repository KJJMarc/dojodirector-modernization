class Api::Clubs::Members::LevelsController < ApplicationController
  respond_to :json

  def create
    @club         = Club.find(params[:club_id])
    @member       = @club.users.find(params[:member_id])
    @level        = @club.club_type.levels.find(params[:level_id])
    @awarded_at   = params[:awarded_at]
    authorize_action_for(@club)

    @user_level   = @member.set_level_in_club(@level, @club, @awarded_at)
    @level        = LevelPresenter.new(@user_level.level) if @level.valid?

    respond_with(@level, :location => "")
  end
end
