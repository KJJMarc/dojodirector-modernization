class Api::Clubs::Members::AttendancesController < ApplicationController
  respond_to :json

  def create
    date = params[:attendance][:date].to_date
    attended = params[:attendance][:attended].to_s == "true"
    @club         = Club.find(params[:club_id])
    @user         = @club.users.find(params[:member_id])
    authorize_action_for(@club)

    attendance = @user.attendances.at_club(@club).toggle(date, attended)

    respond_with(attendance, :location => "")
  end
end
