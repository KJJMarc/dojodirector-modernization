class Api::Clubs::Members::RolesController < Api::ApiController
  respond_to :json

  def create
    @club = Club.find(params[:club_id])
    @user = User.find(params[:member_id])
    @role = Role.new(params[:role])
    @role.resource = @club

    authorize_action_for(@role)
    @role = @user.add_role @role.name, @club
    @role = RolePresenter.new(@role)

    respond_with(@role, :location => "")
  end
end
