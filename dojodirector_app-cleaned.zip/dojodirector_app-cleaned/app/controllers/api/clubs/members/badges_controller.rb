class Api::Clubs::Members::BadgesController < ApplicationController
  respond_to :json

  def index
    @user   = User.find(params[:member_id])
    @club   = @user.clubs.find(params[:club_id])
    @badges = @user.user_badges.where("user_badges.club_id = ?", @club)
    @badges = CollectionPresenter.new(@badges, :root => :badges, :presenter => UserBadgePresenter)

    respond_with(@badges)
  end

  def create
    @user   = User.find(params[:member_id])
    @club   = @user.clubs.find(params[:club_id])
    @badge  = Badge.find(params[:badge_id])
    authorize_action_for(@club)

    @user_badge = @user.user_badges.create(:badge => @badge, :club => @club, :title => params[:title])
    @user_badge = UserBadgePresenter.new(@user_badge) if @user_badge.valid?

    respond_with(@user_badge, :location => "")
  end
end
