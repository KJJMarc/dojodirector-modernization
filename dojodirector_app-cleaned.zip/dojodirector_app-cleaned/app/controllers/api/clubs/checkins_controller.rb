class Api::Clubs::CheckinsController < ApplicationController
  respond_to :json

  def index
    @club       = Club.find(params[:club_id])
    @check_ins  = @club.check_ins
    @check_ins  = CollectionPresenter.new(@check_ins, :root => :check_ins, :presenter => CheckInPresenter)

    respond_with(@check_ins)
  end

  def create
    @club           = Club.find(params[:club_id])
    @check_in       = @club.check_ins.build(params[:check_in])
    @check_in.user  = current_user
    authorize_action_for(@check_in)
    @check_in = CheckInPresenter.new(@check_in) if @check_in.save

    respond_with(@check_in, :location => "")
  end
end
