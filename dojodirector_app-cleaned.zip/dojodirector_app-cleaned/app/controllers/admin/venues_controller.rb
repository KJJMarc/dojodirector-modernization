class Admin::VenuesController < ApplicationController
  respond_to :html
  respond_to :json, :only => [:update]

  authority_action(:show => :update)

  before_filter :load_and_authorize_club, :except => :index

  def index
    @clubs = current_user.my_clubs.page(params[:page])
  end

  def show
    redirect_to admin_venue_members_path(@club), flash.to_hash
  end

  def edit
    @club.build_address unless @club.address
  end

  def update
    unless current_user.has_role?(:super_admin)
      params[:club].delete(:federation_id)
    end

    address_data = params[:club][:address_attributes]
    # ignore address if it was not filled in
    if address_data && address_data.all?{|k,v| v.blank?}
      params[:club].delete(:address_attributes)
    end

    if @club.update_attributes(params[:club])
      respond_with(@club, :location => admin_venue_members_path(@club)) do |format|
        format.json { render :json => @club.logo.url(:medium).to_json  }
      end
    else
      render "edit"
    end
  end

  def dismiss_reminder
    @club.update_attribute(:completeness_reminder_dismissed_at, Time.now)
    redirect_to admin_venue_path(@club)
  end

  private

  def sort_column
    User.column_names.include?(params[:sort]) ? params[:sort] : "created_at"
  end

  def sort_direction
    %w[asc desc].include?(params[:direction]) ? params[:direction] : "desc"
  end
end
