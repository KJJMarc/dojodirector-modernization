class Admin::Venues::MembersController < Admin::VenueSubpageController
  helper_method :sort_column, :sort_direction

  def index
    @search = MemberSearch.new(@club, params)
    @members = @search.members
  end

  def qr_codes
    @search = MemberSearch.new(@club, params)
    @members = @search.members.limit(nil).offset(nil)
  end

  def show
    @member = @club.users.find(params[:id])
  end

  def new
    @member = @club.users.build
    respond_with(@club)
  end

  def create
    @member = User.create_and_add_to_club params[:user], @club
    respond_with(@member, :location => new_admin_venue_member_path(@club))
  end

  def edit
    @member = @club.users.find(params[:id])
    @member.address || @member.build_address
  end

  def update
    @member = @club.users.find(params[:id])

    if params[:user][:password].blank?
      params[:user].delete(:password)
      params[:user].delete(:password_confirmation)
    end
    address_data = params[:user][:address_attributes]
    # ignore address if it was not filled in
    if address_data && address_data.all?{|k,v| v.blank?}
      params[:user].delete(:address_attributes)
    end

    @member.update_attributes(params[:user])
    respond_with(@member, :location => admin_venue_member_path(@club, @member))
  end

  def destroy
    member = @club.users.find(params[:id])
    if member.has_role?(:admin, @club)
      redirect_to admin_venue_members_path(@club),
                  :alert => "You can not delete admin"
    else
      if member.destroy
        redirect_to admin_venue_members_path(@club),
                    :notice => "Member successfully deleted"
      else
        redirect_to admin_venue_members_path(@club),
                    :alert => "Something Wrong please try later"
      end
    end
  end

  def suspend
    @member = @club.users.find(params[:id])
    @member.suspend(@club)
    respond_with(@member, :location => { :action => :show },
                          :notice => "Account suspended",
                          :alert => @member.errors.full_messages.join)
  end

  def unsuspend
    @member = @club.users.find(params[:id])
    @member.unsuspend(@club)
    respond_with(@member, :location => { :action => :show }, :notice => "Account unsuspended")
  end

  def sort_column
    @search.sort_column
  end

  def sort_direction
    @search.direction
  end


  def attendances
    @date = Date.today
    @club       = Club.find(params[:venue_id])
    @members = @club.users.without_suspended
    if params[:date].present?
      @date = params[:date]
    end

    respond_with(@all_events) do |format|
      format.js
    end
  end

end
