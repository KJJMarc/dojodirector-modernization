class Admin::Venues::Members::BadgesController < Admin::VenueSubpageController
  respond_to :html, :js
  before_filter :set_member

  def index
    @badges = @member.user_badges.latest_first.with_badge.page(params[:page]).per(20)
  end

  def create
    @user_badge = @member.user_badges.new(params[:user_badge])
    @user_badge.club = @club

    @user_badge.save
    respond_with(@user_badge,
                 :location => admin_venue_member_path(@club, @member),
                 :notice => "Badge was successfully awarded") do |format|
      format.html {
        redirect_to admin_venue_member_path(@club, @member),
        :alert => "Badge could not be awarded"
      } unless @user_badge.valid?
      format.js {
        render :json => UserBadgePresenter.new(@user_badge)
      }
    end
  end

  def destroy
    @user_badge = @member.user_badges.find(params[:id])
    @user_badge.destroy
    respond_with(@badge, :location => { :action => :index }, :notice => "Badge removed" ) do |format|
      format.js { render :json => @user_badge }
    end
  end

  private

  def set_member
    @member = @club.users.find(params[:member_id])
  end
end
