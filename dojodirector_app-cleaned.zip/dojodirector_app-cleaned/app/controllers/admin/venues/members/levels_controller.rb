class Admin::Venues::Members::LevelsController < Admin::VenueSubpageController
  respond_to :html, :js, :json
  
  def index
    @member = @club.users.find(params[:member_id])
    @levels = @member.user_levels.where(:club_id => @club.id)
  end

  def update
    @member = @club.users.find(params[:member_id])
    @levels = @member.user_levels.where(:club_id => @club.id)

    @level = @club.club_type.levels.find(params[:id])
    @awarded_at = params[:awarded_at]

    @member.set_level_in_club(@level, @club, @awarded_at)
    
    respond_with(@member, :location => admin_venue_member_path(@club, @member),
                          :notice => "Level was updated") do |format|
                            format.html {
                              render :index
                            }
                          end
  end

  def destroy
    @member = @club.users.find(params[:member_id])
    @level  = @club.club_type.levels.find(params[:id])
    @member.remove_level_in_club(@level, @club)
    respond_with(@member, :location => admin_venue_member_path(@club, @member))
  end
end
