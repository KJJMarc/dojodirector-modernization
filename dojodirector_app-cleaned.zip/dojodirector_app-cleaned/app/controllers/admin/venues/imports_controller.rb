require 'csv'

class Admin::Venues::ImportsController < Admin::VenueSubpageController

  def new
    @import = @club.user_imports.new
    @levels = @club.club_type.levels if @club.club_type.present?
  end

  def index
    @imports = @club.user_imports.order("created_at DESC").first(10)
  end

  def create
    @import = @club.user_imports.new params[:user_import]

    if @import.save
      @import.process!
      redirect_to admin_venue_imports_path(@club)
    else
      @levels = @club.club_type.levels if @club.club_type.present?
      render :new
    end
  end

end
