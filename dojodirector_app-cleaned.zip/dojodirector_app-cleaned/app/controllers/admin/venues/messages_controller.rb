class Admin::Venues::MessagesController < Admin::VenueSubpageController
  before_filter :search_users

  def new
    @group_message = GroupMessage.new
    respond_with(@group_message)
  end

  def index
    @group_messages = @club.group_messages.latest_first.page(params[:page])

    respond_with(@members) do |format|
      format.json { render :json => {:users => @members.length} }
    end
  end

  def show
    @group_message = @club.group_messages.find params[:id]
  end

  def create
    @levels = params[:levels]

    @group_message = GroupMessage.new params[:group_message]
    @group_message.members = @members
    @group_message.user = current_user
    @group_message.club = @club
    @group_message.save

    respond_with(@group_message, :location => { :action => :new })
  end

  private

  def sort_column
    User.column_names.include?(params[:sort]) ? params[:sort] : "created_at"
  end

  def sort_direction
    %w[asc desc].include?(params[:direction]) ? params[:direction] : "desc"
  end
end
