class Admin::Venues::EventsController < Admin::VenueSubpageController
  before_filter :search_users
  before_filter :set_event, :except => [:index, :new, :create, :create_collection]

  before_filter :level_on_event, :only => :create

  def index
    @all_events = @club.events.active

    respond_with(@all_events) do |format|
      format.json { render :json => @all_events.to_json(:calendar => true, :admin => true) }
    end
  end

  def show
    @levels = @event.levels
  end

  def new
    @event = @club.events.build
  end

  def clone
    event_params = @event.attributes.slice("name", "description", "youtube_id",
                                           "scheduled_at", "end_at")
    @levels = @event.levels.map { |level| level.id.to_s }
    @event = @club.events.build(event_params)
  end

  def cancel
    collection = @event.event_collection
    if params[:cancel] == "series" && collection
      collection.cancel_and_notify params[:notify_attendees]
    else
      @event.cancel_and_notify(params[:notify_attendees])
    end

    respond_with(@event, :location => { :action => :index }, :notice => "Event was successfully canceled.")
  end

  def create
    params[:event][:level_ids] = params[:level_ids]
    @event = @club.events.create params[:event]
    unless @event.save
      @event_collection = @club.event_collections.build params[:event_collection]
    end
    respond_with @event, :location => admin_venue_events_path(@club)
  end

  def edit
    @levels = @event.levels.map { |level| level.id.to_s }
  end

  def update
    params[:event][:level_ids] = params[:level_ids]
    @event.update_attributes(params[:event])
    respond_with(@event, :location => admin_venue_event_path(@club, @event))
  end

  private

  def set_event
    @event = @club.events.active.find(params[:id])
  end

  def level_on_event
    @levels = fetch_level_ids(:event)
  end

  def level_on_event_collection
    @levels = fetch_level_ids(:event_collection)
  end

  def fetch_level_ids(scope)
    Array(params.fetch(scope, {}).fetch(:level_ids, []))
  end
end
