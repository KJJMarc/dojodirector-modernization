class Admin::Venues::LevelsController < Admin::VenueSubpageController
  def index
    @level_groups = @club.club_type.level_groups
  end
end
