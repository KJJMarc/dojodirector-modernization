class Admin::Venues::BadgesController < Admin::VenueSubpageController
  authorize_actions_for Badge, :except => :award
  authority_action :new => 'read'

  def index
    @levels = []
    level_groups =  @club.level_groups
    level_groups.each do |lg|
      @levels += lg.levels
    end
    @events = @club.events
    @users =  @club.users
  end

  def show
    @badge = Badge.find(params[:id])
    @user_badges = @club.user_badges.for_badge(@badge).with_user
  end

  def new
    @badge = @club.custom_badges.build
  end

  def create
    @badge = @club.custom_badges.create(params[:badge])
    respond_with(@badge, :location => admin_venue_badges_path(@badge.club), :anchor =>"#badges")
  end

  def award
    @badge  = Badge.find(params[:badge_id])
    if params[:user].present?
      member =  User.find_by_id(params[:user])
      user_badge = member.user_badges.new(badge_id: params[:badge_id], title: params[:message])
      user_badge.club = @club
      user_badge.save
      if user_badge.save
        flash[:notice] = "Badge has been assigned to the users"
      else
        flash[:alert] = "Something went wrong"
      end
    else
      @badge_award  = BadgeAward.new(@club, @badge, params)
      if current_user.can_award?(@badge_award) && BadgeAward.new(@club, @badge, params).award
        flash[:notice] = "Badge has been assigned to the users"
      else
        flash[:alert] = "Something went wrong"
      end
    end

    redirect_to admin_venue_badges_path(@club)
  end

  def edit
    @badge = @club.badges.find(params[:id])
  end

  def update
    @badge = @club.badges.find(params[:id])
    @badge.update_attributes(params[:badge]) if @badge.users.count == 0
    respond_with(@badge, :location => admin_venue_badges_path(@badge.club), :anchor =>"#badges")
  end

  def destroy
    @badge = @club.badges.find(params[:id])
    @badge.destroy if @badge.users.count == 0
    respond_with(@badge, :location => admin_venue_badges_path(@badge.club), :anchor =>"#badges")
  end
end
