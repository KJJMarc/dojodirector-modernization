class Admin::Venues::EventsCollectionsController < Admin::VenueSubpageController
  before_filter :search_users

  before_filter :level_on_event, :only => :create

  def new
    @event_collection = @club.event_collections.build
  end

  def create
    params[:event_collection][:level_ids] = params[:level_ids]
    @event_collection = @club.event_collections.build(params[:event_collection])
    unless @event_collection.save
      @show_collection = true
    end
    respond_with @event_collection, :location => admin_venue_events_path(@club),
      :notice => "Event collection was successfully created."
  end

  private

  def level_on_event
    @levels = fetch_level_ids(:event)
  end

  def fetch_level_ids(scope)
    Array(params.fetch(scope, {}).fetch(:level_ids, []))
  end
end
