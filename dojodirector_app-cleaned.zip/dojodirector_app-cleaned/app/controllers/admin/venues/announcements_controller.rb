class Admin::Venues::AnnouncementsController < Admin::VenueSubpageController
  before_filter :load_announcement, :except => [:new, :create, :index]

  def index
    @announcements = @club.announcements
  end

  def new
    @announcement = Announcement.new(params[:announcement])
  end

  def show
    respond_with(@announcement)
  end

  def edit
    respond_with(@announcement)
  end

  def create
    @announcement      = Announcement.new(params[:announcement])
    @announcement.club = @club
    @announcement.save

    respond_with(@announcement, :location => admin_venue_announcements_path(@club, :anchor =>"announcements"))
  end

  def update
    @announcement.update_attributes(params[:announcement])
    respond_with(@club, @announcement, :location => admin_venue_announcement_path)
  end

  def destroy
    @announcement.destroy
    respond_with(@club, @announcement, :location => admin_venue_announcements_path(@club, :anchor =>"announcements"))
  end

  private

  def load_announcement
    @announcement = @club.announcements.find(params[:id])
  end
end
