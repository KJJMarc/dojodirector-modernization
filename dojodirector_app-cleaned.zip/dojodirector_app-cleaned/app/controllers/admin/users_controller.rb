class Admin::UsersController < ApplicationController
  authorize_actions_for ApplicationAuthorizer

  def index
    @users = User.all
  end

  def show
    @user = User.find(params[:id])
  end
end
