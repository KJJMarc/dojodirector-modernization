class Admin::ClubTypesController < ApplicationController
  authorize_actions_for ApplicationAuthorizer

  def index
    @club_types = ClubType.all
  end

  def show
    @club_type = ClubType.find(params[:id])
    @badges = @club_type.badges
    @club_type.clubs.each do |club|
      @badges +=  club.custom_badges
    end
  end

  def new
    @club_type = ClubType.new
  end

  def create
    @club_type = ClubType.new(params[:club_type])
    if @club_type.save
      redirect_to admin_club_type_path(@club_type), :notice => "Successfully created!"
    else
      render "new"
    end
  end

  def edit
    @club_type = ClubType.find(params[:id])
  end

  def update
    @club_type = ClubType.find(params[:id])
    if @club_type.update_attributes(params[:club_type])
      redirect_to admin_club_type_path(@club_type), :notice => "Successfully changed!"
    else
      render "edit"
    end
  end

  def destroy
    club_type = ClubType.find(params[:id])
    club_type.is_deleted = true
    if club_type.save
      redirect_to admin_club_types_path, notice: 'Club Type Successfully Deleted'
    else
      redirect_to admin_club_types_path, alert: 'Something Worng Please try again'
    end
  end
end
