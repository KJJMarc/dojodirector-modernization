class Admin::ClubsController < ApplicationController
  respond_to :html

  authorize_actions_for ClubAuthorizer
  helper_method :sort_column, :sort_direction

  def index
    @clubs = Club.order(sort_column + " " + sort_direction).
                  page(params[:page])
  end

  def new
    @club = Club.new(params[:club])

    @club.users.build if current_user.has_role?(:super_admin)
    @club.build_address

    respond_with(@club)
  end

  def create
    @club = Club.create_with_user params[:club], current_user

    url = current_user.has_role?(:super_admin) ?
      admin_clubs_path : admin_venues_path
    respond_with(@club, :location => url)
  end

  def approve
    @club = Club.find(params[:id])
    msg = @club.approve ? { :notice => "Club approved" } : { :alert => "Could not approve club" }

    respond_with(:admin, @club, { :location => request.referer}.merge(msg))
  end

  def reject
    @club = Club.find(params[:id])
    msg = @club.reject ? { :notice => "Club rejected" } : { :alert => "Could not reject club" }
    respond_with(:admin, @club, { :location => request.referer}.merge(msg))
  end

  def destroy
    club = Club.find(params[:id])
    club.is_deleted = true
    if club.save
      redirect_to admin_clubs_path, notice: 'Club Successfully Deleted'
    else
      redirect_to admin_clubs_path, alert: 'Something Worng Please try again'
    end
  end

  def search
    query = params[:query]

    if query.blank?
      @clubs = Club.scoped
    else
      @clubs = Club.joins(:users => :roles).
                    joins(:address).
                    where(:roles => { :name => :admin }).
                    where("addresses.line_1 ILIKE :query OR
                          addresses.line_2 ILIKE :query OR
                          addresses.city ILIKE :query OR
                          addresses.postcode ILIKE :query OR
                          clubs.name ILIKE :query OR
                          users.email ILIKE :query",
                          :query => "%#{query}%"
                    ).select("DISTINCT(clubs.id), clubs.*")
    end

    @clubs = @clubs.page(0)
    render :index
  end

  private

  def sort_column
    Club.column_names.include?(params[:sort]) ? params[:sort] : "created_at"
  end

  def sort_direction
    %w[asc desc].include?(params[:direction]) ? params[:direction] : "desc"
  end
end
