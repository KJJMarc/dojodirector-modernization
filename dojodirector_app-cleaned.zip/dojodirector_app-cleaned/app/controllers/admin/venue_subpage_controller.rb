class Admin::VenueSubpageController < ApplicationController
  layout 'admin/venue_subpage'
  before_filter :load_and_authorize_venue

  respond_to :html

  protected

  def load_and_authorize_venue
    @club = Club.find(params[:venue_id])
    authorize_action_for(@club)
  end

end
