class Admin::HomeController < ApplicationController
  authorize_actions_for ApplicationAuthorizer

  def show
    @club_types = ClubType
    @clubs = Club
    @users = User
  end
end
