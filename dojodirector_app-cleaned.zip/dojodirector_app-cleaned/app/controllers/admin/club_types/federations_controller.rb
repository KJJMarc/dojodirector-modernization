class Admin::ClubTypes::FederationsController < ApplicationController
  authorize_actions_for ApplicationAuthorizer

  before_filter :set_club_type

  respond_to :html

  def show
    @federation = @club_type.federations.find(params[:id])
    respond_with(@federation)
  end

  def new
    @federation = @club_type.federations.build
    respond_with(@federation)
  end

  def create
    @federation = @club_type.federations.build(params[:federation])
    @federation.save
    respond_with(@federation, :location => admin_club_type_path(@club_type, :anchor => "federations"))
  end

  def edit
    @federation = @club_type.federations.find(params[:id])
    respond_with(@federation, :location => admin_club_type_path(@club_type, :anchor => "federations"))
  end

  def update
    @federation = @club_type.federations.find(params[:id])
    @federation.update_attributes(params[:federation])
    respond_with(@federation, :location => admin_club_type_path(@club_type, :anchor => "federations"))
  end

  def destroy
    @federation = @club_type.federations.find(params[:id])
    @federation.destroy
    respond_with(@federation, :location => admin_club_type_path(@club_type, :anchor => "federations"))
  end

  private

  def set_club_type
    @club_type = ClubType.find(params[:club_type_id])
  end
end
