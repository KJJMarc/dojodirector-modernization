class Admin::ClubTypes::LevelGroups::LevelsController < ApplicationController
  authorize_actions_for ApplicationAuthorizer

  before_filter :set_club_type

  respond_to :html

  def new
    @level = @level_group.levels.build(:club_type => @club_type)
    respond_with(@level)
  end

  def create
    @level = @level_group.levels.build(params[:level].merge(:club_type => @club_type))
    @level.save
    respond_with(@level, :location => admin_club_type_path(@club_type, :anchor => "levels"))
  end

  def edit
    @level = @level_group.levels.find(params[:id])
  end

  def update
    @level = @level_group.levels.find(params[:id])
    @level.update_attributes(params[:level])
    respond_with(@level, :location => admin_club_type_path(@club_type, :anchor => "levels"))
  end

  def destroy
    @level = @level_group.levels.find(params[:id])
    @level.destroy
    respond_with(@level, :location => admin_club_type_path(@club_type, :anchor => "levels"))
  end

  private
  def set_club_type
    @club_type = ClubType.find(params[:club_type_id])
    @level_group = @club_type.level_groups.find(params[:level_group_id])
  end
end
