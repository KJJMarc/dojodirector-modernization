class Admin::ClubTypes::LevelGroupsController < ApplicationController
  authorize_actions_for ApplicationAuthorizer

  before_filter :set_club_type

  respond_to :json, :only => [:sort]
  respond_to :html, :json, :only => [:update]
  respond_to :html
  def new
    @level_group = @club_type.level_groups.build
    respond_with(@level_group)
  end

  def create
    @level_group = @club_type.level_groups.build(params[:level_group])
    @level_group.save
    respond_with(@level_group, :location => admin_club_type_path(@club_type, :anchor => "levels"))
  end

  def edit
    @level_group = @club_type.level_groups.find(params[:id])
  end

  def update
    @level_group = @club_type.level_groups.find(params[:id])
    @level_group.update_levels_positions!(params[:levels])

    @level_group.update_attributes(params[:level_group])
    respond_with(@level_group, :location => admin_club_type_path(@club_type, :anchor => "levels"))
  end

  def destroy
    @level_group = @club_type.level_groups.find(params[:id])
    @level_group.destroy

    respond_with(@level_group, :location => admin_club_type_path(@club_type, :anchor => "levels"))
  end

  def sort
    @club_type.level_groups.update_positions!(params[:level_groups])
    respond_with true
  end

  private
  def set_club_type
    @club_type = ClubType.find(params[:club_type_id])
  end
end
