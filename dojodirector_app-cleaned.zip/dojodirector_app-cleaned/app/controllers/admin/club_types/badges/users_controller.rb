class Admin::ClubTypes::Badges::UsersController < ApplicationController
  authorize_actions_for ApplicationAuthorizer

  def index
    @club_type = ClubType.find(params[:club_type_id])
    @badge = @club_type.badges.find(params[:badge_id])
  end
end
