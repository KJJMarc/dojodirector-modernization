class Admin::ClubTypes::BadgesController < ApplicationController
  authorize_actions_for ApplicationAuthorizer

  before_filter :set_club_type

  respond_to :html

  def new
    @badge = @club_type.badges.build
    respond_with(@badge)
  end

  def create
    @badge = @club_type.badges.build(params[:badge])
    @badge.save
    respond_with(@badge, :location => admin_club_type_path(@club_type, :anchor => "badges"))
  end

  def edit
    @badge = Badge.find(params[:id])
    respond_with(@badge)
  end

  def update
    @badge = Badge.find(params[:id])
    @badge.update_attributes(params[:badge])
    respond_with(@badge, :location => admin_club_type_path(@club_type, :anchor => "badges"))
  end

  def destroy
    @badge = Badge.find(params[:id])
    @badge.destroy
    respond_with(@badge, :location => admin_club_type_path(@club_type, :anchor => "badges"))
  end

  private

  def set_club_type
    @club_type = ClubType.find(params[:club_type_id])
  end
end
