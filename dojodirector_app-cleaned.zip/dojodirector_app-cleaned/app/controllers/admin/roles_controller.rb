class Admin::RolesController < ApplicationController
  respond_to :html, :js

  before_filter :load_user_and_club

  def create
    @role = Role.new(params[:role])
    @role.resource = @club

    authorize_action_for(@role)

    @user.add_role @role.name, @club
    respond_with(@role, :location => request.referer)
  end

  def destroy
    @role = Role.find(params[:id])
    @role.user = @user

    authorize_action_for(@role)

    @user.remove_role(@role.name, @club)
    respond_with(@role, :location => request.referer)
  end

  private

  def load_user_and_club
    @user = User.find(params[:user_id])
    @club = Club.find(params[:club_id])
  end
end
