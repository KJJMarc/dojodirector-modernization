class ClubType::FederationsController < ApplicationController
  skip_before_filter :authenticate_user!

  respond_to :json

  def index
    @federations = Federation.where(:club_type_id => params[:club_type_id])
    respond_with @federations
  end
end
