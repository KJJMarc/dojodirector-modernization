class HomeController < ApplicationController
  skip_before_filter :authenticate_user!
  before_filter :redirect_to_relevant_profile, :if => proc { user_signed_in? }

  def index
    render :layout => "homepage"
  end

  def landing
    render :layout => "landing"
  end

  protected

  def redirect_to_relevant_profile
    redirect_to after_sign_in_path_for
  end

end
