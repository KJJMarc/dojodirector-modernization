class Clubs::EventsController < ApplicationController
  respond_to :html
  before_filter :parse_dates, :only => :index
  skip_before_filter :authenticate_user!, :only => [:show, :index]

  def index
    @club   = Club.find(params[:club_id])
    @events = @club.events.period_events(@start, @end)

    respond_with(@events) do |format|
      format.json { render :json => @events.to_json(:calendar => true) }
    end
  end

  def show
    @club   = Club.find(params[:club_id])
    @event  = @club.events.find(params[:id])
    @levels = @event.levels
  end

  def attend
    @club   = current_user.clubs.find(params[:club_id])
    @event  = @club.events.find(params[:event_id])
    @event.attend(current_user)

    respond_with(@club, @event)
  end

  def unattend
    @club   = current_user.clubs.find(params[:club_id])
    @event  = @club.events.find(params[:event_id])
    @event.unattend(current_user)

    respond_with(@club, @event)
  end

  protected

  def parse_dates
    @start  = params[:start] ? Time.at(params[:start].to_i) : nil
    @end    = params[:start] ? Time.at(params[:end].to_i) : nil
  end

end
