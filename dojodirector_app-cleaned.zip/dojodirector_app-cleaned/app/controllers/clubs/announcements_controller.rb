class Clubs::AnnouncementsController < ApplicationController
  respond_to :html

  def show
    @club = Club.find(params[:club_id])
    @announcement = @club.announcements.find(params[:id])
  end
end
