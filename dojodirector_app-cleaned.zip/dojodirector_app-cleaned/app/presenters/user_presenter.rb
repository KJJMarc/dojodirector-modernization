class UserPresenter
  attr_reader :user

  def initialize(user)
    @user = user
  end

  def as_json(*)
    {
      :id             => id,
      :email          => email,
      :full_name      => full_name,
      :gender         => gender,
      :phone_number   => phone_number,
      :avatar_url     => avatar_url,
      :super_admin => is_super_admin?,
      :statement      => statement
    }
  end

  def avatar_url
    avatar.url(:medium)
  end

  def is_super_admin?
    user.has_role? :super_admin
  end

  delegate :id, :email, :full_name, :gender,
           :phone_number, :statement, :avatar, :to => :user
end
