class CollectionPresenter
  include Enumerable

  attr_reader :collection, :root, :presenter

  def initialize(collection, options = {})
    @collection = collection
    @root       = options[:root] || :collection
    @presenter  = options[:presenter]
  end

  def as_json(*)
    {
      root => collection.map { |item|
        presenter ? presenter.new(item) : item
      }
    }
  end

  def each &blk
    collection.each &blk
  end
end