class ClubPresenter
  attr_reader :club

  def initialize(club)
    @club = club
  end

  def as_json(*)
    {
      :id                     => id,
      :name                   => name,
      :logo_url               => logo_url,
      :club_type              => club_type,
      :status                 => status,
      :twitter_url            => twitter_url,
      :facebook_url           => facebook_url,
      :website_url            => website_url,
      :phone_number           => phone_number,
      :emergency_phone_number => emergency_phone_number
    }
  end

  def logo_url
    logo.url(:medium)
  end

  def club_type
    ClubTypePresenter.new(club.club_type)
  end

  delegate :id, :name, :logo, :status, :twitter_url,
           :facebook_url, :website_url, :phone_number,
           :emergency_phone_number, :to => :club
end