class UserBadgePresenter
  attr_reader :user_badge

  def initialize(user_badge, overrides = {})
    @user_badge = user_badge
    @overrides = overrides
  end

  def as_json(*)
    BadgePresenter.new(user_badge.badge).merge(
      {
        :title => title,
        :club_name => club.name,
        :club_id => club_id
      }.merge(@overrides)
    )
  end

  delegate :title, :club_id, :club, :to => :user_badge
end
