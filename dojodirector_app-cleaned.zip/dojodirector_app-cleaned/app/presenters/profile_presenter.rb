class ProfilePresenter < UserPresenter
  attr_reader :user

  def as_json(*)
    super.merge(:clubs => clubs, :badges =>  badges)
  end

  def clubs
    user.clubs.map do |club|
      ClubProfilePresenter.new(club, user)
    end
  end

  def badges
    user.user_badges.map do |user_badge|
      UserBadgePresenter.new(user_badge, :created_at => user_badge.created_at)
    end
  end
end
