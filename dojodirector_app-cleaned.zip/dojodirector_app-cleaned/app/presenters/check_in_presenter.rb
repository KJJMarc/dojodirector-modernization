class CheckInPresenter
  attr_accessor :check_in

  def initialize(check_in)
    @check_in = check_in
  end

  def as_json(*)
    {
      :id       => id,
      :content  => content,
      :user_id  => user_id,
      :club_id  => club_id
    }
  end

  delegate :id, :content, :user_id, :club_id, :errors, :to => :check_in
end