class RolePresenter
  attr_reader :role

  def initialize(role)
    @role = role
  end

  def as_json(*)
    {
      :id       => id,
      :name     => name,
      :club_id  => resource_id
    }
  end

  def resource_id
    resource.id
  end

  delegate :id, :name, :resource, :to => :role
end