class MessagePresenter
  attr_reader :message

  def initialize(message)
    @message = message
  end

  def as_json(*)
    {
      :id           => id,
      :topic        => topic,
      :body         => body,
      :readed       => readed,
      :sender_id    => sender_id
    }
  end

  def sender_id
    sent_messageable_id
  end

  def readed
    open?
  end

  delegate :id, :topic, :body, :sent_messageable_id, :open?, :to => :message
end