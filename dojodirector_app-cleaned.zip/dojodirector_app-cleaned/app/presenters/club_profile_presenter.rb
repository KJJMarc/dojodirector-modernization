class ClubProfilePresenter
  attr_reader :club, :user

  def initialize(club, user)
    @club = club
    @user = user
  end

  def as_json(*)
    {
      :id           => id,
      :name         => name,
      :logo_url     => logo_url,
      :role_in_club => role_in_club,
      :suspended    => suspended?,
      :attendance_count => attendance_count,
      :check_ins_count => check_ins_count,
      :level           => level
    }
  end

  def logo_url
    logo.url(:medium)
  end

  def level
    if level = user.current_level_in(club)
      LevelPresenter.new(level)
    end
  end

  def role_in_club
    if user.has_role?(:super_admin)
      return "Admin"
    else
      user_roles = user.roles_for(club).map(&:name)
      %w{admin}.detect do |role|
        user_roles.include?(role)
      end.try(:humanize) || "None"
    end
  end

  def check_ins_count
    user.check_ins_in(club)
  end

  def attendance_count
    user.attendances_in(club)
  end

  def suspended?
    user.membership_at(club).suspended?
  end

  delegate :id, :name, :logo, :to => :club
end
