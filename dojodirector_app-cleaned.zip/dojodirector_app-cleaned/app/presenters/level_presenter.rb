class LevelPresenter
  attr_reader :level

  def initialize(level)
    @level = level
  end

  def as_json(*)
    {
      :id               => id,
      :name             => name,
      :position         => position,
      :image_url        => image_url,
      :code             => code,
      :weeks_to_achieve => weeks_to_achieve,
      :times_to_achieve => times_to_achieve,
      :club_type        => club_type
    }
  end

  def club_type
    ClubTypePresenter.new(level.club_type)
  end

  def image_url
    image.url(:medium)
  end

  delegate :id, :name, :position, :image, :code,
           :weeks_to_achieve, :times_to_achieve, :to => :level
end
