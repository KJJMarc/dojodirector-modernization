class BadgePresenter
  attr_reader :badge

  def initialize(badge, overrides = {})
    @badge = badge
    @overrides = overrides
  end

  def as_json(*)
    {
      :id           => id,
      :name         => name,
      :description  => description,
      :image_url    => image_url,
      :club_id      => club_id
    }.merge @overrides
  end

  def image_url
    image.url(:medium)
  end

  delegate :id, :name, :description, :club_id, :image, :to => :badge
  delegate :merge, :to => :as_json
end
