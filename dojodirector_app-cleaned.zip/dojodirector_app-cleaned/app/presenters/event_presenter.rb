class EventPresenter
  attr_reader :event

  def initialize(event)
    @event = event
  end

  def as_json(*)
    {
      :id           => id,
      :name         => name,
      :description  => description,
      :club_id      => club_id,
      :scheduled_at => scheduled_at,
      :end_at       => end_at,
      :status       => status
    }
  end

  delegate :id, :name, :description, :club_id,
    :scheduled_at, :end_at, :status, :to => :event
end
