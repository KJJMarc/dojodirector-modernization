class ClubTypePresenter
  attr_reader :club_type

  def initialize(club_type)
    @club_type = club_type
  end

  def as_json(*)
    {
      :id             => id,
      :type_name      => type_name,
      :token_criteria => token_criteria
    }
  end

  delegate :id, :type_name, :token_criteria, :to => :club_type
end