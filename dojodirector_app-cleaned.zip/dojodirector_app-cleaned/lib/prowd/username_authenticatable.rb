module Devise
  # Keys that should be downcased upon creating or modyfying a user
  mattr_accessor :downcase_keys
  @@downcase_keys = []

  module Models
    module UsernameAuthenticatable
      VALIDATIONS = [ :validates_presence_of, :validates_uniqueness_of, :validates_format_of,
                      :validates_confirmation_of, :validates_length_of ].freeze

      def self.required_fields(klass)
        []
      end

      def self.included(base)
        base.extend ClassMethods
        assert_validations_api!(base)

        base.class_eval do
          validates_presence_of   :email, :if => :email_required?
          validates_format_of     :email, :with  => email_regexp, :allow_blank => true, :if => :email_changed?

          validates_presence_of     :password, :if => :password_required?
          validates_confirmation_of :password, :if => :password_required?
          validates_length_of       :password, :within => password_length, :allow_blank => true

          validates_presence_of :username
          validates_uniqueness_of :username, :case_sensitive => false, :if => :username_changed?
          validates_length_of :username, :in => 0..255, :if => :username_changed?
        end
      end

      def self.assert_validations_api!(base) #:nodoc:
        unavailable_validations = VALIDATIONS.select { |v| !base.respond_to?(v) }

        unless unavailable_validations.empty?
          raise "Could not use :validatable module since #{base} does not respond " <<
          "to the following methods: #{unavailable_validations.to_sentence}."
        end
      end

      protected

      def downcase_keys
        self.class.downcase_keys.each { |k| apply_to_attribute_or_variable(k, :downcase!) }
      end

      # Checks whether a password is needed or not. For validations only.
      # Passwords are always required if it's a new record, or if the password
      # or confirmation are being set somewhere.
      def password_required?
        !persisted? || !password.nil? || !password_confirmation.nil?
      end

      def valid_password?(password)
        (password.blank? && encrypted_password.blank? && facebook_uid.present?) || super
      end

      def email_required?
        true
      end

      module ClassMethods
        Devise::Models.config(self, :email_regexp, :password_length, :downcase_keys)

        def find_first_by_auth_conditions(tainted_conditions, opts = {})
          conditions = devise_parameter_filter.filter(tainted_conditions).map do |key, value|
            column_name = case_insensitive_keys.include?(key) && !downcase_keys.include?(key) ? "LOWER(#{key})" : key
            to_adapter.klass.send(:sanitize_sql_array, ["#{column_name} = ?", value])
          end.join(' AND ')

          to_adapter.klass.find(:first, :conditions => conditions)
        end
      end

    end
  end
end

Devise.add_module :username_authenticatable

require 'devise_invitable'
