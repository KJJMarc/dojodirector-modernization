module Prowd
  class Seeder
    def initialize number_of_records
      @number_of_records = number_of_records
    end

    def number_of type
      rand(@number_of_records[type][0]) + @number_of_records[type][1]
    end

    def create_clubs club_type, number = nil
      number ||= number_of(:clubs)

      Timecop.freeze(rand(100).days.ago) do
        number.times do |i|
          address = FactoryGirl.build :address

          club_name = "#{address.city} #{club_type.type_name} #{(Club.last.try(:id) || 0)+1}"

          club = FactoryGirl.build :club,
            :name => club_name,
            :club_type => club_type

          club.address = address
          club.save!

          admin = FactoryGirl.create(:user)
          admin.add_role :admin, club

          club.approve! if (rand(100) > 2)
          club.save!
        end
      end
    end

    def add_levels_to_club_type club_type, number = nil
      number ||= number_of(:levels)
      Timecop.freeze(rand(100).days.ago) do
        lg = FactoryGirl.create :level_group,
          :club_type => club_type

        number.times.each do |i|
          FactoryGirl.create :level,
            :level_group => lg,
            :club_type => club_type
        end
      end
    end

    def add_badges_to_club_type club_type, number = nil
      number ||= number_of(:badges)
      Timecop.freeze(rand(100).days.ago) do
        number.times.each do |i|
          FactoryGirl.create :badge,
            :club_type => club_type
        end
      end
    end

    def add_users_to_club club, number = nil
      number ||= number_of(:members)
      Timecop.travel(rand(100).days.ago) do
        number.times.each do |i|
          member = FactoryGirl.create(:user)
          club.users << member
        end
      end
    end

    def add_events_to_club club, number = nil
      number ||= number_of(:events)
      dates = ((number*2).days.ago.to_date..(number * 2).days.from_now.to_date).
        to_a.sample(number)

      dates.each do |date|
        member = FactoryGirl.create :event,
          :start_date => date,
          :scheduled_at => (date.to_time + rand(23).hours),
          :club => club
      end
    end

    def add_levels_to_user club, user, number = nil
      number ||= number_of(:user_levels)
      number.times do |i|
        Timecop.travel(rand(100).days.ago) do
          FactoryGirl.create :user_level,
            :user => user,
            :club => club,
            :level => club.levels.to_a.sample
        end
      end
    end

    def add_badges_to_user club, user, number = nil
      number ||= number_of(:user_badges)
      number.times do |i|
        Timecop.travel(rand(100).days.ago) do
          FactoryGirl.create :user_badge,
            :user => user,
            :club => club,
            :badge => club.badges.to_a.sample
        end
      end
    end

    def add_attendances club, user, number = nil
      number ||= number_of(:attendances)
      number.times do |i|
        # take number of dates from the range
        dates = ((number*3).days.ago.to_date..Time.now.to_date).to_a.sample(number)
        dates.each do |date|
          begin
            FactoryGirl.create :attendance,
              :user => user,
              :club => club,
              :date => date
          rescue
            nil
          end
        end
      end
    end

    def add_events_attended club, user, number = nil
      number ||= number_of(:events_attended)
      events = club.events.to_a.sample(number)
      events.each do |event|
        FactoryGirl.create :event_attendee,
          :user => user,
          :event => event,
          :confirmed => (rand(2) == 0)
      end
    end

    def add_checkins club, user, number = nil
      number ||= number_of(:events_attended)
      number.times do |i|
        # take number of dates from the range
        dates = ((number*3).days.ago.to_date..Time.now.to_date).to_a.sample(number)
        dates.each do |date|
          Timecop.travel(date) do
            FactoryGirl.create :check_in,
              :user => user,
              :club => club,
              :content => Faker::Lorem.sentence
          end
        end
      end
    end

    def add_member_data club_user
      club = club_user.club
      user = club_user.user

      add_levels_to_user club, user
      add_badges_to_user club, user
      add_attendances club, user
      add_checkins club, user
      add_events_attended club, user
    end
  end
end
