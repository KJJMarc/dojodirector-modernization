class CustomMessage
  def initialize(*args)
    @options    = args.extract_options!
    @recipient  = args.first
  end

  def deliver
    deliver_with_action_mailer
  end

  def deliver_with_action_mailer
    message = Admin::Notifier.custom_message(@recipient, @options)
    message.deliver
  end
end