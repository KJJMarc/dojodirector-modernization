# DojoDirector recovered legacy Rails app - GitHub safe archive

This archive has been cleaned for private GitHub storage. It is intended for code review and migration planning, not direct production deployment.

Removed from this archive:

- `.git/` history from the recovered server copy
- `log/` files
- `tmp/` cache files
- `backup.zip`
- SQL/database dump files
- `public/assets/` compiled asset output
- production credential files such as `config/database.yml`, `config/application.yml`, `config/newrelic.yml`, and legacy secret token initialiser

Added example templates:

- `config/database.yml.example`
- `config/application.yml.example`
- `config/initializers/secret_token.rb.example`

Keep the original recovered ZIP and SQL dump offline as private backups. Do not upload production credentials or the `.pem` SSH key to GitHub.
