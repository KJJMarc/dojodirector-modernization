ProwdRails::Application.routes.draw do
  constraints :subdomain => /^api/ do
    scope :constraints => ApiVersion.new(:version => 1, :default => true) do
      devise_scope :user do
        post "/login" => "sessions#create"
      end

      scope :module => :api do
        resource :profile, :only => :show
        resources :clubs, :only => :show do
          resources :badges, :only => :index, :module => :clubs
          resources :events, :only => [:index, :create], :module => :clubs do
            collection do
              get :past
              get :upcoming
            end
            member do
              put :cancel
            end
          end
          resources :checkins, :only => [:index, :create], :module => :clubs
          resources :members, :only => :index, :module => :clubs do
            collection do
              get :search
            end
            resources :badges, :only => [:index, :create], :module => :members
            resources :roles, :only => :create, :module => :members
            resources :levels, :only => :create, :module => :members
            resources :attendances, :only => :create, :module => :members
          end
        end
        resources :events, :only => [:show, :update] do
          member do
            post :attendees
          end
          resources :attendees, :only => :index, :module => :events
        end
        resources :users, :only => :show do
          scope :module => :users do
            resources :checkins, :only => :index
            resources :clubs, :only => :index
            resources :events, :only => :index
            resources :messages, :only => :index
            resources :badges, :only => :index
          end
        end
      end
    end
  end

  #NOTE: setup omniauth routes
  match '/auth/failure' => 'users/authentications#failure'
  match '/auth/facebook/callback' => 'users/authentications#create'

  devise_for :users, :controllers  => {
                                        :registrations  => 'users/registrations',
                                        :invitations    => 'users/invitations',
                                        :passwords      => 'users/passwords'
                                      }
  devise_scope :user do
    get  'owner/sign_up' => 'users/registrations#new_owner', :as => 'new_owner_registration'
    post 'owner/sign_up' => 'users/registrations#create',    :as => 'owner_registration'
  end

  namespace :admin do
    resource :home, :controller => "home"
    resources :roles, :only => [:create, :destroy]
    resources :clubs do
      member do
        put :approve
        put :reject
      end
      collection do
        get :search
      end
    end
    resources :users, :only => [:index, :show]
    resources :club_types do
      resources :badges, :module => :club_types, :except => [:index, :show] do
        resources :users, :module => :badges, :only => :index
      end
      resources :level_groups, :module => :club_types,
        :only => [:new, :create, :edit, :update, :destroy] do
        put :sort, on: :collection
        resources :levels, :module => :level_groups,
          :only => [:show, :new, :create, :edit, :update, :destroy]
      end
      resources :federations, :module => :club_types, :except => [:index]
    end
    resources :venues, :only => [:index, :show, :update, :edit] do
      member do
        get :dismiss_reminder
      end
      resources :badges, :module => :venues do
        collection do
          post :award
        end
      end
      resources :checkins, :module => :venues, :only => :index
      resources :members, :module => :venues do
        collection do
          get :qr_codes
          get :attendances
        end
        member do
          put :suspend
          put :unsuspend
        end
        resources :levels, :module => :members, :only => [:index, :update, :destroy]
        resources :badges, :module => :members, :only => [:index, :create, :destroy]
      end

      resources :imports, :module => :venues, :only => [:index, :new, :create]

      resources :events, :module => :venues do
        member do
          get :clone
          put :cancel
          get :members
        end
      end
      resources :events_collections, :module => :venues, :only => [:new, :create]
      resources :messages, :module => :venues,
        :only => [:new, :index, :show, :create]
      resources :announcements, :module => :venues
    end
  end

  resources :club_types, :only => [] do
    resources :federations, :controller => "club_type/federations",
                            :only => :index
  end

  resources :clubs, :only => [:show] do

    member do
      get :updates
    end
    resources :events, :only => [:show, :index], :module => :clubs do
      put :attend
      put :unattend
    end
    resources :announcements, :only => :show, :module => :clubs
    resources :badges, :only => :index, :module => :clubs
    resources :check_ins, :only => :index, :module => :clubs
  end

  resources :users, :only => [] do
    scope :module => :users do
      resource :calendar, :only => :show, :controller => "calendar"
      resources :badges, :only => [:index, :show]
      resources :levels, :only => :show
      resource :profile do
        post :avatar_upload,  :on => :member
        post :webcam_avatar,  :on => :member
        get  :show_badge,     :on => :member
      end
      resource :check_ins, :only => :create
      resources :messages do
        member do
          get :reply
          post :reply
        end
      end
      resources :clubs, :only => [] do
        scope :module => :clubs do
          resource :attendance, :only => [:show, :update], :controller => "attendance" do
            member do
              put :update_attendance
            end
          end
        end
      end
    end
  end

  resource :static, :path => '', :only => [] do
    collection do
      get :terms
      get :faq
      get :contact
      get :privacy_policy
      get :invitation_only
      get :invalid_token
      post :submit_query
    end
  end

  root :to => "home#landing"
  get 'landing' => "home#landing"
end
