ProwdRails::Application.configure do
  # Settings specified here will take precedence over those in config/application.rb

  # In the development environment your application's code is reloaded on
  # every request. This slows down response time but is perfect for development
  # since you don't have to restart the web server when you make code changes.
  config.cache_classes = false

  # Log error messages when you accidentally call methods on nil.
  config.whiny_nils = true

  # Show full error reports and disable caching
  config.consider_all_requests_local       = true
  config.action_controller.perform_caching = false

  # Don't care if the mailer can't send
  config.action_mailer.raise_delivery_errors = true

  # Print deprecation notices to the Rails logger
  config.active_support.deprecation = :log

  # Only use best-standards-support built into browsers
  config.action_dispatch.best_standards_support = :builtin

  # Raise exception on mass assignment protection for Active Record models
  config.active_record.mass_assignment_sanitizer = :strict

  # Log the query plan for queries taking more than this (works
  # with SQLite, MySQL, and PostgreSQL)
  config.active_record.auto_explain_threshold_in_seconds = 0.5

  # Do not compress assets
  config.assets.compress = false

  # Expands the lines which load the assets
  config.assets.debug = true

  # Default url for mailer
  config.action_mailer.default_url_options = { :host => 'localhost:3000' }
  config.paperclip_defaults = {
      :storage => :fog,
      :path => 'uploads/:class/:attachment/:id_partition/:style/:basename.:extension',
      :fog_directory => ENV['FOG_DIRECTORY'],
      :fog_credentials => {
          :provider => 'AWS',
          :region => ENV['FOG_REGION'],
          :aws_access_key_id => ENV['AWS_ACCESS_KEY_ID'],
          :aws_secret_access_key => ENV['AWS_SECRET_ACCESS_KEY']
      }
  }
  
  INVITATION_ONLY = false

  ActionMailer::Base.smtp_settings = {
      :user_name => "apikey",
      :password => "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",
      :domain => "dojodirector.com",
      :address => "smtp.sendgrid.net",
      :port => 587,
      :authentication => :plain,
      :enable_starttls_auto => true
  }
end
