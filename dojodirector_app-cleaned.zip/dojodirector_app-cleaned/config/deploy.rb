# set :scm, :git # You can set :scm explicitly or Capistrano will make an intelligent guess based on known version control directory names
# Or: `accurev`, `bzr`, `cvs`, `darcs`, `git`, `mercurial`, `perforce`, `subversion` or `none`

require 'rvm/capistrano'
require 'bundler/capistrano'

role :web, '18.188.89.48' # Your HTTP server, Apache/etc
role :app, '18.188.89.48' # This may be the same as your `Web` server
role :db, '18.188.89.48', :primary => true # This is where Rails migrations will run
role :db, '18.188.89.48'

set :stages, %w(production)
set :default_stage, 'production'

# =============================================================================
# VARIABLES
# =============================================================================
set :application, 'prowd'
set :rvm_ruby_string, 'ruby-1.9.3-p551'
set :repository, 'git@bitbucket.org:zikoku07/prowd-rails.git'
set :deploy_to, '/home/ubuntu/apps/prowd'
set :branch, 'master'
set :user, 'ubuntu'
set :rails_env, 'production'
set :scm, :git
set :rvm_type, :user

set :linked_files, %w{config/database.yml config/application.yml}

# Default value for linked_dirs is []
# set :linked_dirs, 'log', 'tmp/pids', 'tmp/cache', 'tmp/sockets', 'public/system'
set :linked_dirs, %w{log tmp/pids tmp/cache tmp/sockets vendor/bundle public/system public/assets public/uploads pdf_files}

# =============================================================================
# SETTINGS
# =============================================================================
set :pty, true
set :forward_agent, true
set :deploy_via, :remote_cache
set :use_sudo, false
set :keep_releases, 5

after 'deploy:create_symlink', 'deploy:cus_symlink'
after 'deploy:create_symlink', 'deploy:precompile'
after 'deploy:create_symlink', 'deploy:migration'
after 'deploy:restart', 'deploy:cleanup'

namespace :deploy do
  desc 'Symlink linked directories'
  task :cus_symlink do
    fetch(:linked_files).each do |dir|
      target = "#{release_path}/#{dir}"
      source = "#{shared_path}/#{dir}"
      run "ln '-s' #{source} #{target}"
    end
  end

  desc 'Run pending migration'
  task :migration do
    run "cd -- #{release_path} && RAILS_ENV=production bundle exec rake db:migrate"
  end

  desc 'start assets precompile'
  task :precompile do
    run "cd -- #{release_path} && RAILS_ENV=production RAILS_GROUPS=assets bundle exec rake assets:precompile"
  end

  desc 'cause Passenger to initiate a restart'
  task :restart do
    run "touch #{current_path}/tmp/restart.txt"
  end

  desc 'reload the database with seed data'
  task :seed do
    deploy.migrations
    run "cd #{current_path}; rake db:seed RAILS_ENV=#{rails_env}"
  end
end