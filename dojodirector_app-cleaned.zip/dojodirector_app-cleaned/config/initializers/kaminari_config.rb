Kaminari.configure do |config|
  config.default_per_page = Rails.env.test? ? 2 : 20
  config.outer_window = 1
end