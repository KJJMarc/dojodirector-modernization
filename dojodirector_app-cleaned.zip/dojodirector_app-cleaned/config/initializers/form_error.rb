ActionView::Base.field_error_proc = Proc.new do |html_tag, instance|
  object        = instance.object
  method_name   = instance.method_name
  unless html_tag =~ /^<label/
    error_message = %{<div class="field_with_errors">#{html_tag}<label for="#{instance.send(:tag_id)}" class="message">#{instance.error_message.first}</label></div>}.html_safe
  else
    error_message = %{<div class="field_with_errors">#{html_tag}</div>}.html_safe
  end

  if object.respond_to?(:fields_with_validation) && object.fields_with_validation.kind_of?(Array)
    if object.fields_with_validation.include?(method_name)
      error_message
    else
      "#{html_tag}".html_safe
    end
  else
    error_message
  end
end