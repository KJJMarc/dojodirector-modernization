key, secret = case Rails.env
              when 'production' then ["1550475868413199" , "212702a14cd05890aaab763a52bd42ac"]
              when 'staging' then ["1550475868413199", "212702a14cd05890aaab763a52bd42ac"]
              else
                #["615560338474256", "f2c4afb5cb0cb74259b398624967dcc9"] # Prowd local app
                ["1550475868413199", "212702a14cd05890aaab763a52bd42ac"] # Przemek local facebook app
              end

Rails.application.config.middleware.use OmniAuth::Builder do
  provider :facebook, key, secret,  token_params: { parse: :json }
end
