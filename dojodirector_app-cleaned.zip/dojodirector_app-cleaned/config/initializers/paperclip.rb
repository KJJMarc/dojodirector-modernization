Paperclip.interpolates :assets_host  do |attachment, style|
  request = Thread.current[:current_request]
  "#{request.protocol}#{request.host_with_port}" if request
end

Paperclip::Attachment.default_options.update({
   :url   => ":assets_host/system/:class/:attachment/:id_partition/:style/:filename",
   :path  => ":rails_root/public/system/:class/:attachment/:id_partition/:style/:filename"
})
