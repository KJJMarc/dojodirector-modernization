if Rails.env.test?
  Rails.application.config.assets.paths.reject! do |path|
    path =~ /font-awesome/
  end
end

