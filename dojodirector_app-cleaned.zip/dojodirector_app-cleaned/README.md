Deployment
==========

Add an endpoint

    git remote add production dokku@dokku.x8.io:prowd

Next, you can deploy using gith

    git push production master


Find more info about deployment on our [wiki](https://github.com/X8/sysadmin/wiki)

Scaling
=======

In order to change number of unicorn processes set the WEB_CONCURRENCY env variable.

    ssh dokku config:set prowd WEB_CONCURRENCY=5
